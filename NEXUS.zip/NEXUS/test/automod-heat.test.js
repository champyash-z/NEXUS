const test = require('node:test');
const assert = require('node:assert/strict');
const { heatForMessage, normalized, timeoutForViolation } = require('../src/utils/automod');

function message(content, extras = {}) {
  return {
    content,
    mentions: { users: { size: 0 }, roles: { size: 0 }, everyone: false },
    attachments: { size: 0 },
    ...extras,
  };
}

test('normalization is case and whitespace insensitive', () => {
  assert.equal(normalized('  HELLO   World! '), 'hello world');
});

test('repeated identical messages build enough heat to trigger by the third copy', () => {
  const first = heatForMessage(message('same message'), { heat: 0, lastAt: 0, messages: [] }, 10000);
  const second = heatForMessage(message('same message'), { heat: first.heat, lastAt: 10000, messages: [{ at: 10000, content: 'same message' }] }, 10500);
  const third = heatForMessage(message('same message'), { heat: second.heat, lastAt: 10500, messages: [{ at: 10000, content: 'same message' }, { at: 10500, content: 'same message' }] }, 11000);
  assert.equal(third.duplicates + 1, 3);
  assert.ok(third.heat >= 100);
});

test('heat decays while a member is inactive', () => {
  const scored = heatForMessage(message('hello'), { heat: 80, lastAt: 1000, messages: [] }, 11000);
  assert.ok(scored.heat < 50);
});

test('timeout duration escalates but never exceeds Discord maximum', () => {
  const now = Date.now();
  assert.equal(timeoutForViolation(5, []), 5);
  assert.equal(timeoutForViolation(5, [{ createdAt: new Date(now).toISOString() }]), 10);
  assert.equal(timeoutForViolation(1440, Array.from({ length: 10 }, () => ({ createdAt: new Date(now).toISOString() }))), 28 * 24 * 60);
});
