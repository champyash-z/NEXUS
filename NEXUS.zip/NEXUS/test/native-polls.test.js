const test = require('node:test');
const assert = require('node:assert/strict');
const native = require('../src/polls/native');

test('builds Discord native poll payload matching the reference style', () => {
  const result = native.buildOptions('Server Choose Karo!', ['Survival', 'Lifesteal'], 24, false);
  assert.deepEqual(result.poll.question, { text: 'Server Choose Karo!' });
  assert.deepEqual(result.poll.answers, [{ text: 'Survival' }, { text: 'Lifesteal' }]);
  assert.equal(result.poll.duration, 24);
  assert.equal(result.poll.allowMultiselect, false);
});
test('rejects fewer than two answers', () => assert.throws(() => native.buildOptions('Question', ['Only one'], 24), /between 2 and 10/));
test('rejects duplicate answers', () => assert.throws(() => native.buildOptions('Question', ['Yes', 'yes'], 24), /unique/));
test('rejects out-of-range durations', () => assert.throws(() => native.buildOptions('Question', ['Yes', 'No'], 0), /between 1 and 168/));
test('slash command schemas are valid and include the replacement commands', () => {
  const command = require('../src/commands/p');
  const json = command.data.toJSON();
  assert.equal(json.name, 'p');
  assert.deepEqual(json.options.map(option => option.name), ['create', 'time', 'builder', 'help']);
});

test('accepts multiple answer options supplied as newline-separated text', () => {
  const result = native.buildOptions('Choose', 'A\nB\nC\nD\nE', 24);
  assert.equal(result.poll.answers.length, 5);
});
