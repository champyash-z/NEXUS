const test = require('node:test');
const assert = require('node:assert/strict');
const { getLevelFromXp, getXpRequiredForLevel } = require('../src/utils/leveling');

test('XP curve has exact level boundaries for levels 1 through 100', () => {
  for (let level = 1; level <= 100; level++) {
    assert.equal(getLevelFromXp(getXpRequiredForLevel(level)), level);
    assert.equal(getLevelFromXp(getXpRequiredForLevel(level) - 1), level - 1);
  }
});

test('invalid and non-positive XP stays at level zero', () => {
  assert.equal(getLevelFromXp(0), 0);
  assert.equal(getLevelFromXp(-1), 0);
  assert.equal(getLevelFromXp(Number.NaN), 0);
});

const { isoWeekKey, monthKey, getLevelConfig } = require('../src/utils/leveling');

test('weekly and monthly leaderboard periods use UTC calendar boundaries', () => {
  const date = new Date('2026-01-01T12:00:00.000Z');
  assert.equal(isoWeekKey(date), '2026-W01');
  assert.equal(monthKey(date), '2026-01');
});

test('leveling defaults expose configurable reaction, voice, and anti-farming options', () => {
  const config = getLevelConfig('test-default-config');
  assert.equal(config.reactionXpEnabled, false);
  assert.equal(config.voiceXpEnabled, false);
  assert.equal(config.minMessageLength, 3);
  assert.equal(config.messageXpMode, 'random');
});
