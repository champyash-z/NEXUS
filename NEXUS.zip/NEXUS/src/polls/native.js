const {
  SlashCommandBuilder,
  ModalBuilder,
  ActionRowBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} = require('discord.js');

function buildOptions(question, answers, hours = 24, multiselect = false) {
  const cleanQuestion = String(question || '').trim();
  const cleanAnswers = (Array.isArray(answers) ? answers : String(answers || '').split(/\r?\n/))
    .map(x => String(x || '').trim()).filter(Boolean);
  if (!cleanQuestion || cleanQuestion.length > 300) throw new Error('Question must be between 1 and 300 characters.');
  if (cleanAnswers.length < 2 || cleanAnswers.length > 10) throw new Error(`Add between 2 and 10 answer options (you provided ${cleanAnswers.length}). Put each answer on a separate line.`);
  if (cleanAnswers.some(a => a.length > 55)) throw new Error('Each answer must be 55 characters or fewer.');
  if (new Set(cleanAnswers.map(a => a.toLocaleLowerCase())).size !== cleanAnswers.length) throw new Error('Answer options must be unique.');
  const duration = Number(hours);
  if (!Number.isInteger(duration) || duration < 1 || duration > 168) throw new Error('Duration must be between 1 and 168 hours.');
  return { poll: { question: { text: cleanQuestion }, answers: cleanAnswers.map(text => ({ text })), duration, allowMultiselect: Boolean(multiselect) } };
}

function addCreateFields(subcommand, timed = false) {
  subcommand.addStringOption(o => o.setName('question').setDescription('What should people vote on?').setRequired(true).setMaxLength(300));
  if (timed) {
    subcommand.addIntegerOption(o => o.setName('hours').setDescription('Voting duration in hours (1–168)').setRequired(true).setMinValue(1).setMaxValue(168));
  } else {
    subcommand.addIntegerOption(o => o.setName('hours').setDescription('Voting duration in hours (default 24)').setRequired(false).setMinValue(1).setMaxValue(168));
  }
  return subcommand;
}

function createCommand() {
  return new SlashCommandBuilder()
    .setName('p')
    .setDescription('Create and manage Nexus polls')
    .addSubcommand(s => addCreateFields(s.setName('create').setDescription('Create a poll'), false))
    .addSubcommand(s => addCreateFields(s.setName('time').setDescription('Create a poll that closes after a set duration'), true))
    .addSubcommand(s => s.setName('builder').setDescription('Open the interactive poll creation form'))
    .addSubcommand(s => s.setName('help').setDescription('Show poll command help'));
}

async function execute(interaction) {
  if (!interaction.inGuild()) return interaction.reply({ content: 'Polls can only be created in a server.', flags: MessageFlags.Ephemeral });
  const action = interaction.options.getSubcommand();
  if (action === 'help') {
    return interaction.reply({ flags: MessageFlags.Ephemeral, content: [
      '**Nexus Poll Help**',
      '`/p create` — create a poll (default duration: 24 hours).',
      '`/p time` — create a poll with a required duration.',
      '`/p builder` — open a form to create a poll.',
      '`/p help` — show this help.',
      '',
      'After `/p create` or `/p time`, fill in the form. Put each answer on its own line; provide 2–10 answers. Each answer can be up to 55 characters. Duration: 1–168 hours.'
    ].join('\n') });
  }
  if (action === 'builder') return interaction.showModal(builderModal());
  const question = interaction.options.getString('question');
  const hours = interaction.options.getInteger('hours') ?? 24;
  return interaction.showModal(builderModal(question, hours));
}

function builderModal(question = '', hours = 24) {
  const modal = new ModalBuilder().setCustomId('native_poll_builder').setTitle('Create a poll');
  modal.addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('question').setLabel('Poll question').setStyle(TextInputStyle.Short).setMaxLength(300).setRequired(true).setValue(String(question).slice(0, 300))),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('answers').setLabel('Answers (one per line, 2–10)').setStyle(TextInputStyle.Paragraph).setMaxLength(1000).setRequired(true)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('hours').setLabel('Duration in hours (1–168)').setStyle(TextInputStyle.Short).setMaxLength(3).setRequired(true).setValue(String(hours))),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('multiple').setLabel('Allow multiple answers? yes/no').setStyle(TextInputStyle.Short).setMaxLength(3).setRequired(true).setValue('no')),
  );
  return modal;
}
module.exports = { buildOptions, createCommand, execute, builderModal };
