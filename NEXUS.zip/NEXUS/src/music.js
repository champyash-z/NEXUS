'use strict';

// Prefix-only, YouTube-only music module for Nexus.
// Playback requires @discordjs/voice, play-dl and ffmpeg-static.
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const {
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, PermissionFlagsBits,
} = require('discord.js');
const play = require('@iamtraction/play-dl');
const {
  joinVoiceChannel, getVoiceConnection, createAudioPlayer, createAudioResource,
  AudioPlayerStatus, VoiceConnectionStatus, entersState, StreamType,
} = require('@discordjs/voice');

const DATA_PATH = path.join(__dirname, '..', '..', 'data', 'music.json');
const MAX_QUEUE = 100;
const MAX_PLAYLIST_TRACKS = 100;
const MAX_SAVED_PLAYLISTS = 25;
const INACTIVITY_MS = 3 * 60 * 1000;
const PREFIXES = ['!', '.', '?'];
const FILTERS = {
  bassboost: 'bass=g=8',
  nightcore: 'asetrate=48000*1.15,aresample=48000,atempo=1.05',
  vaporwave: 'asetrate=48000*0.8,aresample=48000,atempo=0.9',
  '8d': 'apulsator=hz=0.08',
  karaoke: 'stereotools=mlev=0.03',
  treble: 'treble=g=5',
};
const COLORS = { brand: 0x7c3aed, success: 0x22c55e, warn: 0xf59e0b, error: 0xef4444 };
const players = new Map();
const locks = new Map();
let clientRef = null;

function ensureData() {
  fs.mkdirSync(path.dirname(DATA_PATH), { recursive: true });
  if (!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, JSON.stringify({ guilds: {}, playlists: {} }, null, 2));
}
function readData() {
  ensureData();
  try {
    const data = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8'));
    return { guilds: data.guilds || {}, playlists: data.playlists || {} };
  } catch { return { guilds: {}, playlists: {} }; }
}
function writeData(data) {
  ensureData();
  const temp = `${DATA_PATH}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(data, null, 2));
  fs.renameSync(temp, DATA_PATH);
}
function defaultSettings() {
  return { djRoleId: null, trustedRoleIds: [], textChannelIds: [], voiceChannelIds: [], announceChannelId: null,
    queueLimit: MAX_QUEUE, cooldownSeconds: 3, defaultVolume: 50, maxVolume: 100, djOnly: false,
    inactivityMinutes: 3, prefixAlias: null, announce: true, autoplay: false };
}
function getSettings(guildId) {
  const data = readData();
  return { ...defaultSettings(), ...(data.guilds[guildId] || {}) };
}
function saveSettings(guildId, patch) {
  const data = readData();
  data.guilds[guildId] = { ...defaultSettings(), ...(data.guilds[guildId] || {}), ...patch };
  writeData(data);
  return data.guilds[guildId];
}
function getSavedPlaylists(guildId) {
  const data = readData();
  return data.playlists[guildId] || {};
}
function saveSavedPlaylists(guildId, playlists) {
  const data = readData(); data.playlists[guildId] = playlists; writeData(data);
}
function serializeGuild(guildId, task) {
  const previous = locks.get(guildId) || Promise.resolve();
  let release;
  const gate = new Promise(resolve => { release = resolve; });
  const tail = previous.catch(() => {}).then(() => gate);
  locks.set(guildId, tail);
  return previous.catch(() => {}).then(task).finally(() => {
    release();
    if (locks.get(guildId) === tail) locks.delete(guildId);
  });
}
function cleanText(value, max = 180) { return String(value || '').replace(/[`<>]/g, '').slice(0, max) || 'Unknown'; }
function fmtDuration(seconds) {
  if (!Number.isFinite(Number(seconds)) || Number(seconds) < 0) return 'LIVE';
  const s = Math.floor(Number(seconds));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}` : `${m}:${String(sec).padStart(2, '0')}`;
}
function isYoutubeUrl(value) {
  try {
    const u = new URL(value);
    return ['youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtu.be', 'www.youtu.be'].includes(u.hostname.toLowerCase()) && ['http:', 'https:'].includes(u.protocol);
  } catch { return false; }
}
function isPlaylistUrl(value) {
  try { const u = new URL(value); return isYoutubeUrl(value) && (u.searchParams.has('list') || u.pathname.startsWith('/playlist')); } catch { return false; }
}
function makeTrack(raw, requester) {
  const duration = Number(raw.durationInSec ?? raw.durationInSeconds ?? raw.duration ?? 0);
  return {
    title: cleanText(raw.title, 240), url: String(raw.url || raw.webpage_url || ''),
    author: cleanText(raw.channel?.name || raw.channel?.title || raw.channelName || raw.uploader || raw.author || 'YouTube'),
    duration: Number.isFinite(duration) && duration > 0 ? duration : 0,
    thumbnail: raw.thumbnails?.[0]?.url || raw.thumbnail?.url || raw.thumbnail || null,
    requesterId: requester.id, requesterTag: requester.tag || requester.username || 'Unknown',
    addedAt: Date.now(),
  };
}
function playerState(guildId) {
  if (!players.has(guildId)) {
    const settings = getSettings(guildId);
    const player = createAudioPlayer();
    const state = { guildId, player, connection: null, queue: [], current: null, history: [], recent: [],
      loop: 'off', autoplay: Boolean(settings.autoplay), volume: settings.defaultVolume, filter: 'off',
      textChannel: null, nowPlayingMessage: null, idleTimer: null, currentStartedAt: 0, currentOffset: 0,
      stopRequested: false, busy: false, lastItemWasSound: false, searchSessions: new Map(), lastRequests: new Map(), generation: 0 };
    player.on('error', error => {
      console.error(`[music:${guildId}] player error: ${error.message}`);
      const failed = state.current;
      // Soundboard playback is intentionally silent in text channels.
      if (failed?.type !== 'sound') state.textChannel?.send({ embeds: [musicEmbed('Playback error', 'This track could not be played. Skipping to the next track.', COLORS.error)] }).catch(() => {});
      state.stopRequested = false;
      if (failed && failed.type !== 'sound') state.recent.unshift(failed);
      state.current = null;
      setImmediate(() => advance(state).catch(err => console.error(`[music:${guildId}] advance: ${err.message}`)));
    });
    player.on(AudioPlayerStatus.Idle, () => {
      if (state.stopRequested) { state.stopRequested = false; return; }
      state.lastItemWasSound = state.current?.type === 'sound';
      if (state.current && state.current.type !== 'sound') {
        state.history.push(state.current);
        if (state.history.length > 50) state.history.shift();
        state.recent.unshift(state.current);
        if (state.recent.length > 25) state.recent.length = 25;
        if (state.loop === 'track') state.queue.unshift(state.current);
        else if (state.loop === 'queue') state.queue.push(state.current);
      }
      state.current = null;
      setImmediate(() => advance(state).catch(err => console.error(`[music:${guildId}] advance: ${err.message}`)));
    });
    players.set(guildId, state);
  }
  return players.get(guildId);
}
function musicEmbed(title, description, color = COLORS.brand) {
  return new EmbedBuilder().setColor(color).setTitle(`🎵 ${title}`.slice(0, 256)).setDescription(String(description || '—').slice(0, 4000)).setTimestamp().setFooter({ text: 'NEXUS MUSIC • YouTube only' });
}
function trackEmbed(state) {
  const t = state.current;
  if (!t) return musicEmbed('Nothing playing', 'Use `!play <YouTube URL or search>` to start the music.');
  const pos = state.queue.length ? `1 / ${state.queue.length + 1}` : '1 / 1';
  const embed = musicEmbed('Now Playing', `**[${t.title.replace(/\]/g, '\\]')}](${t.url})**\n${cleanText(t.author)}\n\n**Duration:** ${fmtDuration(t.duration)}\n**Requested by:** <@${t.requesterId}>\n**Queue position:** ${pos}\n**Volume:** ${state.volume}%\n**Filter:** ${state.filter}`);
  if (t.thumbnail && /^https:\/\//i.test(t.thumbnail)) embed.setThumbnail(t.thumbnail);
  return embed;
}
function playerButtons(state) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`nxmusic:pause:${state.guildId}`).setLabel(state.player.state.status === AudioPlayerStatus.Paused ? 'Resume' : 'Pause').setEmoji(state.player.state.status === AudioPlayerStatus.Paused ? '▶️' : '⏸️').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`nxmusic:skip:${state.guildId}`).setLabel('Skip').setEmoji('⏭️').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`nxmusic:stop:${state.guildId}`).setLabel('Stop').setEmoji('⏹️').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId(`nxmusic:shuffle:${state.guildId}`).setLabel('Shuffle').setEmoji('🔀').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`nxmusic:loop:${state.guildId}`).setLabel(`Loop: ${state.loop}`).setEmoji('🔁').setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`nxmusic:queue:${state.guildId}`).setLabel('View Queue').setEmoji('📜').setStyle(ButtonStyle.Secondary),
    ),
  ];
}
async function updateNowPlaying(state) {
  if (!state.textChannel?.isTextBased()) return;
  const payload = { embeds: [trackEmbed(state)], components: state.current ? playerButtons(state) : [] };
  if (state.nowPlayingMessage) {
    const edited = await state.nowPlayingMessage.edit(payload).catch(() => null);
    if (edited) return;
  }
  state.nowPlayingMessage = await state.textChannel.send(payload).catch(() => null);
}
function clearIdleTimer(state) { if (state.idleTimer) clearTimeout(state.idleTimer); state.idleTimer = null; }
function scheduleIdleDisconnect(state) {
  clearIdleTimer(state);
  const mins = Math.max(1, Math.min(30, Number(getSettings(state.guildId).inactivityMinutes) || 3));
  state.idleTimer = setTimeout(() => {
    if (!state.current && !state.queue.length) destroyState(state.guildId, 'Music inactivity timeout');
  }, mins * 60_000);
  state.idleTimer.unref?.();
}
function getFfmpegPath() { try { return require('ffmpeg-static') || 'ffmpeg'; } catch { return 'ffmpeg'; } }
function audioFilterFor(name) { return FILTERS[name] || null; }
async function resolveStream(track, state) {
  const result = await play.stream(track.url, { quality: 2 });
  const filter = audioFilterFor(state.filter);
  if (!filter) return createAudioResource(result.stream, { inputType: result.type, inlineVolume: true, metadata: track });
  // Effects are only applied when FFmpeg can decode the resolved container stream.
  // Raw Opus streams cannot safely be passed through this filter pipeline.
  if (String(result.type).toLowerCase() === 'opus') {
    state.filter = 'off';
    state.textChannel?.send({ embeds: [musicEmbed('Filter unavailable', 'This YouTube stream format cannot safely use the selected effect. Continuing playback without a filter.', COLORS.warn)] }).catch(() => {});
    return createAudioResource(result.stream, { inputType: result.type, inlineVolume: true, metadata: track });
  }
  const ffmpeg = spawn(getFfmpegPath(), ['-hide_banner', '-loglevel', 'error', '-i', 'pipe:0', '-vn', '-af', filter, '-f', 's16le', '-ar', '48000', '-ac', '2', 'pipe:1'], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
  result.stream.pipe(ffmpeg.stdin);
  let stderr = '';
  ffmpeg.stderr.on('data', chunk => { stderr = (stderr + chunk.toString()).slice(-1000); });
  ffmpeg.on('error', () => {});
  ffmpeg.on('close', code => { if (code && code !== 0) console.warn(`[music] ffmpeg filter exited ${code}: ${stderr}`); });
  const resource = createAudioResource(ffmpeg.stdout, { inputType: StreamType.Raw, inlineVolume: true, metadata: track });
  resource.playbackProcess = ffmpeg;
  return resource;
}
async function ensureVoice(message, state) {
  const memberChannel = message.member?.voice?.channel;
  if (!memberChannel) throw new Error('Join a voice channel first.');
  const me = message.guild.members.me;
  const perms = memberChannel.permissionsFor(me);
  if (!perms?.has(PermissionFlagsBits.Connect) || !perms?.has(PermissionFlagsBits.Speak)) throw new Error(`I need **Connect** and **Speak** permissions in ${memberChannel}.`);
  const settings = getSettings(message.guild.id);
  if (settings.voiceChannelIds?.length && !settings.voiceChannelIds.includes(memberChannel.id)) throw new Error('Music is not enabled in this voice channel. Ask an administrator to update `!music permissions`.');
  const existing = getVoiceConnection(message.guild.id);
  if (existing && existing.joinConfig.channelId !== memberChannel.id) {
    const botChannel = message.guild.channels.cache.get(existing.joinConfig.channelId);
    if (botChannel && botChannel.id !== memberChannel.id) throw new Error(`I am already playing in ${botChannel}. Use leave after playback is stopped, or join that voice channel.`.replaceAll('\u0001', '`'));
  }
  if (!state.connection || state.connection.state.status === VoiceConnectionStatus.Destroyed) {
    state.connection = joinVoiceChannel({ channelId: memberChannel.id, guildId: message.guild.id, adapterCreator: message.guild.voiceAdapterCreator, selfDeaf: true });
    state.connection.on('error', err => console.warn(`[music:${message.guild.id}] voice connection: ${err.message}`));
    await entersState(state.connection, VoiceConnectionStatus.Ready, 15_000);
    state.connection.subscribe(state.player);
  }
  state.textChannel = message.channel;
  return memberChannel;
}
function authorized(message, action = 'control') {
  if (!message.guild || !message.member) return false;
  const settings = getSettings(message.guild.id);
  if (message.member.permissions.has(PermissionFlagsBits.Administrator) || message.guild.ownerId === message.author.id) return true;
  if (settings.djRoleId && message.member.roles.cache.has(settings.djRoleId)) return true;
  if ((settings.trustedRoleIds || []).some(id => message.member.roles.cache.has(id))) return true;
  if (!settings.djOnly && ['pause', 'resume', 'skip', 'volume', 'filter', 'queue', 'nowplaying', 'previous', 'seek', 'forward', 'rewind', 'shuffle', 'remove', 'move', 'playnext', 'loop', 'autoplay', 'playrecent', 'selectrandom', 'mute', 'unmute', 'musicmute', 'musicunmute'].includes(action)) return true;
  return false;
}
function requireGuild(message) { if (!message.guild) throw new Error('Music commands can only be used inside a server.'); }
function requireTextChannel(message) {
  const settings = getSettings(message.guild.id);
  if (settings.textChannelIds?.length && !settings.textChannelIds.includes(message.channel.id)) throw new Error('Music commands are not allowed in this text channel.');
}
async function resolveTracks(query, requester) {
  if (isYoutubeUrl(query) && isPlaylistUrl(query)) {
    const playlist = await play.playlist_info(query, { incomplete: true });
    const videos = await playlist.all_videos();
    const tracks = videos.slice(0, MAX_PLAYLIST_TRACKS).map(v => makeTrack(v, requester)).filter(t => isYoutubeUrl(t.url));
    if (!tracks.length) throw new Error('This YouTube playlist has no available public videos.');
    return { tracks, playlistTitle: cleanText(playlist.title || 'YouTube playlist') };
  }
  if (isYoutubeUrl(query)) {
    const info = await play.video_info(query);
    const raw = info.video_details || info;
    const track = makeTrack({ title: raw.title, url: raw.url || query, channel: raw.channel, durationInSec: raw.durationInSec, thumbnails: raw.thumbnails }, requester);
    if (!track.url || !isYoutubeUrl(track.url)) track.url = query;
    if (!track.title || track.title === 'Unknown') throw new Error('YouTube did not return usable video metadata. It may be private, removed or restricted.');
    return { tracks: [track] };
  }
  const results = await play.search(query, { limit: 1, source: { youtube: 'video' } });
  if (!results?.length) throw new Error('No YouTube results found. Try a different title or a direct YouTube URL.');
  return { tracks: [makeTrack(results[0], requester)] };
}
async function enqueueAndPlay(message, query, { next = false } = {}) {
  requireGuild(message); requireTextChannel(message);
  const state = playerState(message.guild.id);
  const settings = getSettings(message.guild.id);
  const last = state.lastRequests.get(message.author.id) || 0;
  if (Date.now() - last < Math.max(0, settings.cooldownSeconds) * 1000) throw new Error(`Please wait ${Math.ceil((Math.max(0, settings.cooldownSeconds) * 1000 - (Date.now() - last)) / 1000)}s before another music request.`);
  state.lastRequests.set(message.author.id, Date.now());
  await ensureVoice(message, state);
  if (!query) throw new Error('Usage: `!play <YouTube URL or search terms>`');
  // Resolve one music request per guild at a time to avoid bursts of concurrent
  // YouTube metadata/playlist work when users spam commands during playback.
  const result = await serializeGuild(message.guild.id, () => resolveTracks(query, { id: message.author.id, tag: message.author.tag }));
  await serializeGuild(message.guild.id, async () => {
    const latestSettings = getSettings(message.guild.id);
    const capacity = Math.max(1, Math.min(MAX_QUEUE, Number(latestSettings.queueLimit) || MAX_QUEUE));
    if (state.queue.length + (state.current ? 1 : 0) + result.tracks.length > capacity) throw new Error(`That request exceeds this server's queue limit (${capacity} tracks).`);
    if (next) state.queue.unshift(...result.tracks);
    else state.queue.push(...result.tracks);
  });
  clearIdleTimer(state);
  state.textChannel = message.channel;
  if (result.playlistTitle) await message.reply({ embeds: [musicEmbed('Playlist queued', `Loaded **${result.tracks.length}** available track(s) from **${result.playlistTitle}**.`, COLORS.success)] });
  else if (result.tracks.length > 1) await message.reply({ embeds: [musicEmbed('Tracks queued', `Added **${result.tracks.length}** tracks to the queue.`, COLORS.success)] });
  else await message.reply({ embeds: [musicEmbed('Added to queue', `**[${result.tracks[0].title}](${result.tracks[0].url})**\n${fmtDuration(result.tracks[0].duration)} • Requested by ${message.author}`, COLORS.success)] });
  if (!state.current || state.player.state.status === AudioPlayerStatus.Idle) await advance(state);
  return state;
}
async function advance(state) {
  if (state.busy || state.current) return;
  state.busy = true;
  try {
    const next = state.queue.shift();
    if (!next) {
      if (!state.lastItemWasSound) await updateNowPlaying(state);
      state.lastItemWasSound = false;
      scheduleIdleDisconnect(state);
      if (state.autoplay || getSettings(state.guildId).autoplay) {
        const recent = state.recent[0];
        if (recent) {
          const query = `${recent.title} ${recent.author}`;
          const found = await play.search(query, { limit: 5, source: { youtube: 'video' } }).catch(() => []);
          const candidate = found.find(v => v.url !== recent.url);
          if (candidate) {
            state.queue.push(makeTrack(candidate, { id: recent.requesterId, tag: recent.requesterTag }));
            clearIdleTimer(state);
            setImmediate(() => advance(state).catch(() => {}));
            return;
          }
        }
      }
      return;
    }
    state.current = next;
    state.currentStartedAt = Date.now(); state.currentOffset = 0;
    try {
      const resource = next.type === 'sound'
        ? createAudioResource(next.file)
        : await resolveStream(next, state);
      if (resource.volume) resource.volume.setVolume(Math.max(0, Math.min(1, state.volume / 100)));
      state.player.play(resource);
      clearIdleTimer(state);
      if (next.type !== 'sound') await updateNowPlaying(state);
      const settings = getSettings(state.guildId);
      const announceChannel = settings.announceChannelId && settings.announce
        ? clientRef?.channels?.cache?.get(settings.announceChannelId) : null;
      if (next.type !== 'sound' && announceChannel?.isTextBased() && announceChannel.id !== state.textChannel?.id) {
        await announceChannel.send({ embeds: [trackEmbed(state)] }).catch(() => {});
      }
    } catch (error) {
      console.warn(`[music:${state.guildId}] unable to play ${next.type === 'sound' ? 'sound' : next.url}: ${error.message}`);
      state.current = null;
      if (next.type !== 'sound') state.textChannel?.send({ embeds: [musicEmbed('Track unavailable', `**${next.title}** could not be resolved by the audio backend. It may be removed, private, restricted or temporarily unavailable. Skipping it.`, COLORS.warn)] }).catch(() => {});
      setImmediate(() => advance(state).catch(() => {}));
    }
  } finally { state.busy = false; }
}
function queueEmbed(state, page = 0) {
  const all = [...(state.current ? [state.current] : []), ...state.queue];
  const pageSize = 10, maxPage = Math.max(0, Math.ceil(all.length / pageSize) - 1), currentPage = Math.min(Math.max(0, page), maxPage);
  const slice = all.slice(currentPage * pageSize, currentPage * pageSize + pageSize);
  const desc = slice.length ? slice.map((t, i) => `**${currentPage * pageSize + i + 1}.** ${t.title.slice(0, 110)} · \`${fmtDuration(t.duration)}\` · <@${t.requesterId}>${state.current === t ? '  **NOW PLAYING**' : ''}`).join('\n') : 'The queue is empty.';
  return musicEmbed(`Queue • ${all.length} track(s)`, desc).setFooter({ text: `NEXUS MUSIC • Page ${currentPage + 1}/${maxPage + 1}` });
}
function queueRows(state, page = 0) {
  const total = Math.max(1, Math.ceil(([...(state.current ? [state.current] : []), ...state.queue]).length / 10));
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`nxmusic:qprev:${state.guildId}:${page}`).setLabel('Previous').setStyle(ButtonStyle.Secondary).setDisabled(page <= 0),
    new ButtonBuilder().setCustomId(`nxmusic:qnext:${state.guildId}:${page}`).setLabel('Next').setStyle(ButtonStyle.Secondary).setDisabled(page >= total - 1),
  )];
}
async function destroyState(guildId, reason = 'Music stopped') {
  const state = players.get(guildId); if (!state) return;
  clearIdleTimer(state);
  state.stopRequested = true;
  state.queue.length = 0; state.current = null;
  try { state.player.stop(true); } catch {}
  const connection = state.connection || getVoiceConnection(guildId);
  if (connection) { try { connection.destroy(); } catch {} }
  if (state.nowPlayingMessage) await state.nowPlayingMessage.edit({ embeds: [musicEmbed('Playback ended', reason, COLORS.warn)], components: [] }).catch(() => {});
  players.delete(guildId);
}
function safeName(name) { return String(name || '').trim().toLowerCase().replace(/[^a-z0-9 _-]/g, '').replace(/\s+/g, '-').slice(0, 32); }
function playlistName(args) { return args.join(' ').trim().replace(/^['"]|['"]$/g, '').slice(0, 60); }
function ensureDJ(message, action) { if (!authorized(message, action)) throw new Error(`You need the configured DJ/trusted role or Administrator permission to ${action}.`); }
async function handleCommand(message, args) {
  const sub = String(args[0] || '').toLowerCase();
  const rest = args.slice(1);
  try {
    if (!message.guild && !['help'].includes(sub)) throw new Error('Music commands can only be used inside a server.');
    if (sub === 'help' || !sub) return message.reply({ embeds: [musicEmbed('Nexus Music Commands', [
      '**Playback:** `!play <YouTube URL/search>`, `!search <query>`, `!pause`, `!resume`, `!skip`, `!stop`, `!join`, `!leave`, `!previous`, `!nowplaying`, `!seek <time>`, `!forward <seconds>`, `!rewind <seconds>`, `!volume <0-100>`, `!music mute`, `!music unmute`,',
      '**Queue:** `!queue [page]`, `!shuffle`, `!clear`, `!remove <position>`, `!move <from> <to>`, `!playnext <URL/search>`, `!loop off|track|queue`, `!autoplay on|off`, `!playrecent`, `!selectrandom`,',
      '**Music config:** `!music setup`, `!music settings`, `!music status`, `!music permissions`, `!music prefix`, `!music announce #channel|off`, `!music reset`,',
      '**Playlists:** `!playlist create|add|remove|play|view|rename|delete|list`,',
      '**Effects:** `!filter off|bassboost|nightcore|vaporwave|8d|karaoke|treble` (filter support depends on the resolved stream format).',
      'All music commands work with `!`, `.`, and `?`. YouTube only; no slash commands are used.'
    ].join('\n'))] });
    requireGuild(message); requireTextChannel(message);
    const state = playerState(message.guild.id);
    const requireCurrent = () => { if (!state.current) throw new Error('Nothing is playing right now.'); return state.current; };
    switch (sub) {
      case 'play': case 'search': {
        const query = rest.join(' ').trim();
        if (!query) throw new Error(`Usage: \`${sub === 'search' ? 'search' : 'play'} <YouTube URL or search terms>\``);
        if (sub === 'search' && !isYoutubeUrl(query)) {
          await ensureVoice(message, state);
          const results = await play.search(query, { limit: 5, source: { youtube: 'video' } });
          if (!results?.length) throw new Error('No YouTube search results found.');
          const requester = { id: message.author.id, tag: message.author.tag };
          const rows = results.slice(0, 5).map((v, i) => ({ label: cleanText(v.title, 95), description: `${cleanText(v.channel?.name || 'YouTube')} • ${fmtDuration(v.durationInSec)}`.slice(0, 95), value: String(i) }));
          state.searchSessions.set(message.author.id, { results: results.slice(0, 5).map(v => makeTrack(v, requester)), at: Date.now() });
          const menu = new StringSelectMenuBuilder().setCustomId(`nxmusic:search:${message.guild.id}:${message.author.id}`).setPlaceholder('Choose a YouTube result').addOptions(rows);
          return message.reply({ embeds: [musicEmbed('Choose a track', 'Select the correct YouTube video below. It will be added to this server’s queue.')], components: [new ActionRowBuilder().addComponents(menu)] });
        }
        return enqueueAndPlay(message, query);
      }
      case 'join': { await ensureVoice(message, state); return message.reply({ embeds: [musicEmbed('Connected', `Joined ${message.member.voice.channel}.`, COLORS.success)] }); }
      case 'leave': case 'disconnect': { ensureDJ(message, 'disconnect the player'); return destroyState(message.guild.id, `Disconnected by ${message.author.tag}`); }
      case 'pause': { ensureDJ(message, 'pause'); requireCurrent(); if (!state.player.pause()) throw new Error('Playback could not be paused.'); return message.reply({ embeds: [musicEmbed('Paused', 'Playback is paused.', COLORS.warn)] }); }
      case 'resume': { ensureDJ(message, 'resume'); if (!state.player.unpause()) throw new Error('Playback is not paused.'); return message.reply({ embeds: [musicEmbed('Resumed', 'Playback continued.', COLORS.success)] }); }
      case 'skip': { ensureDJ(message, 'skip'); requireCurrent(); state.stopRequested = false; state.player.stop(true); return message.reply({ embeds: [musicEmbed('Skipped', 'Moving to the next track.', COLORS.success)] }); }
      case 'stop': { ensureDJ(message, 'stop playback'); state.queue = []; state.stopRequested = true; const hadPlayback = state.player.stop(true); state.current = null; if (!hadPlayback) state.stopRequested = false; await updateNowPlaying(state); scheduleIdleDisconnect(state); return message.reply({ embeds: [musicEmbed('Stopped', 'Playback stopped and the queue was cleared.', COLORS.warn)] }); }
      case 'previous': { ensureDJ(message, 'previous'); const prev = state.history.pop(); if (!prev) throw new Error('There is no previous track in history.'); if (state.current) state.queue.unshift(state.current); state.queue.unshift(prev); state.stopRequested = true; state.player.stop(true); state.current = null; await advance(state); return message.reply({ embeds: [musicEmbed('Previous track', `Replaying **${prev.title}**.`, COLORS.success)] }); }
      case 'nowplaying': case 'np': { requireCurrent(); await updateNowPlaying(state); return state.nowPlayingMessage ? message.reply({ embeds: [trackEmbed(state)] }) : message.reply({ embeds: [trackEmbed(state)] }); }
      case 'queue': case 'q': { const page = Math.max(0, Number.parseInt(rest[0] || '1', 10) - 1 || 0); return message.reply({ embeds: [queueEmbed(state, page)], components: queueRows(state, page) }); }
      case 'shuffle': { ensureDJ(message, 'shuffle'); for (let i = state.queue.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [state.queue[i], state.queue[j]] = [state.queue[j], state.queue[i]]; } return message.reply({ embeds: [musicEmbed('Queue shuffled', `Shuffled **${state.queue.length}** queued tracks.`, COLORS.success)] }); }
      case 'clear': { ensureDJ(message, 'clear the queue'); const count = state.queue.length; state.queue = []; return message.reply({ embeds: [musicEmbed('Queue cleared', `Removed **${count}** queued tracks.`, COLORS.warn)] }); }
      case 'remove': { ensureDJ(message, 'remove'); const pos = Number(rest[0]); if (!Number.isInteger(pos) || pos < 1 || pos > state.queue.length) throw new Error('Usage: `!remove <queue position>` (positions start at 1 after the current track).'); const [removed] = state.queue.splice(pos - 1, 1); return message.reply({ embeds: [musicEmbed('Track removed', `Removed **${removed.title}** from the queue.`, COLORS.success)] }); }
      case 'move': { ensureDJ(message, 'move'); const from = Number(rest[0]), to = Number(rest[1]); if (![from, to].every(Number.isInteger) || from < 1 || from > state.queue.length || to < 1 || to > state.queue.length) throw new Error('Usage: `!move <from position> <to position>`.'); const [track] = state.queue.splice(from - 1, 1); state.queue.splice(to - 1, 0, track); return message.reply({ embeds: [musicEmbed('Queue reordered', `Moved **${track.title}** to queue position **${to}**.`, COLORS.success)] }); }
      case 'playnext': { return enqueueAndPlay(message, rest.join(' '), { next: true }); }
      case 'loop': { ensureDJ(message, 'loop'); const mode = String(rest[0] || '').toLowerCase(); if (!['off', 'track', 'queue'].includes(mode)) throw new Error('Usage: `!loop off|track|queue`.'); state.loop = mode; return message.reply({ embeds: [musicEmbed('Loop mode updated', `Loop mode: **${mode}**.`, COLORS.success)] }); }
      case 'autoplay': { const mode = String(rest[0] || '').toLowerCase(); if (!['on', 'off'].includes(mode)) throw new Error('Usage: `!autoplay on|off`.'); state.autoplay = mode === 'on'; saveSettings(message.guild.id, { autoplay: state.autoplay }); return message.reply({ embeds: [musicEmbed('Autoplay updated', `Autoplay is **${mode}**.`, COLORS.success)] }); }
      case 'playrecent': { const track = state.recent[Number(rest[0] || 1) - 1]; if (!track) throw new Error('No recent track at that position. Use `!playrecent [position]`.'); return enqueueAndPlay(message, track.url); }
      case 'selectrandom': { if (!state.queue.length) throw new Error('The queue is empty.'); const idx = Math.floor(Math.random() * state.queue.length); const [track] = state.queue.splice(idx, 1); state.queue.unshift(track); if (state.current) { state.history.push(state.current); state.recent.unshift(state.current); state.current = null; state.stopRequested = true; state.player.stop(true); } await advance(state); return message.reply({ embeds: [musicEmbed('Random track selected', `Playing **${track.title}**.`, COLORS.success)] }); }
      case 'volume': { ensureDJ(message, 'volume'); const vol = Number(rest[0]); if (!Number.isFinite(vol) || vol < 0 || vol > getSettings(message.guild.id).maxVolume) throw new Error(`Usage: \`volume <0-${getSettings(message.guild.id).maxVolume}>\``); state.volume = vol; const resource = state.player.state.resource; if (resource?.volume) resource.volume.setVolume(vol / 100); return message.reply({ embeds: [musicEmbed('Volume updated', `Volume set to **${vol}%**.`, COLORS.success)] }); }
      case 'musicmute': { ensureDJ(message, 'musicmute'); state.volumeBeforeMute = state.volume || 50; state.volume = 0; if (state.player.state.resource?.volume) state.player.state.resource.volume.setVolume(0); return message.reply({ embeds: [musicEmbed('Muted', 'Music volume set to 0%.', COLORS.warn)] }); }
      case 'musicunmute': { ensureDJ(message, 'musicunmute'); state.volume = state.volumeBeforeMute || getSettings(message.guild.id).defaultVolume || 50; if (state.player.state.resource?.volume) state.player.state.resource.volume.setVolume(state.volume / 100); return message.reply({ embeds: [musicEmbed('Unmuted', `Volume restored to **${state.volume}%**.`, COLORS.success)] }); }
      case 'seek': case 'forward': case 'rewind': { throw new Error('Seeking is not supported by the current play-dl stream backend. Forward/rewind require a seekable audio source; this implementation will not claim a seek succeeded.'); }
      case 'filter': {
        ensureDJ(message, 'filter'); const name = String(rest[0] || '').toLowerCase();
        if (name === 'off' || name === 'reset') { state.filter = 'off'; return message.reply({ embeds: [musicEmbed('Filters reset', 'New tracks will play without an audio filter. Restart the current track with `!play` if you need the filter change immediately.', COLORS.success)] }); }
        if (!FILTERS[name]) throw new Error(`Unknown filter. Supported: ${Object.keys(FILTERS).join(', ')}, off.`);
        state.filter = name;
        return message.reply({ embeds: [musicEmbed('Filter selected', `**${name}** will be applied to the next track when the resolved YouTube stream is filter-compatible. Some stream formats may reject effects safely.`, COLORS.success)] });
      }
      case 'music': {
        const action = String(rest[0] || '').toLowerCase();
        if (action === 'mute') return handleCommand(message, ['musicmute']);
        if (action === 'unmute') return handleCommand(message, ['musicunmute']);
        return handleMusicConfig(message, rest);
      }
      case 'playlist': return handlePlaylist(message, rest, state);
      default: throw new Error('Unknown music command. Use `!music help` for the complete command list.');
    }
  } catch (error) {
    return message.reply({ embeds: [musicEmbed('Music command failed', error.message || 'The request could not be completed.', COLORS.error)] }).catch(() => {});
  }
}
async function handleMusicConfig(message, args) {
  const sub = String(args[0] || 'status').toLowerCase();
  const settings = getSettings(message.guild.id);
  const admin = message.guild.ownerId === message.author.id || message.member.permissions.has(PermissionFlagsBits.Administrator) || message.member.permissions.has(PermissionFlagsBits.ManageGuild);
  if (sub === 'help') return message.reply({ embeds: [musicEmbed('Music setup help', '`!music setup` • `!music settings [queue-limit|default-volume|max-volume|cooldown|inactivity number]` • `!music status` • `!music permissions [dj @role|trusted @role|djonly on|off]` • `!music prefix <prefix>` • `!music announce #channel|off` • `!music reset`')] });
  if (sub === 'status') {
    const state = players.get(message.guild.id);
    return message.reply({ embeds: [musicEmbed('Music status', `**Player:** ${state?.current ? 'Playing' : state?.connection ? 'Connected / idle' : 'Disconnected'}\n**Current:** ${state?.current?.title || 'Nothing'}\n**Queue:** ${state?.queue.length || 0} track(s)\n**Loop:** ${state?.loop || 'off'}\n**Autoplay:** ${(state?.autoplay ?? settings.autoplay) ? 'On' : 'Off'}\n**Volume:** ${state?.volume ?? settings.defaultVolume}%\n**DJ-only:** ${settings.djOnly ? 'On' : 'Off'}\n**DJ role:** ${settings.djRoleId ? `<@&${settings.djRoleId}>` : 'Not set'}\n**Announcements:** ${settings.announceChannelId ? `<#${settings.announceChannelId}>` : 'Off'}`)] });
  }
  if (!admin) throw new Error('Administrator or Manage Server permission is required for music configuration.');
  if (sub === 'setup') {
    const settingsNow = getSettings(message.guild.id);
    return message.reply({ embeds: [musicEmbed('Nexus Music Setup', 'YouTube-only music is enabled. Make sure Nexus has **View Channels**, **Connect**, and **Speak** permissions.\n\nConfigure options with `!music permissions`, `!music announce #channel`, `!music settings`, and `!music prefix !`.\n\nThe bot uses prefix commands only: `!`, `.`, and `?`.')] });
  }
  if (sub === 'settings') {
    const key = String(args[1] || '').toLowerCase();
    if (key) {
      const value = Number(args[2]);
      const ranges = { 'queue-limit': [1, MAX_QUEUE], 'default-volume': [0, 100], 'max-volume': [1, 100], cooldown: [0, 30], inactivity: [1, 30] };
      if (!ranges[key]) throw new Error('Usage: `!music settings queue-limit|default-volume|max-volume|cooldown|inactivity <number>`.');
      const [min, max] = ranges[key];
      if (!Number.isInteger(value) || value < min || value > max) throw new Error(`${key} must be a whole number between ${min} and ${max}.`);
      const field = { 'queue-limit': 'queueLimit', 'default-volume': 'defaultVolume', 'max-volume': 'maxVolume', cooldown: 'cooldownSeconds', inactivity: 'inactivityMinutes' }[key];
      const updated = saveSettings(message.guild.id, { [field]: value });
      return message.reply({ embeds: [musicEmbed('Music setting saved', `**${key}:** ${value}${key.includes('volume') ? '%' : ''}`, COLORS.success)] });
    }
    const updated = saveSettings(message.guild.id, {});
    return message.reply({ embeds: [musicEmbed('Music settings', `**Queue limit:** ${updated.queueLimit}\n**Default volume:** ${updated.defaultVolume}%\n**Maximum volume:** ${updated.maxVolume}%\n**Cooldown:** ${updated.cooldownSeconds}s\n**Inactivity disconnect:** ${updated.inactivityMinutes} minute(s)\n**DJ-only mode:** ${updated.djOnly ? 'On' : 'Off'}\n**Allowed text channels:** ${updated.textChannelIds.length ? updated.textChannelIds.map(id => `<#${id}>`).join(', ') : 'All'}\n**Allowed voice channels:** ${updated.voiceChannelIds.length ? updated.voiceChannelIds.map(id => `<#${id}>`).join(', ') : 'All'}`)] });
  }
  if (sub === 'permissions') {
    const mode = String(args[1] || '').toLowerCase();
    if (mode === 'dj') {
      const role = message.mentions.roles.first(); if (!role) throw new Error('Usage: `!music permissions dj @Role`');
      saveSettings(message.guild.id, { djRoleId: role.id });
      return message.reply({ embeds: [musicEmbed('DJ role saved', `Sensitive music controls can be managed by ${role}.`, COLORS.success)] });
    }
    if (mode === 'djonly') {
      const enabled = String(args[2] || '').toLowerCase(); if (!['on', 'off'].includes(enabled)) throw new Error('Usage: `!music permissions djonly on|off`');
      saveSettings(message.guild.id, { djOnly: enabled === 'on' });
      return message.reply({ embeds: [musicEmbed('DJ-only mode updated', `DJ-only mode is **${enabled}**.`, COLORS.success)] });
    }
    if (mode === 'trusted') {
      const role = message.mentions.roles.first(); if (!role) throw new Error('Usage: `!music permissions trusted @Role`');
      saveSettings(message.guild.id, { trustedRoleIds: [...new Set([...(settings.trustedRoleIds || []), role.id])] });
      return message.reply({ embeds: [musicEmbed('Trusted role saved', `${role} can use privileged music controls.`, COLORS.success)] });
    }
    if (mode === 'text') {
      const channel = message.mentions.channels.first(); if (!channel || !channel.isTextBased()) throw new Error('Usage: `!music permissions text #channel`');
      const ids = [...new Set([...settings.textChannelIds, channel.id])]; saveSettings(message.guild.id, { textChannelIds: ids });
      return message.reply({ embeds: [musicEmbed('Music text channel allowed', `${channel} can now use music commands.`, COLORS.success)] });
    }
    if (mode === 'voice') {
      const channel = message.mentions.channels.first(); if (!channel?.isVoiceBased()) throw new Error('Usage: `!music permissions voice #voice-channel`');
      saveSettings(message.guild.id, { voiceChannelIds: [...new Set([...settings.voiceChannelIds, channel.id])] });
      return message.reply({ embeds: [musicEmbed('Music voice channel allowed', `${channel} can now be used for music.`, COLORS.success)] });
    }
    if (mode === 'cleartext') { saveSettings(message.guild.id, { textChannelIds: [] }); return message.reply({ embeds: [musicEmbed('Text restrictions cleared', 'Music commands are allowed in all text channels.', COLORS.success)] }); }
    if (mode === 'clearvoice') { saveSettings(message.guild.id, { voiceChannelIds: [] }); return message.reply({ embeds: [musicEmbed('Voice restrictions cleared', 'Music can join any permitted voice channel.', COLORS.success)] }); }
    throw new Error('Usage: `!music permissions dj @Role` | `trusted @Role` | `djonly on|off` | `text #channel` | `voice #voice-channel` | `cleartext` | `clearvoice`');
  }
  if (sub === 'prefix') {
    const prefix = String(args[1] || ''); if (!['!', '.', '?'].includes(prefix)) throw new Error('Nexus currently supports the prefixes `!`, `.` and `?`. Choose one of these; custom prefixes are not enabled.');
    saveSettings(message.guild.id, { prefixAlias: prefix });
    return message.reply({ embeds: [musicEmbed('Prefix preference saved', `Preferred music prefix: **${prefix}**. All three prefixes remain available.`, COLORS.success)] });
  }
  if (sub === 'announce') {
    const channel = message.mentions.channels.first();
    if (String(args[1] || '').toLowerCase() === 'off') { saveSettings(message.guild.id, { announceChannelId: null, announce: false }); return message.reply({ embeds: [musicEmbed('Announcements disabled', 'Now-playing announcements are disabled.', COLORS.success)] }); }
    if (!channel?.isTextBased()) throw new Error('Usage: `!music announce #channel` or `!music announce off`.');
    saveSettings(message.guild.id, { announceChannelId: channel.id, announce: true });
    return message.reply({ embeds: [musicEmbed('Announcement channel saved', `Now-playing announcements will be sent to ${channel}.`, COLORS.success)] });
  }
  if (sub === 'reset') {
    saveSettings(message.guild.id, defaultSettings());
    return message.reply({ embeds: [musicEmbed('Music settings reset', 'Music settings were reset to defaults. Saved playlists were kept.', COLORS.success)] });
  }
  throw new Error('Unknown music configuration action. Use `!music help`.');
}
async function handlePlaylist(message, args, state) {
  const sub = String(args[0] || 'list').toLowerCase();
  const rest = args.slice(1);
  let playlists = getSavedPlaylists(message.guild.id);
  const name = playlistName(rest.slice(0, sub === 'add' || sub === 'remove' ? 1 : rest.length));
  if (sub === 'list') {
    const entries = Object.entries(playlists);
    return message.reply({ embeds: [musicEmbed('Saved playlists', entries.length ? entries.map(([key, p]) => `**${p.name}** · ${p.tracks.length} track(s) · owner <@${p.ownerId}>`).join('\n').slice(0, 3800) : 'No saved playlists yet. Create one with `!playlist create <name>`.')] });
  }
  if (sub === 'create') {
    const playlistNameValue = playlistName(rest); const key = safeName(playlistNameValue);
    if (!key) throw new Error('Usage: `!playlist create <name>`.');
    if (playlists[key]) throw new Error('A playlist with that name already exists.');
    if (Object.keys(playlists).length >= MAX_SAVED_PLAYLISTS) throw new Error(`This server has reached its ${MAX_SAVED_PLAYLISTS}-playlist limit.`);
    playlists[key] = { name: playlistNameValue, ownerId: message.author.id, tracks: [], createdAt: Date.now() }; saveSavedPlaylists(message.guild.id, playlists);
    return message.reply({ embeds: [musicEmbed('Playlist created', `Created **${playlistNameValue}**. Add YouTube tracks with playlist add ${playlistNameValue} <YouTube URL>.`.replaceAll('\u0001', '`'), COLORS.success)] });
  }
  const key = safeName(rest[0]); const playlist = playlists[key];
  if (!playlist) throw new Error('Playlist not found. Use `!playlist list`.');
  const canEdit = playlist.ownerId === message.author.id || message.guild.ownerId === message.author.id || message.member.permissions.has(PermissionFlagsBits.ManageGuild);
  if (['add', 'remove', 'rename', 'delete'].includes(sub) && !canEdit) throw new Error('Only the playlist owner or server managers can edit this playlist.');
  if (sub === 'add') {
    const query = rest.slice(1).join(' ').trim(); if (!query) throw new Error('Usage: `!playlist add <name> <YouTube URL or search terms>`.');
    const resolved = await resolveTracks(query, { id: message.author.id, tag: message.author.tag });
    if (playlist.tracks.length + resolved.tracks.length > MAX_PLAYLIST_TRACKS) throw new Error(`A playlist can contain at most ${MAX_PLAYLIST_TRACKS} tracks.`);
    playlist.tracks.push(...resolved.tracks.map(({ title, url, author, duration, thumbnail }) => ({ title, url, author, duration, thumbnail })));
    playlists[key] = playlist; saveSavedPlaylists(message.guild.id, playlists);
    return message.reply({ embeds: [musicEmbed('Playlist updated', `Added **${resolved.tracks.length}** track(s) to **${playlist.name}**.`, COLORS.success)] });
  }
  if (sub === 'remove') {
    const pos = Number(rest[1]); if (!Number.isInteger(pos) || pos < 1 || pos > playlist.tracks.length) throw new Error('Usage: `!playlist remove <name> <track number>`.');
    const [removed] = playlist.tracks.splice(pos - 1, 1); saveSavedPlaylists(message.guild.id, playlists);
    return message.reply({ embeds: [musicEmbed('Track removed', `Removed **${removed.title}** from **${playlist.name}**.`, COLORS.success)] });
  }
  if (sub === 'view') {
    const page = Math.max(0, Number(rest[1] || 1) - 1); const tracks = playlist.tracks.slice(page * 10, page * 10 + 10);
    return message.reply({ embeds: [musicEmbed(`${playlist.name} • ${playlist.tracks.length} tracks`, tracks.length ? tracks.map((t, i) => `**${page * 10 + i + 1}.** [${t.title}](${t.url}) · ${fmtDuration(t.duration)}`).join('\n') : 'This playlist has no tracks.') ] });
  }
  if (sub === 'play') {
    if (!playlist.tracks.length) throw new Error('This playlist has no tracks.');
    await ensureVoice(message, state);
    const settings = getSettings(message.guild.id); const count = state.queue.length + (state.current ? 1 : 0) + playlist.tracks.length;
    if (count > settings.queueLimit) throw new Error(`Playing this playlist would exceed the queue limit (${settings.queueLimit}).`);
    state.queue.push(...playlist.tracks.map(t => ({ ...t, requesterId: message.author.id, requesterTag: message.author.tag, addedAt: Date.now() })));
    state.textChannel = message.channel; clearIdleTimer(state);
    await message.reply({ embeds: [musicEmbed('Playlist queued', `Added **${playlist.tracks.length}** tracks from **${playlist.name}**.`, COLORS.success)] });
    if (!state.current) await advance(state); return;
  }
  if (sub === 'rename') {
    const newName = playlistName(rest.slice(1)); const newKey = safeName(newName); if (!newKey) throw new Error('Usage: `!playlist rename <old name> <new name>`.');
    if (playlists[newKey] && newKey !== key) throw new Error('A playlist with that name already exists.');
    delete playlists[key]; playlist.name = newName; playlists[newKey] = playlist; saveSavedPlaylists(message.guild.id, playlists);
    return message.reply({ embeds: [musicEmbed('Playlist renamed', `Playlist renamed to **${newName}**.`, COLORS.success)] });
  }
  if (sub === 'delete') { delete playlists[key]; saveSavedPlaylists(message.guild.id, playlists); return message.reply({ embeds: [musicEmbed('Playlist deleted', `Deleted **${playlist.name}**.`, COLORS.warn)] }); }
  throw new Error('Usage: `!playlist create|add|remove|play|view|rename|delete|list ...`.');
}
async function handleInteraction(interaction) {
  if (!interaction.customId?.startsWith('nxmusic:')) return false;
  const parts = interaction.customId.split(':'); const action = parts[1]; const guildId = parts[2];
  if (!interaction.guildId || interaction.guildId !== guildId) {
    if (!interaction.replied && !interaction.deferred) await interaction.reply({ content: 'This music control belongs to a different server.', ephemeral: true }).catch(() => {});
    return true;
  }
  const state = players.get(guildId);
  if (action === 'search' && interaction.isStringSelectMenu()) {
    const ownerId = parts[3];
    if (interaction.user.id !== ownerId) { await interaction.reply({ content: 'Only the user who started this search can select a result.', ephemeral: true }).catch(() => {}); return true; }
    const session = state?.searchSessions.get(ownerId);
    if (!session || Date.now() - session.at > 120_000) { await interaction.reply({ content: 'These search results expired. Run `!search` again.', ephemeral: true }).catch(() => {}); return true; }
    const track = session.results[Number(interaction.values[0])];
    if (!track) { await interaction.reply({ content: 'That search result is no longer available.', ephemeral: true }).catch(() => {}); return true; }
    const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
    const channel = member?.voice?.channel;
    const st = playerState(guildId);
    if (!channel || (st.connection?.joinConfig?.channelId && channel.id !== st.connection.joinConfig.channelId)) {
      await interaction.reply({ content: 'Join the same voice channel as Nexus before selecting a search result.', ephemeral: true }).catch(() => {});
      return true;
    }
    track.requesterId = interaction.user.id; track.requesterTag = interaction.user.tag;
    try {
      await serializeGuild(guildId, () => {
        const settings = getSettings(guildId);
        const capacity = Math.max(1, Math.min(MAX_QUEUE, Number(settings.queueLimit) || MAX_QUEUE));
        if (st.queue.length + (st.current ? 1 : 0) + 1 > capacity) throw new Error(`The queue limit is ${capacity} tracks.`);
        st.queue.push(track);
      });
    } catch (error) {
      await interaction.reply({ content: error.message, ephemeral: true }).catch(() => {});
      return true;
    }
    st.textChannel = interaction.channel;
    await interaction.update({ embeds: [musicEmbed('Added to queue', `**[${track.title}](${track.url})** was added to the queue.`, COLORS.success)], components: [] }).catch(() => {});
    if (!st.current) {
      try {
        const fakeMessage = { guild: interaction.guild, member, author: interaction.user, channel: interaction.channel };
        await ensureVoice(fakeMessage, st); await advance(st);
      } catch (error) { st.queue = st.queue.filter(t => t !== track); await interaction.followUp({ content: error.message, ephemeral: true }).catch(() => {}); }
    }
    return true;
  }
  if (action === 'qprev' || action === 'qnext') {
    if (!interaction.isButton()) return true;
    const page = Number(parts[3] || 0) + (action === 'qnext' ? 1 : -1);
    return interaction.update({ embeds: [queueEmbed(state || playerState(guildId), page)], components: queueRows(state || playerState(guildId), Math.max(0, page)) }).catch(() => true);
  }
  if (!interaction.isButton()) return true;
  if (!state) return interaction.reply({ content: 'No active music session exists.', ephemeral: true }).catch(() => true);
  const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
  const settings = getSettings(guildId);
  const privileged = Boolean(interaction.guild.ownerId === interaction.user.id || interaction.memberPermissions?.has(PermissionFlagsBits.Administrator) || interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild) || (settings.djRoleId && member?.roles.cache.has(settings.djRoleId)) || (settings.trustedRoleIds || []).some(id => member?.roles.cache.has(id)));
  if (action === 'queue') return interaction.reply({ embeds: [queueEmbed(state)], components: queueRows(state, 0), ephemeral: true }).catch(() => true);
  if (['pause', 'skip', 'stop', 'shuffle', 'loop'].includes(action) && !privileged && settings.djOnly) return interaction.reply({ content: 'DJ role or Administrator permission is required for this control.', ephemeral: true }).catch(() => true);
  const botVoiceChannelId = state.connection?.joinConfig?.channelId;
  if (!privileged && botVoiceChannelId && member?.voice?.channelId !== botVoiceChannelId) return interaction.reply({ content: 'Join the same voice channel as Nexus to use music controls.', ephemeral: true }).catch(() => true);
  if (action === 'pause') {
    if (state.player.state.status === AudioPlayerStatus.Paused) state.player.unpause(); else state.player.pause();
  } else if (action === 'skip') {
    if (!state.current) return interaction.reply({ content: 'Nothing is playing.', ephemeral: true }).catch(() => true);
    state.player.stop(true);
  } else if (action === 'stop') {
    state.queue = []; state.stopRequested = true; const hadPlayback = state.player.stop(true); state.current = null; if (!hadPlayback) state.stopRequested = false; scheduleIdleDisconnect(state);
  } else if (action === 'shuffle') {
    for (let i = state.queue.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [state.queue[i], state.queue[j]] = [state.queue[j], state.queue[i]]; }
  } else if (action === 'loop') {
    state.loop = state.loop === 'off' ? 'track' : state.loop === 'track' ? 'queue' : 'off';
  }
  await interaction.update({ embeds: [trackEmbed(state)], components: state.current ? playerButtons(state) : [] }).catch(() => {});
  return true;
}
function initialize(client) {
  clientRef = client;
  // Clear stale timers/sessions and expire search sessions lazily.
  setInterval(() => {
    for (const state of players.values()) {
      for (const [userId, session] of state.searchSessions) if (Date.now() - session.at > 120_000) state.searchSessions.delete(userId);
    }
  }, 60_000).unref?.();
}
async function enqueueSound(message, file, name) {
  requireGuild(message);
  const voiceChannel = message.member?.voice?.channel;
  if (!voiceChannel || !fs.existsSync(file)) return false;
  const state = playerState(message.guild.id);
  const previousTextChannel = state.textChannel;
  await ensureVoice(message, state);
  // Keep soundboard commands silent and preserve the music announcement channel.
  state.textChannel = previousTextChannel;
  const settings = getSettings(message.guild.id);
  const capacity = Math.max(1, Math.min(MAX_QUEUE, Number(settings.queueLimit) || MAX_QUEUE));
  if (state.queue.length + (state.current ? 1 : 0) + 1 > capacity) return false;
  state.queue.push({ type: 'sound', file, title: String(name || 'Sound').slice(0, 100), url: '', duration: 0, author: 'Nexus Soundboard', requesterId: message.author.id, requesterTag: message.author.tag || message.author.username, addedAt: Date.now() });
  clearIdleTimer(state);
  if (!state.current || state.player.state.status === AudioPlayerStatus.Idle) setImmediate(() => advance(state).catch(error => console.error(`[music:${state.guildId}] sound queue: ${error.message}`)));
  return true;
}

module.exports = { initialize, handleCommand, handleInteraction, getSettings, saveSettings, enqueueSound };
