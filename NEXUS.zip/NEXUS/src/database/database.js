const fs = require('node:fs');
const path = require('node:path');
const Database = require('better-sqlite3');

const dbDir = path.join(__dirname, '..', '..', 'data');
fs.mkdirSync(dbDir, { recursive: true });
const dbPath = path.join(dbDir, 'nexus.db');
const db = new Database(dbPath);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

function initSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS guild_security (
      guild_id TEXT PRIMARY KEY,
      enabled INTEGER NOT NULL DEFAULT 0,
      response_mode TEXT NOT NULL DEFAULT 'alert',
      security_log_channel TEXT,
      thresholds TEXT NOT NULL DEFAULT '{}',
      trusted_users TEXT NOT NULL DEFAULT '[]',
      trusted_roles TEXT NOT NULL DEFAULT '[]',
      allowlist TEXT NOT NULL DEFAULT '[]',
      lockdown_state TEXT NOT NULL DEFAULT '{}',
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS incidents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      type TEXT NOT NULL,
      summary TEXT NOT NULL,
      details TEXT,
      executor_id TEXT,
      target_id TEXT,
      severity TEXT NOT NULL DEFAULT 'medium',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS security_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      event_type TEXT NOT NULL,
      payload TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS lockdown_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      actor_id TEXT NOT NULL,
      action TEXT NOT NULL,
      resources TEXT,
      snapshot TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS auth_roles (
      guild_id TEXT NOT NULL,
      role_id TEXT NOT NULL,
      PRIMARY KEY (guild_id, role_id)
    );

    CREATE TABLE IF NOT EXISTS bot_admins (
      user_id TEXT PRIMARY KEY,
      added_by TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE INDEX IF NOT EXISTS idx_incidents_guild ON incidents(guild_id);
    CREATE INDEX IF NOT EXISTS idx_security_events_guild ON security_events(guild_id);
    CREATE INDEX IF NOT EXISTS idx_lockdown_history_guild ON lockdown_history(guild_id);
  `);
}

initSchema();

function parseJson(value, fallback) {
  if (!value) return fallback;
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function toJson(value) {
  return JSON.stringify(value ?? {});
}

function ensureDatabase() {
  initSchema();
  return db;
}

function getGuildSecurity(guildId) {
  const row = db.prepare('SELECT * FROM guild_security WHERE guild_id = ?').get(guildId) || null;
  if (!row) {
    return {
      guild_id: guildId,
      enabled: 0,
      response_mode: 'alert',
      security_log_channel: null,
      thresholds: {
        channel_delete: 3,
        channel_create: 8,
        role_delete: 3,
        member_ban: 4,
        member_kick: 8,
        webhook_create: 1,
      },
      trusted_users: [],
      trusted_roles: [],
      allowlist: [],
      lockdown_state: {},
      updated_at: null,
      created_at: null,
    };
  }

  return {
    guild_id: guildId,
    enabled: Number(row.enabled) === 1 ? 1 : 0,
    response_mode: row.response_mode === 'contain' ? 'contain' : 'alert',
    security_log_channel: row.security_log_channel || null,
    thresholds: parseJson(row.thresholds, {
      channel_delete: 3,
      channel_create: 8,
      role_delete: 3,
      member_ban: 4,
      member_kick: 8,
      webhook_create: 1,
    }),
    trusted_users: Array.isArray(parseJson(row.trusted_users, [])) ? parseJson(row.trusted_users, []) : [],
    trusted_roles: Array.isArray(parseJson(row.trusted_roles, [])) ? parseJson(row.trusted_roles, []) : [],
    allowlist: Array.isArray(parseJson(row.allowlist, [])) ? parseJson(row.allowlist, []) : [],
    lockdown_state: parseJson(row.lockdown_state, {}),
    updated_at: row.updated_at,
    created_at: row.created_at,
  };
}

function upsertGuildSecurity(guildId, data = {}) {
  const existing = getGuildSecurity(guildId);
  const merged = {
    ...existing,
    ...data,
    thresholds: { ...existing.thresholds, ...(data.thresholds || {}) },
    trusted_users: Array.isArray(data.trusted_users) ? data.trusted_users : existing.trusted_users,
    trusted_roles: Array.isArray(data.trusted_roles) ? data.trusted_roles : existing.trusted_roles,
    allowlist: Array.isArray(data.allowlist) ? data.allowlist : existing.allowlist,
    lockdown_state: { ...existing.lockdown_state, ...(data.lockdown_state || {}) },
  };

  db.prepare(`
    INSERT INTO guild_security (
      guild_id, enabled, response_mode, security_log_channel, thresholds, trusted_users, trusted_roles, allowlist, lockdown_state, updated_at, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    ON CONFLICT(guild_id) DO UPDATE SET
      enabled = excluded.enabled,
      response_mode = excluded.response_mode,
      security_log_channel = excluded.security_log_channel,
      thresholds = excluded.thresholds,
      trusted_users = excluded.trusted_users,
      trusted_roles = excluded.trusted_roles,
      allowlist = excluded.allowlist,
      lockdown_state = excluded.lockdown_state,
      updated_at = CURRENT_TIMESTAMP
  `).run(
    guildId,
    Number(merged.enabled) || 0,
    merged.response_mode || 'alert',
    merged.security_log_channel || null,
    toJson(merged.thresholds),
    toJson(merged.trusted_users),
    toJson(merged.trusted_roles),
    toJson(merged.allowlist),
    toJson(merged.lockdown_state)
  );

  return getGuildSecurity(guildId);
}

function addIncident({ guild_id, type, summary, details, executor_id, target_id, severity = 'medium' }) {
  db.prepare(`
    INSERT INTO incidents (guild_id, type, summary, details, executor_id, target_id, severity)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(guild_id, type, summary, details ? JSON.stringify(details) : null, executor_id || null, target_id || null, severity);

  return getIncidents(guild_id).slice(-1)[0] || null;
}

function getIncidents(guildId, limit = 50) {
  return db.prepare('SELECT * FROM incidents WHERE guild_id = ? ORDER BY id DESC LIMIT ?').all(guildId, limit);
}

function listAllowlistEntries(guildId) {
  const cfg = getGuildSecurity(guildId);
  return Array.isArray(cfg.allowlist) ? cfg.allowlist : [];
}

function addAllowlistEntry(guildId, value) {
  const cfg = getGuildSecurity(guildId);
  const list = Array.isArray(cfg.allowlist) ? [...cfg.allowlist] : [];
  if (!list.includes(value)) list.push(value);
  upsertGuildSecurity(guildId, { allowlist: list });
  return list;
}

function removeAllowlistEntry(guildId, value) {
  const cfg = getGuildSecurity(guildId);
  const list = (Array.isArray(cfg.allowlist) ? cfg.allowlist : []).filter(item => item !== value);
  upsertGuildSecurity(guildId, { allowlist: list });
  return list;
}

function logSecurityEvent(guildId, eventType, payload = {}) {
  db.prepare(`INSERT INTO security_events (guild_id, event_type, payload) VALUES (?, ?, ? )`).run(guildId, eventType, JSON.stringify(payload));
}

function addLockdownRecord(guildId, actorId, action, resources = [], snapshot = {}) {
  db.prepare(`INSERT INTO lockdown_history (guild_id, actor_id, action, resources, snapshot) VALUES (?, ?, ?, ?, ?)`).run(
    guildId,
    actorId,
    action,
    JSON.stringify(resources),
    JSON.stringify(snapshot)
  );
}

function isBotAdmin(userId) {
  const row = db.prepare('SELECT 1 FROM bot_admins WHERE user_id = ?').get(userId);
  return Boolean(row);
}

function addBotAdmin(userId, addedBy = null) {
  db.prepare('INSERT OR IGNORE INTO bot_admins (user_id, added_by) VALUES (?, ?)').run(userId, addedBy);
}

module.exports = {
  db,
  ensureDatabase,
  getGuildSecurity,
  upsertGuildSecurity,
  addIncident,
  getIncidents,
  listAllowlistEntries,
  addAllowlistEntry,
  removeAllowlistEntry,
  logSecurityEvent,
  addLockdownRecord,
  isBotAdmin,
  addBotAdmin,
};
