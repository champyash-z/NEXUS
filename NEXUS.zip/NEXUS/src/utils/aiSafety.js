const fs = require('node:fs');
const path = require('node:path');
const { PermissionFlagsBits } = require('discord.js');
const { addWarning } = require('./warnings');
const { logModEvent } = require('./modlog');
const { getGuildSecurity } = require('../database/database');
const file = path.join(__dirname, '..', '..', 'data', 'ai-mod.json');
const bansFile = path.join(__dirname, '..', '..', 'data', 'ai-mod-bans.json');
const DEFAULT_WORDS = [
  'fuck', 'fucking', 'motherfucker', 'shit', 'bullshit', 'bitch', 'bastard', 'asshole', 'dumbass', 'son of a bitch', 'cunt', 'dickhead', 'piss off', 'retard',
  'chutiya', 'chutiye', 'gandu', 'gaand', 'madarchod', 'behenchod', 'bhenchod', 'bhosdike', 'bsdk', 'randi', 'harami', 'lodu', 'laude', 'gaand mein', 'teri maa', 'teri behen'
];
const FUNNY_WARNINGS = [
  '🚨 **Bad boy!** Language like that again and I’m calling your mom! 📞😤',
  '🐾 **Caught in 4K!** Please reboot your manners before your mom hears about this. 😂',
  '📢 **AI MOD ALERT:** Your keyboard has been grounded. Keep it respectful! 😼'
];
function readJson(p, fallback) { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return fallback; } }
function writeJson(p, value) { fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, JSON.stringify(value, null, 2)); }
let store = readJson(file, {});
let activeBans = readJson(bansFile, {});
function getConfig(guildId) {
  const cfg = store[guildId] || { enabled: false, words: [...DEFAULT_WORDS], mutedChannels: [], bypassUsers: [] };
  cfg.words = Array.isArray(cfg.words) ? cfg.words : [...DEFAULT_WORDS];
  cfg.mutedChannels = Array.isArray(cfg.mutedChannels) ? cfg.mutedChannels : [];
  cfg.bypassUsers = Array.isArray(cfg.bypassUsers) ? cfg.bypassUsers : [];
  return cfg;
}
function setConfig(guildId, patch) { store[guildId] = { ...getConfig(guildId), ...patch }; writeJson(file, store); return store[guildId]; }
function normalize(s) { return String(s || '').normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ').trim(); }
function hasBlockedWord(content, words) {
  const text = normalize(content);
  if (!text) return false;
  return words.some(word => {
    const term = normalize(word); if (!term) return false;
    const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s+');
    return new RegExp(`(^|\\s)${escaped}($|\\s)`, 'iu').test(text);
  });
}
function isSecurityBypassed(message, cfg) {
  // Respect both AI MOD's own bypass list and Nexus security trusted/allowlist users and roles.
  if (cfg.bypassUsers.includes(message.author.id)) return true;
  const member = message.member;
  if (!member) return false;
  let security = {};
  try { security = getGuildSecurity(message.guild.id) || {}; }
  catch (error) { console.error(`[ai-mod] Could not read security bypass configuration: ${error.message}`); }
  const trustedUsers = Array.isArray(security.trusted_users) ? security.trusted_users : [];
  const allowlist = Array.isArray(security.allowlist) ? security.allowlist : [];
  const trustedRoles = Array.isArray(security.trusted_roles) ? security.trusted_roles : [];
  return trustedUsers.includes(member.id) || allowlist.includes(member.id) ||
    member.roles.cache.some(role => trustedRoles.includes(role.id));
}
function isBypassed(message, cfg) {
  // Only explicit bypass configuration exempts a member. Server ownership and
  // moderation permissions do not bypass AI MOD; owners/admins are moderated
  // exactly like other members unless they match the configured bypass system.
  return isSecurityBypassed(message, cfg);
}
async function processExpiry(client) {
  const now = Date.now();
  for (const [key, record] of Object.entries(activeBans)) {
    if (record.expiresAt > now) continue;
    const [guildId, userId] = key.split(':');
    const guild = client.guilds.cache.get(guildId);
    if (guild) await guild.members.unban(userId, 'AI MOD temporary ban expired').catch(() => {});
    delete activeBans[key]; writeJson(bansFile, activeBans);
  }
}
async function handleSafetyMessage(message, client) {
  if (!message.guild || message.author.bot || message.webhookId) return false;
  const cfg = getConfig(message.guild.id);
  if (!cfg.enabled || cfg.mutedChannels.includes(message.channel.id) || !hasBlockedWord(message.content, cfg.words)) return false;
  // No server-owner exemption: only explicit configured bypasses skip moderation.
  if (isBypassed(message, cfg)) return false;
  let deleted = false;
  if (message.deletable) {
    try { await message.delete(); deleted = true; }
    catch (err) { console.error(`[ai-mod] Delete failed in guild ${message.guild.id}, channel ${message.channel.id}: ${err.message}`); }
  }
  if (!deleted) {
    console.error(`[ai-mod] Could not delete a blocked message. Ensure the bot has Manage Messages permission and its role can access this channel.`);
    await message.channel.send('⚠️ AI MOD detected a blocked word, but I could not remove the message. Please give me **Manage Messages** permission in this channel.').catch(() => {});
    return true;
  }
  const warnings = addWarning(message.guild.id, message.author.id, { reason: 'AI MOD: blocked word detected', moderatorId: client.user.id, createdAt: new Date().toISOString() });
  const count = warnings.length;
  await message.channel.send(`${FUNNY_WARNINGS[Math.floor(Math.random() * FUNNY_WARNINGS.length)]}\n⚠️ <@${message.author.id}> warning **${count}** recorded. (Bots and explicitly configured bypass members are exempt.)`).catch(() => {});
  await logModEvent(client, message.guild.id, { title: 'AI MOD • Message Removed', description: `A message from ${message.author.tag} was removed for a blocked word in <#${message.channel.id}>.`, color: 0xef4444, fields: [{ name: 'User', value: `${message.author.tag} (${message.author.id})`, inline: true }, { name: 'Warning count', value: String(count), inline: true }, { name: 'Channel', value: `<#${message.channel.id}>`, inline: true }] }).catch(() => {});
  // At each 3-warning threshold, apply an escalating temporary ban: 24h, 48h, 72h, ...
  if (count >= 3 && count % 3 === 0) {
    const hours = 24 * (count / 3);
    const member = await message.guild.members.fetch(message.author.id).catch(() => null);
    if (member?.bannable) {
      const key = `${message.guild.id}:${message.author.id}`;
      try {
        await message.guild.members.ban(message.author.id, { reason: `AI MOD: ${count} warnings; temporary ${hours}h ban` });
        activeBans[key] = { guildId: message.guild.id, userId: message.author.id, expiresAt: Date.now() + hours * 3600000 };
        writeJson(bansFile, activeBans);
        await logModEvent(client, message.guild.id, { title: 'AI MOD • Temporary Ban', description: `${message.author.tag} was temporarily banned for ${hours} hours after ${count} warnings.`, color: 0x991b1b, fields: [{ name: 'User ID', value: message.author.id }, { name: 'Duration', value: `${hours} hours` }, { name: 'Expires', value: new Date(activeBans[key].expiresAt).toISOString() }] }).catch(() => {});
        await message.channel.send(`⛔ <@${message.author.id}> reached ${count} warnings and has been temporarily banned for **${hours} hours**. The ban will be lifted automatically.`).catch(() => {});
      } catch (error) { console.error(`[ai-mod] Auto-ban failed: ${error.message}`); }
    } else {
      await message.channel.send(`⚠️ <@${message.author.id}> reached ${count} warnings, but I cannot ban them. Check my **Ban Members** permission and role position.`).catch(() => {});
    }
  }
  return true;
}
function authorized(message) { return Boolean(message.guild?.ownerId === message.author.id || message.member?.permissions?.has(PermissionFlagsBits.Administrator) || message.member?.permissions?.has(PermissionFlagsBits.ManageGuild)); }
async function handleSafetyCommand(message, args = []) {
  if (!message.guild) return message.reply('AI MOD can only be configured in a server.');
  if (!authorized(message)) return message.reply('Administrator or Manage Server permission is required to configure AI MOD.');
  const sub = String(args[0] || 'help').toLowerCase();
  const cfg = getConfig(message.guild.id);
  if (sub === 'help') return message.reply('**AI MOD prefix commands**\n`!ai mod enable` / `disable` — server-wide chat moderation\n`!ai mod add words word1, word2` — add blocked words\n`!ai mod words` — show count\n`!ai mod mute [#channel]` / `unmute [#channel]` — pause/resume in one channel\n`!ai mod bypass add @user` / `remove @user` / `list` — exempt users\n`!ai mod status` / `reset`\nAll commands also work with `.` and `?`. Legacy `ai safety` aliases still work.');
  if (sub === 'status') return message.reply(`🛡️ **AI MOD:** ${cfg.enabled ? 'ENABLED' : 'DISABLED'}\nBlocked words/phrases: **${cfg.words.length}**\nMuted channels: ${cfg.mutedChannels.map(id => `<#${id}>`).join(', ') || 'None'}\nBypass users: **${cfg.bypassUsers.length}**`);
  if (['enable', 'on'].includes(sub)) { setConfig(message.guild.id, { enabled: true }); return message.reply('🛡️ **AI MOD enabled server-wide.** I will moderate new text messages in the server, except muted channels and bypass users.'); }
  if (['disable', 'off'].includes(sub)) { setConfig(message.guild.id, { enabled: false }); return message.reply('🔕 **AI MOD disabled** for this server.'); }
  if (sub === 'reset') { setConfig(message.guild.id, { words: [...DEFAULT_WORDS] }); return message.reply(`Restored the built-in list of ${DEFAULT_WORDS.length} blocked words. Enable state unchanged.`); }
  if (sub === 'words') return message.reply(`AI MOD currently has **${cfg.words.length}** blocked words/phrases. Add more with !ai mod add words word1, word2.`);
  if (sub === 'add' && String(args[1] || '').toLowerCase() === 'words') {
    const raw = message.content.replace(/^[!.?]ai\s+(?:mod|safety)\s+add\s+words\s*/i, '');
    const additions = raw.split(/[,;\n]+/).map(x => normalize(x).slice(0, 80)).filter(x => x.length >= 2);
    const words = [...new Set([...cfg.words, ...additions])].slice(0, 500);
    if (!additions.length) return message.reply('Usage: `!ai mod add words word1, word2, phrase here`');
    setConfig(message.guild.id, { words });
    return message.reply(`✅ Added **${words.length - cfg.words.length}** new blocked word/phrase(s). Total: **${words.length}**.`);
  }
  if (sub === 'mute' || sub === 'unmute') {
    const channel = message.mentions.channels.first() || message.guild.channels.cache.get(String(args[1] || '').replace(/[<#>]/g, '')) || message.channel;
    const muted = new Set(cfg.mutedChannels);
    if (sub === 'mute') muted.add(channel.id); else muted.delete(channel.id);
    setConfig(message.guild.id, { mutedChannels: [...muted] });
    return message.reply(sub === 'mute' ? `🔇 AI MOD is now muted in ${channel}. Other channels are unaffected.` : `🔊 AI MOD is active in ${channel} again.`);
  }
  if (sub === 'bypass') {
    const action = String(args[1] || 'list').toLowerCase();
    if (action === 'list') return message.reply(`AI MOD bypass users: ${cfg.bypassUsers.map(id => `<@${id}>`).join(', ') || 'None'}`);
    const id = String(args[2] || '').replace(/[<@!>]/g, '');
    if (!/^\d{17,20}$/.test(id)) return message.reply('Usage: `!ai mod bypass add|remove @user` or `!ai mod bypass list`');
    const users = new Set(cfg.bypassUsers);
    if (action === 'add') users.add(id); else if (action === 'remove') users.delete(id); else return message.reply('Use `add`, `remove`, or `list`.');
    setConfig(message.guild.id, { bypassUsers: [...users] });
    return message.reply(action === 'add' ? `🛡️ <@${id}> is now exempt from AI MOD.` : `AI MOD bypass removed for <@${id}>.`);
  }
  return message.reply('Unknown AI MOD command. Use `!ai mod help` (or `.ai mod help` / `?ai mod help`).');
}
module.exports = { handleSafetyMessage, handleSafetyCommand, getSafetyConfig: getConfig, hasBlockedWord, processExpiry };
