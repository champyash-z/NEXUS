const fs = require('node:fs');
const path = require('node:path');
const { ChannelType, PermissionFlagsBits, ButtonBuilder, ButtonStyle, ActionRowBuilder, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { getGuildConfig } = require('./config');
const { db } = require('../database/database');

const dataDir = path.join(__dirname, '..', '..', 'data');
const legacyPath = path.join(dataDir, 'tickets.json');
const transcriptDir = path.join(dataDir, 'transcripts');
fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(transcriptDir, { recursive: true });

db.exec(`
 CREATE TABLE IF NOT EXISTS tickets (
  ticket_id TEXT PRIMARY KEY, guild_id TEXT NOT NULL, channel_id TEXT NOT NULL UNIQUE,
  owner_id TEXT NOT NULL, subject TEXT NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT 'Support', priority TEXT NOT NULL DEFAULT 'Normal', status TEXT NOT NULL DEFAULT 'open',
  staff_role_id TEXT, claimed_by TEXT, claimed_at INTEGER, created_at INTEGER NOT NULL,
  closed_at INTEGER, closed_by TEXT, close_reason TEXT, closure_report_state TEXT NOT NULL DEFAULT 'pending',
  dm_error TEXT, transcript_path TEXT, message_count INTEGER NOT NULL DEFAULT 0,
  user_message_count INTEGER NOT NULL DEFAULT 0, staff_message_count INTEGER NOT NULL DEFAULT 0,
  attachment_count INTEGER NOT NULL DEFAULT 0, last_staff_response_at INTEGER, first_staff_response_at INTEGER,
  last_activity_at INTEGER NOT NULL DEFAULT 0, close_requested_at INTEGER, auto_close_warned_at INTEGER
 );
 CREATE TABLE IF NOT EXISTS ticket_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id TEXT NOT NULL, event_type TEXT NOT NULL,
  actor_id TEXT, details TEXT, created_at INTEGER NOT NULL
 );
 CREATE TABLE IF NOT EXISTS ticket_ratings (
  ticket_id TEXT PRIMARY KEY, guild_id TEXT NOT NULL, user_id TEXT NOT NULL, rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
  comment TEXT, submitted_at INTEGER NOT NULL, claimed_by TEXT, closed_at INTEGER
 );
 CREATE INDEX IF NOT EXISTS idx_tickets_guild_status ON tickets(guild_id, status);
 CREATE INDEX IF NOT EXISTS idx_ticket_events_ticket ON ticket_events(ticket_id, created_at);
`);
// Safe additive migrations for existing Nexus databases.
for (const [column, definition] of [['last_activity_at', 'INTEGER NOT NULL DEFAULT 0'], ['close_requested_at', 'INTEGER'], ['auto_close_warned_at', 'INTEGER']]) {
 try { db.exec(`ALTER TABLE tickets ADD COLUMN ${column} ${definition}`); } catch (error) { if (!String(error.message).includes('duplicate column')) throw error; }
}
try { db.exec('UPDATE tickets SET last_activity_at=created_at WHERE last_activity_at=0'); } catch {}

// One-time import of records from the previous JSON-backed ticket system.
try {
 if (fs.existsSync(legacyPath)) {
  const legacy = JSON.parse(fs.readFileSync(legacyPath, 'utf8') || '{}');
  const insert = db.prepare(`INSERT OR IGNORE INTO tickets (ticket_id,guild_id,channel_id,owner_id,subject,description,staff_role_id,claimed_by,status,created_at,category,priority) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`);
  const tx = db.transaction(() => {
   for (const [guildId, entries] of Object.entries(legacy)) for (const [channelId, t] of Object.entries(entries || {})) {
    insert.run(channelId, guildId, channelId, t.ownerId || 'unknown', t.subject || '', t.description || '', t.staffRoleId || null, t.claimedBy || null, t.status || 'open', t.createdAt || Date.now(), t.category || 'Support', t.priority || 'Normal');
   }
  }); tx();
 }
} catch (e) { console.error('[Tickets] Legacy JSON import skipped:', e.message); }

function getTicketRecord(guildId, channelId) {
 const row = db.prepare('SELECT * FROM tickets WHERE guild_id=? AND channel_id=?').get(guildId, channelId);
 if (!row) return null;
 return { ...row, ownerId: row.owner_id, channelId: row.channel_id, guildId: row.guild_id, staffRoleId: row.staff_role_id, claimedBy: row.claimed_by, createdAt: row.created_at, closedAt: row.closed_at, closedBy: row.closed_by, closeReason: row.close_reason };
}
function saveTicketRecord(guildId, channelId, record) {
 db.prepare(`INSERT INTO tickets (ticket_id,guild_id,channel_id,owner_id,subject,description,staff_role_id,claimed_by,status,created_at,category,priority,last_activity_at)
 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(channel_id) DO UPDATE SET subject=excluded.subject,description=excluded.description,staff_role_id=excluded.staff_role_id,claimed_by=excluded.claimed_by,status=excluded.status`)
 .run(String(record.ticketId || channelId), guildId, channelId, record.ownerId, record.subject || '', record.description || '', record.staffRoleId || null, record.claimedBy || null, record.status || 'open', record.createdAt || Date.now(), record.category || 'Support', record.priority || 'Normal', record.createdAt || Date.now());
}
function recordTicketActivity(channelId, actorId) {
 const ticket = db.prepare("SELECT status FROM tickets WHERE channel_id=?").get(channelId);
 if (!ticket || !['open','claimed'].includes(ticket.status)) return false;
 db.prepare('UPDATE tickets SET last_activity_at=?, close_requested_at=NULL, auto_close_warned_at=NULL WHERE channel_id=?').run(Date.now(), channelId);
 return true;
}
function addEvent(ticketId, type, actorId, details = {}) {
 db.prepare('INSERT INTO ticket_events(ticket_id,event_type,actor_id,details,created_at) VALUES(?,?,?,?,?)').run(String(ticketId), type, actorId || null, JSON.stringify(details), Date.now());
}
function buildTicketButtons() {
 return new ActionRowBuilder().addComponents(
  new ButtonBuilder().setCustomId('ticket_claim').setLabel('Claim Ticket').setStyle(ButtonStyle.Primary),
  new ButtonBuilder().setCustomId('ticket_close').setLabel('Close & Send Report').setStyle(ButtonStyle.Danger));
}
function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function formatDuration(ms) {
 const mins = Math.max(0, Math.floor(ms / 60000)); const days = Math.floor(mins / 1440); const hours = Math.floor((mins % 1440) / 60); const minutes = mins % 60;
 return [days ? `${days} day${days===1?'':'s'}` : '', hours ? `${hours} hour${hours===1?'':'s'}` : '', `${minutes} minute${minutes===1?'':'s'}`].filter(Boolean).join(', ');
}
function discordTime(ms) { return ms ? `<t:${Math.floor(ms / 1000)}:F> (<t:${Math.floor(ms / 1000)}:R>)` : 'Not recorded'; }
async function fetchAllMessages(channel) {
 const all = []; let before;
 for (let page = 0; page < 100; page++) {
  const batch = await channel.messages.fetch({ limit: 100, ...(before ? { before } : {}) }).catch(() => null);
  if (!batch || !batch.size) break;
  all.push(...batch.values()); before = batch.last().id;
  if (batch.size < 100) break;
 }
 return all.sort((a,b) => a.createdTimestamp - b.createdTimestamp);
}
function makeTranscript(channel, messages) {
 const body = messages.map(m => {
  const files = [...m.attachments.values()].map(a => `<li><a href="${escapeHtml(a.url)}">${escapeHtml(a.name || 'attachment')}</a></li>`).join('');
  const embeds = m.embeds.map(e => `<div class="embed"><b>${escapeHtml(e.title || 'Embed')}</b><p>${escapeHtml(e.description || '')}</p></div>`).join('');
  return `<article><header>${escapeHtml(m.author?.tag || 'Unknown user')} · ${escapeHtml(new Date(m.createdTimestamp).toISOString())}</header><p>${escapeHtml(m.content || '(no text content)').replace(/\n/g,'<br>')}</p>${files ? `<ul>${files}</ul>` : ''}${embeds}</article>`;
 }).join('\n');
 return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Ticket ${escapeHtml(channel.id)} transcript</title><style>body{font:15px Arial,sans-serif;background:#111827;color:#e5e7eb;max-width:1000px;margin:2rem auto;padding:0 1rem}h1{color:#a7f3d0}article{padding:1rem;margin:1rem 0;background:#1f2937;border-radius:8px;overflow-wrap:anywhere}header{color:#93c5fd;font-weight:bold;margin-bottom:.5rem}.embed{border-left:3px solid #818cf8;padding:.5rem 1rem}a{color:#93c5fd}</style></head><body><h1>Nexus Support — Ticket Transcript</h1><p>Channel: ${escapeHtml(channel.name)} (${escapeHtml(channel.id)}) · Exported: ${escapeHtml(new Date().toISOString())}</p>${body || '<p>No messages were accessible.</p>'}</body></html>`;
}
async function createTicketChannel({ guild, ownerId, subject, description, staffRoleId, category = 'Support' }) {
 const config = getGuildConfig(guild.id); const owner = await guild.members.fetch(ownerId).catch(() => null);
 const safeUser = (owner?.user?.username || 'user').toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-').slice(0, 45) || 'user';
 const active = db.prepare("SELECT channel_id FROM tickets WHERE guild_id=? AND owner_id=? AND status IN ('open','claimed','closing')").get(guild.id, ownerId);
 if (active) throw new Error(`You already have an active ticket: <#${active.channel_id}>`);
 const channel = await guild.channels.create({ name: `ticket-${safeUser}`.slice(0, 90), type: ChannelType.GuildText, parent: config.channels.ticketCategory || undefined,
  permissionOverwrites: [
   { id: guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
   ...(guild.members.me ? [{ id: guild.members.me.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.AttachFiles, PermissionFlagsBits.EmbedLinks] }] : []),
   { id: ownerId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] },
   ...(staffRoleId ? [{ id: staffRoleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] }] : [])
  ] });
 const record = { guildId:guild.id, channelId:channel.id, ownerId, subject, description, staffRoleId, createdAt:Date.now(), claimedBy:null, status:'open', category, priority:'Normal' };
 saveTicketRecord(guild.id, channel.id, record); addEvent(channel.id,'created',ownerId,{subject,category});
 const embed = new EmbedBuilder().setColor(0x7c3aed).setTitle(`Nexus Support · ${subject.slice(0,200)}`).setDescription(description.slice(0,4000) || 'No description provided.')
  .addFields({name:'Ticket ID',value:channel.id,inline:true},{name:'Category',value:category,inline:true},{name:'Status',value:'Open',inline:true},{name:'Created by',value:`<@${ownerId}>`,inline:true},{name:'Priority',value:'Normal',inline:true}).setTimestamp(new Date());
 await channel.send({ content:`<@${ownerId}>`, embeds:[embed], components:[buildTicketButtons()] }); return channel;
}

async function closeTicketAndTranscript(client, channel, actor = null, reason = 'Not provided') {
 if (!channel?.guild || !channel?.messages) return { ok:false, reason:'invalid-channel' };
 const existing = getTicketRecord(channel.guild.id, channel.id); if (!existing) return { ok:false, reason:'ticket-not-found' };
 // Conditional update makes duplicate button clicks/retries idempotent.
 const claim = db.prepare("UPDATE tickets SET status='closing', closed_by=?, close_reason=? WHERE channel_id=? AND status IN ('open','claimed')").run(actor?.id || null, reason || 'Not provided', channel.id);
 if (!claim.changes) return { ok:false, reason:'already-closing-or-closed' };
 const closedAt = Date.now(); addEvent(channel.id,'closing',actor?.id,{reason});
 const messages = await fetchAllMessages(channel);
 const ownerMessages = messages.filter(m => m.author?.id === existing.owner_id).length;
 const staffMessages = messages.filter(m => !m.author?.bot && m.author?.id !== existing.owner_id).length;
 const attachments = messages.reduce((n,m)=>n+m.attachments.size,0);
 const firstStaff = messages.find(m => !m.author?.bot && m.author?.id !== existing.owner_id)?.createdTimestamp || null;
 const transcriptPath = path.join(transcriptDir, `ticket-${channel.id}.html`);
 fs.writeFileSync(transcriptPath, makeTranscript(channel,messages), 'utf8');
 db.prepare(`UPDATE tickets SET status='closed',closed_at=?,message_count=?,user_message_count=?,staff_message_count=?,attachment_count=?,first_staff_response_at=?,last_staff_response_at=?,transcript_path=?,closure_report_state='pending' WHERE channel_id=?`)
  .run(closedAt,messages.length,ownerMessages,staffMessages,attachments,firstStaff,[...messages].reverse().find(m=>!m.author?.bot&&m.author?.id!==existing.owner_id)?.createdTimestamp||null,transcriptPath,channel.id);
 addEvent(channel.id,'closed',actor?.id,{reason,closedAt,messageCount:messages.length});
 const ticket = getTicketRecord(channel.guild.id, channel.id); const events = db.prepare('SELECT * FROM ticket_events WHERE ticket_id=? ORDER BY created_at').all(channel.id);
 const eventText = events.map(e=>`${e.event_type}: ${e.actor_id ? `<@${e.actor_id}>` : 'Not recorded'} (${discordTime(e.created_at)})`).join('\n').slice(0,1000) || 'Not recorded';
 const embed = new EmbedBuilder()
  .setColor(0x7c3aed)
  .setAuthor({ name: `${channel.guild.name} • Nexus Support`, iconURL: channel.guild.iconURL({ size: 128 }) || undefined })
  .setTitle('🎫 Ticket Closed Successfully')
  .setDescription('Thank you for contacting **Nexus Support**. Your ticket has been closed. Here is the saved report for your request.')
  .addFields(
   { name:'🧾 Ticket Details', value:`**Ticket ID**\n\`${channel.id}\`\n\n**Subject**\n${(ticket.subject||'Not provided').slice(0,180)}\n\n**Category**\n${ticket.category||'Not recorded'}\n\n**Priority**\n${ticket.priority||'Not recorded'}`, inline:true },
   { name:'👤 Request Information', value:`**Creator**\n<@${ticket.owner_id}> (\`${ticket.owner_id}\`)\n\n**Server**\n${channel.guild.name.slice(0,180)}\n\n**Channel**\n#${channel.name.replace(/^closed-/, '')}\n\n**Status**\n🟣 Closed`, inline:true },
   { name:'📝 Original Issue', value:(ticket.description||'Not provided').slice(0,1000) }
  )
  .setFooter({ text:'Nexus Support • Your feedback helps us improve' })
  .setTimestamp(new Date(closedAt));
 const detailsEmbed = new EmbedBuilder()
  .setColor(0x334155)
  .setTitle('📋 Closure Summary & Activity')
  .addFields(
   { name:'🕒 Timeline', value:`**Opened:** ${discordTime(ticket.created_at)}\n**Claimed:** ${ticket.claimed_at ? `${discordTime(ticket.claimed_at)} by <@${ticket.claimed_by}>` : 'Not assigned'}\n**First staff response:** ${discordTime(ticket.first_staff_response_at)}\n**Closed:** ${discordTime(closedAt)}\n**Total open time:** ${formatDuration(closedAt-ticket.created_at)}` },
   { name:'🛡️ Staff & Closure', value:`**Claimed by:** ${ticket.claimed_by?`<@${ticket.claimed_by}>`:'Not assigned'}\n**Closed by:** ${actor ? `<@${actor.id}>` : 'Not recorded'}\n**Reason:** ${(reason||'Not provided').slice(0,250)}\n**Recorded history:** ${eventText}` },
   { name:'📊 Recorded Activity', value:`**Messages:** ${messages.length}\n**Creator messages:** ${ownerMessages}\n**Other non-bot messages:** ${staffMessages}\n**Attachments:** ${attachments}\n**Resolution summary:** Not provided` }
  )
  .setFooter({ text:`Ticket ${channel.id} • Keep this report for your records` })
  .setTimestamp(new Date(closedAt));
 const surveyRow = new ActionRowBuilder().addComponents(...[
  ['1','Very Poor'],['2','Poor'],['3','Average'],['4','Good'],['5','Excellent']
 ].map(([rating,label])=>new ButtonBuilder().setCustomId(`ticket_rate_${channel.id}_${rating}`).setLabel(`⭐ ${rating} — ${label}`).setStyle(rating==='5'?ButtonStyle.Success:ButtonStyle.Secondary)));
 let dmSent=false; let dmError=null;
 try {
  const user = await client.users.fetch(ticket.owner_id);
  const transcriptSize = fs.statSync(transcriptPath).size;
  const transcriptFits = transcriptSize < 7_500_000;
  const files = transcriptFits ? [new AttachmentBuilder(transcriptPath,{name:`nexus-ticket-${channel.id}-transcript.html`})] : [];
  if (!transcriptFits) detailsEmbed.addFields({ name: '📎 Transcript', value: 'The transcript exceeded the direct-message attachment limit. It has been retained in the configured staff archive; contact support staff if you need a copy.' });
  await user.send({embeds:[embed, detailsEmbed],components:[surveyRow],files}); dmSent=true;
 } catch (e) { dmError=e.message; console.warn(`[Tickets] Closure DM failed for ticket ${channel.id}: ${e.message}`); }
 db.prepare('UPDATE tickets SET closure_report_state=?,dm_error=? WHERE channel_id=?').run(dmSent?'sent':'failed',dmError,channel.id);
 const config=getGuildConfig(channel.guild.id); const logId=config.channels?.tickets || config.channels?.modlog;
 if(logId){const log=channel.guild.channels.cache.get(logId)||await channel.guild.channels.fetch(logId).catch(()=>null); if(log?.isTextBased()) await log.send({content:`Ticket ${channel.id} closed by ${actor ? `<@${actor.id}>` : 'unknown staff'}. DM ${dmSent?'sent':'failed'}. Transcript: ${path.basename(transcriptPath)}`,files:[new AttachmentBuilder(transcriptPath,{name:path.basename(transcriptPath)})]}).catch(e=>console.warn('[Tickets] Staff log failed:',e.message));}
 // The transcript and staff log are saved, and the user has been sent the closure report
 // with the five-star survey buttons before the ticket channel is removed.
 await new Promise(resolve => setTimeout(resolve, 5000));
 await channel.delete('Ticket closed; transcript archived and closure DM attempted').catch(error => {
  console.warn(`[Tickets] Could not delete closed ticket channel ${channel.id}: ${error.message}`);
 });
 return {ok:true,dmSent,dmError,transcriptPath,ticketId:channel.id};
}

function saveTicketRating(ticketId, userId, rating, guildId) {
 const ticket = guildId ? db.prepare('SELECT * FROM tickets WHERE channel_id=? AND guild_id=?').get(ticketId,guildId) : db.prepare('SELECT * FROM tickets WHERE channel_id=?').get(ticketId);
 if(!ticket || ticket.owner_id!==userId || ticket.status!=='closed') return {ok:false,reason:'invalid-ticket'};
 try { db.prepare('INSERT INTO ticket_ratings(ticket_id,guild_id,user_id,rating,submitted_at,claimed_by,closed_at) VALUES(?,?,?,?,?,?,?)').run(ticketId,guildId,userId,rating,Date.now(),ticket.claimed_by,ticket.closed_at); return {ok:true}; }
 catch(e) { if(String(e.code).includes('CONSTRAINT')) return {ok:false,reason:'already-rated'}; throw e; }
}
module.exports = { readTickets:()=>({}), writeTickets:()=>{}, getTicketRecord, saveTicketRecord, buildTicketButtons, createTicketChannel, closeTicketAndTranscript, saveTicketRating, addEvent, recordTicketActivity, fetchAllMessages, makeTranscript, db };
