const fs = require('node:fs');
const path = require('node:path');
const { randomBytes, randomInt } = require('node:crypto');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const file = path.join(__dirname, '..', '..', 'data', 'onboarding.json');
const pendingChallenges = new Map();
function readAll() { try { const data = JSON.parse(fs.readFileSync(file, 'utf8')); return data && typeof data === 'object' ? data : {}; } catch { return {}; } }
function writeAll(data) { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, JSON.stringify(data, null, 2)); }
function getOnboarding(guildId) { const all = readAll(); return all[guildId] || { enabled: true, welcomeChannelId: null, welcomeMessage: 'Welcome {member} to **{server}**! You are member **#{count}**.', leaveChannelId: null, leaveMessage: '{member} left **{server}**.', dmEnabled: false, autoRoleId: null, verificationChannelId: null, verifiedRoleId: null, unverifiedRoleId: null, verificationEnabled: false, gateEnabled: false, gateSnapshot: [] }; }
function setOnboarding(guildId, patch) { const all = readAll(); all[guildId] = { ...getOnboarding(guildId), ...patch }; writeAll(all); return all[guildId]; }
function makeVerifyPanel(guild, cfg) {
  const embed = new EmbedBuilder().setColor(0x22c55e).setTitle('Welcome — verify to unlock the server')
    .setDescription('Press **Verify me** below and answer the short arithmetic check to receive access. Nexus will only assign the configured verification role; it will never ask for passwords, QR scans, or external account credentials.');
  const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`nexus_verify:${guild.id}`).setLabel('Verify me').setStyle(ButtonStyle.Success));
  return { embeds: [embed], components: [row], allowedMentions: { parse: [] } };
}
async function handleMemberJoin(member) {
  const cfg = getOnboarding(member.guild.id);
  if (cfg.verificationEnabled && cfg.unverifiedRoleId) {
    const role = member.guild.roles.cache.get(cfg.unverifiedRoleId) || await member.guild.roles.fetch(cfg.unverifiedRoleId).catch(() => null);
    if (role && member.manageable) await member.roles.add(role, 'Nexus onboarding: mark member unverified').catch(() => {});
  }
  if (cfg.autoRoleId && !cfg.verificationEnabled) {
    const role = member.guild.roles.cache.get(cfg.autoRoleId) || await member.guild.roles.fetch(cfg.autoRoleId).catch(() => null);
    if (role && member.manageable && member.guild.members.me?.permissions.has(PermissionFlagsBits.ManageRoles) && role.position < member.guild.members.me.roles.highest.position) {
      await member.roles.add(role, 'Nexus onboarding auto-role').catch(() => {});
    }
  }
  if (cfg.dmEnabled) {
    const dmText = String(cfg.welcomeMessage || '').replaceAll('{member}', member.user.username).replaceAll('{server}', member.guild.name).replaceAll('{count}', String(member.guild.memberCount)).slice(0, 1800);
    await member.send({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle(`Welcome to ${member.guild.name}!`).setDescription(dmText)] }).catch(() => {});
  }
  if (cfg.welcomeChannelId) {
    const channel = member.guild.channels.cache.get(cfg.welcomeChannelId) || await member.guild.channels.fetch(cfg.welcomeChannelId).catch(() => null);
    if (channel?.isTextBased()) {
      const content = String(cfg.welcomeMessage || '').replaceAll('{member}', `<@${member.id}>`).replaceAll('{server}', member.guild.name).replaceAll('{count}', String(member.guild.memberCount)).slice(0, 1800);
      await channel.send({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle('🎉 A new member has arrived!').setDescription(content).setThumbnail(member.user.displayAvatarURL({ size: 256 })).setFooter({ text: `Member #${member.guild.memberCount}` }).setTimestamp()], allowedMentions: { users: [member.id] } }).catch(() => {});
    }
  }
}

async function handleMemberLeave(member) {
  const cfg = getOnboarding(member.guild.id);
  if (!cfg.leaveChannelId) return;
  const channel = member.guild.channels.cache.get(cfg.leaveChannelId) || await member.guild.channels.fetch(cfg.leaveChannelId).catch(() => null);
  if (!channel?.isTextBased()) return;
  const text = String(cfg.leaveMessage || '{member} left {server}.').replaceAll('{member}', member.user.username).replaceAll('{server}', member.guild.name).replaceAll('{count}', String(member.guild.memberCount)).slice(0, 1800);
  await channel.send({ embeds: [new EmbedBuilder().setColor(0x64748b).setTitle('A member left').setDescription(text).setThumbnail(member.user.displayAvatarURL({ size: 256 })).setTimestamp()], allowedMentions: { parse: [] } }).catch(() => {});
}

async function applyVerificationGate(guild, cfg) {
  if (!cfg.verificationEnabled || !cfg.verifiedRoleId || !cfg.unverifiedRoleId || !cfg.verificationChannelId) throw new Error('Configure verification channel, verified role, and unverified role first.');
  if (cfg.gateEnabled) return { applied: false, reason: 'already_active' };
  const botMember = guild.members.me;
  const unverified = guild.roles.cache.get(cfg.unverifiedRoleId) || await guild.roles.fetch(cfg.unverifiedRoleId).catch(() => null);
  const verified = guild.roles.cache.get(cfg.verifiedRoleId) || await guild.roles.fetch(cfg.verifiedRoleId).catch(() => null);
  if (!unverified || !verified || !botMember?.permissions.has(PermissionFlagsBits.ManageRoles) || !botMember?.permissions.has(PermissionFlagsBits.ManageChannels) || unverified.position >= botMember.roles.highest.position || verified.position >= botMember.roles.highest.position) throw new Error('The bot needs Manage Roles and Manage Channels, and its highest role must be above both verification roles.');
  const channels = await guild.channels.fetch().catch(() => guild.channels.cache);
  const snapshot = []; let failed = 0;
  for (const channel of channels.values()) {
    if (!channel?.permissionOverwrites || channel.isThread?.()) continue;
    const previous = channel.permissionOverwrites.cache.get(unverified.id);
    snapshot.push({ channelId: channel.id, existed: Boolean(previous), allow: previous?.allow.bitfield.toString() || '0', deny: previous?.deny.bitfield.toString() || '0' });
    if (channel.id === cfg.verificationChannelId || channel.id === cfg.welcomeChannelId) {
      try { await channel.permissionOverwrites.edit(unverified, { ViewChannel: true, SendMessages: false, AddReactions: false }, { reason: 'Nexus verification gate: allow access to onboarding' }); } catch { failed++; }
    } else if (channel.isTextBased() || channel.isVoiceBased?.()) {
      try { await channel.permissionOverwrites.edit(unverified, { ViewChannel: false, SendMessages: false, AddReactions: false, Connect: false }, { reason: 'Nexus verification gate: restrict unverified members' }); } catch { failed++; }
    }
  }
  if (failed) {
    let rollbackFailed = 0;
    for (const saved of snapshot) {
      const channel = guild.channels.cache.get(saved.channelId); if (!channel?.permissionOverwrites) continue;
      try { if (!saved.existed) await channel.permissionOverwrites.delete(unverified.id, 'Rollback failed Nexus verification gate setup'); else await channel.permissionOverwrites.edit(unverified.id, { allow: BigInt(saved.allow), deny: BigInt(saved.deny) }, { reason: 'Rollback failed Nexus verification gate setup' }); } catch { rollbackFailed++; }
    }
    if (rollbackFailed) setOnboarding(guild.id, { gateEnabled: true, gateSnapshot: snapshot });
    throw new Error(`Discord rejected permission edits in ${failed} channel(s). ${rollbackFailed ? 'Rollback was incomplete; run !welcome gate disable to retry restoration.' : 'Changes were rolled back.'} Check bot permissions and try again.`);
  }
  setOnboarding(guild.id, { gateEnabled: true, gateSnapshot: snapshot });
  return { applied: true, count: snapshot.length };
}
async function removeVerificationGate(guild, cfg) {
  if (!cfg.gateEnabled || !Array.isArray(cfg.gateSnapshot)) return { restored: 0, failed: 0, reason: 'not_active' };
  let restored = 0, failed = 0;
  for (const saved of cfg.gateSnapshot) {
    const channel = guild.channels.cache.get(saved.channelId) || await guild.channels.fetch(saved.channelId).catch(() => null);
    if (!channel?.permissionOverwrites) continue;
    try {
      if (!saved.existed) await channel.permissionOverwrites.delete(cfg.unverifiedRoleId, 'Nexus verification gate disabled');
      else await channel.permissionOverwrites.edit(cfg.unverifiedRoleId, { allow: BigInt(saved.allow), deny: BigInt(saved.deny) }, { reason: 'Nexus verification gate disabled' });
      restored++;
    } catch { failed++; }
  }
  if (failed === 0) setOnboarding(guild.id, { gateEnabled: false, gateSnapshot: [] });
  return { restored, failed };
}

async function completeVerification(interaction, guildId, userId) {
  if (!interaction.guild || interaction.guild.id !== guildId || interaction.user.id !== userId) {
    await interaction.reply({ content: 'This verification challenge does not belong to you.', ephemeral: true }).catch(() => {}); return true;
  }
  const cfg = getOnboarding(guildId);
  if (!cfg.verificationEnabled || !cfg.verifiedRoleId) {
    await interaction.reply({ content: 'Verification is not configured yet. Please contact a server moderator.', ephemeral: true }); return true;
  }
  const member = await interaction.guild.members.fetch(userId).catch(() => null);
  if (!member) { await interaction.reply({ content: 'I could not find your server membership. Try again.', ephemeral: true }); return true; }
  const role = interaction.guild.roles.cache.get(cfg.verifiedRoleId) || await interaction.guild.roles.fetch(cfg.verifiedRoleId).catch(() => null);
  if (!role) { await interaction.reply({ content: 'The verification role no longer exists. Please contact a moderator.', ephemeral: true }); return true; }
  if (!interaction.guild.members.me?.permissions.has(PermissionFlagsBits.ManageRoles) || role.position >= interaction.guild.members.me.roles.highest.position) {
    await interaction.reply({ content: 'The bot cannot assign the verification role. Please ask an administrator to move the Nexus role above it and grant Manage Roles.', ephemeral: true }); return true;
  }
  try {
    await member.roles.add(role, 'Nexus arithmetic verification');
    if (cfg.unverifiedRoleId && cfg.unverifiedRoleId !== role.id) await member.roles.remove(cfg.unverifiedRoleId, 'Nexus verification completed').catch(() => {});
    await interaction.reply({ content: '✅ You are verified! Welcome to the server.', ephemeral: true });
  } catch (error) {
    await interaction.reply({ content: `Verification failed: ${error.message.slice(0, 180)}`, ephemeral: true }).catch(() => {});
  }
  return true;
}

async function handleVerifyButton(interaction) {
  if (interaction.isButton() && interaction.customId.startsWith('nexus_verify:')) {
    if (!interaction.guild || interaction.customId !== `nexus_verify:${interaction.guild.id}`) return false;
    const cfg = getOnboarding(interaction.guild.id);
    if (!cfg.verificationEnabled || !cfg.verifiedRoleId) {
      await interaction.reply({ content: 'Verification is not configured yet. Please contact a server moderator.', ephemeral: true }); return true;
    }
    const left = randomInt(2, 10), right = randomInt(2, 10), token = randomBytes(6).toString('hex');
    pendingChallenges.set(token, { guildId: interaction.guild.id, userId: interaction.user.id, answer: String(left + right), expiresAt: Date.now() + 120000 });
    const modal = new ModalBuilder().setCustomId(`nexus_verify_answer:${interaction.guild.id}:${interaction.user.id}:${token}`).setTitle('Quick verification');
    const answer = new TextInputBuilder().setCustomId('answer').setLabel(`What is ${left} + ${right}?`).setStyle(TextInputStyle.Short).setMinLength(1).setMaxLength(3).setRequired(true);
    modal.addComponents(new ActionRowBuilder().addComponents(answer));
    await interaction.showModal(modal); return true;
  }
  if (interaction.isModalSubmit() && interaction.customId.startsWith('nexus_verify_answer:')) {
    const [, guildId, userId, token] = interaction.customId.split(':');
    const challenge = pendingChallenges.get(token); pendingChallenges.delete(token);
    if (!challenge || challenge.expiresAt < Date.now() || challenge.guildId !== guildId || challenge.userId !== userId || interaction.user.id !== userId || interaction.guildId !== guildId) {
      await interaction.reply({ content: 'This verification challenge expired. Press Verify me and try again.', ephemeral: true }); return true;
    }
    if (String(interaction.fields.getTextInputValue('answer')).trim() !== challenge.answer) {
      await interaction.reply({ content: '❌ Incorrect answer. Press Verify me and try again.', ephemeral: true }); return true;
    }
    return completeVerification(interaction, guildId, userId);
  }
  return false;
}

module.exports = { getOnboarding, setOnboarding, handleMemberJoin, handleMemberLeave, makeVerifyPanel, handleVerifyButton, applyVerificationGate, removeVerificationGate };
