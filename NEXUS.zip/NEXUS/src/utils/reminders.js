const fs = require('node:fs');
const path = require('node:path');

const dataDir = path.join(__dirname, '..', '..', 'data');
const filePath = path.join(dataDir, 'reminders.json');

const durationMap = {
  s: 1000,
  m: 60 * 1000,
  h: 60 * 60 * 1000,
  d: 24 * 60 * 60 * 1000,
};

function ensureFile() {
  fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, '[]', 'utf8');
  }
}

function readReminders() {
  ensureFile();
  try {
    const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeReminders(list) {
  ensureFile();
  fs.writeFileSync(filePath, JSON.stringify(list, null, 2), 'utf8');
}

function parseDuration(raw) {
  const text = String(raw || '').trim().toLowerCase();
  const match = /^([0-9]+)(s|m|h|d)$/i.exec(text);
  if (!match) return null;
  const value = Number(match[1]);
  const unit = match[2].toLowerCase();
  return value * (durationMap[unit] || 1000);
}

function addReminder({ guildId, userId, message, duration }) {
  const reminders = readReminders();
  const id = `${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
  const ms = parseDuration(duration);
  const reminder = {
    id,
    guildId,
    userId,
    message,
    duration: String(duration),
    createdAt: Date.now(),
    dueAt: Date.now() + (ms || 0),
    sent: false,
  };
  reminders.push(reminder);
  writeReminders(reminders);
  return reminder;
}

function listReminders(guildId, userId) {
  return readReminders().filter(r => r.guildId === guildId && r.userId === userId);
}

function cancelReminder(reminderId) {
  const reminders = readReminders();
  const filtered = reminders.filter(r => r.id !== reminderId);
  writeReminders(filtered);
  return filtered.length !== reminders.length;
}

function getDueReminders() {
  const now = Date.now();
  return readReminders().filter(r => !r.sent && r.dueAt <= now);
}

async function resolveReminderUser(client, userId) {
  const cached = client?.users?.cache?.get(userId);
  if (cached) return cached;
  if (!client?.users?.fetch) return null;
  return client.users.fetch(userId).catch(() => null);
}

function markSent(reminderId) {
  const reminders = readReminders();
  const updated = reminders.map(r => r.id === reminderId ? { ...r, sent: true } : r);
  writeReminders(updated);
}

module.exports = {
  parseDuration,
  addReminder,
  listReminders,
  cancelReminder,
  getDueReminders,
  resolveReminderUser,
  markSent,
  readReminders,
  writeReminders,
};
