const fs = require('node:fs');
const path = require('node:path');

const dataDir = path.join(__dirname, '..', '..', 'data');
const filePath = path.join(dataDir, 'warnings.json');

function readAll() {
  fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, '{}', 'utf8');
  try { return JSON.parse(fs.readFileSync(filePath, 'utf8')); }
  catch { return {}; }
}
function writeAll(data) {
  fs.mkdirSync(dataDir, { recursive: true });
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
}
function getWarnings(guildId, userId) {
  const all = readAll();
  return all[guildId]?.[userId] || [];
}
function addWarning(guildId, userId, warning) {
  const all = readAll();
  all[guildId] ||= {};
  all[guildId][userId] ||= [];
  all[guildId][userId].push(warning);
  writeAll(all);
  return all[guildId][userId];
}
function clearWarnings(guildId, userId) {
  const all = readAll();
  const count = all[guildId]?.[userId]?.length || 0;
  if (all[guildId]) delete all[guildId][userId];
  writeAll(all);
  return count;
}
module.exports = { getWarnings, addWarning, clearWarnings };
