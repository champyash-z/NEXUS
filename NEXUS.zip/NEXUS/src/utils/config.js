const fs = require('node:fs');
const path = require('node:path');

const dataDir = path.join(__dirname, '..', '..', 'data');
const filePath = path.join(dataDir, 'config.json');

function defaultGuildConfig() {
  return {
    version: 1,
    modules: {
      moderation: true,
      automod: true,
      security: false,
      smartWelcome: true,
      departure: false,
      autoroles: false,
      reactionRoles: false,
      tickets: true,
      suggestions: true,
      levelingPlus: true,
      polls: true,
      giveaways: false,
      starboard: false,
      reminders: true,
      logging: true,
      customCommands: false,
      socialNotifications: false,
    },
    channels: {
      modlog: null,
      welcome: null,
      departure: null,
      suggestions: null,
      levelup: null,
      ticketCategory: null,
      announcements: null,
      giveaways: null,
      tickets: null,
    },
    roles: {
      moderator: [],
      admin: [],
      support: [],
      verified: [],
      trusted: [],
      automodExempt: [],
    },
    automod: {
      antispam: true,
      antiinvite: true,
      mentionLimit: 6,
      maxMessages: 7,
      maxIdentical: 3,
      heatLimit: 100,
      timeoutMinutes: 5,
      action: 'timeout',
      prohibitedWords: [],
      linkFilter: [],
      trustedRoles: [],
      exemptChannels: [],
      escalation: 'warn',
    },
    ticketStaffRoleId: null,
    onboarding: {
      active: false,
      step: 0,
      preset: 'custom',
      moduleList: [],
      startedBy: null,
      completed: false,
    },
  };
}

function ensureFile() {
  fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, '{}', 'utf8');
  }
}

function readConfig() {
  ensureFile();
  try {
    const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function writeConfig(data) {
  ensureFile();
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
}

function normalizeGuildConfig(raw = {}) {
  const base = defaultGuildConfig();
  const merged = {
    ...base,
    ...raw,
    modules: { ...base.modules, ...(raw.modules || {}) },
    channels: { ...base.channels, ...(raw.channels || {}) },
    roles: { ...base.roles, ...(raw.roles || {}) },
    automod: { ...base.automod, ...(raw.automod || {}) },
    onboarding: { ...base.onboarding, ...(raw.onboarding || {}) },
  };

  // Drop retired module identifiers so the old implementations cannot be re-enabled by stale config.
  delete merged.modules.antiraid;
  delete merged.modules.welcome;
  delete merged.modules.leveling;
  delete merged.welcome;
  if (Array.isArray(merged.onboarding.moduleList)) {
    const migrated = merged.onboarding.moduleList.map(key => ({ antiraid: 'security', welcome: 'smartWelcome', leveling: 'levelingPlus' }[key] || key));
    merged.onboarding.moduleList = [...new Set(migrated)];
  }
  if (!Array.isArray(merged.roles.moderator)) merged.roles.moderator = [];
  if (!Array.isArray(merged.roles.admin)) merged.roles.admin = [];
  if (!Array.isArray(merged.roles.support)) merged.roles.support = [];
  if (!Array.isArray(merged.roles.verified)) merged.roles.verified = [];
  if (!Array.isArray(merged.roles.trusted)) merged.roles.trusted = [];
  if (!Array.isArray(merged.roles.automodExempt)) merged.roles.automodExempt = [];
  if (!Array.isArray(merged.automod.prohibitedWords)) merged.automod.prohibitedWords = [];
  if (!Array.isArray(merged.automod.linkFilter)) merged.automod.linkFilter = [];
  if (!Array.isArray(merged.automod.trustedRoles)) merged.automod.trustedRoles = [];
  if (!Array.isArray(merged.automod.exemptChannels)) merged.automod.exemptChannels = [];
  return merged;
}

function getGuildConfig(guildId) {
  const config = readConfig();
  const guildConfig = config[guildId] || {};
  return normalizeGuildConfig(guildConfig);
}

function setGuildConfig(guildId, updates) {
  const config = readConfig();
  config[guildId] = normalizeGuildConfig({
    ...getGuildConfig(guildId),
    ...updates,
  });
  writeConfig(config);
  return config[guildId];
}

function setChannel(guildId, key, channelId) {
  const config = readConfig();
  const guild = normalizeGuildConfig(config[guildId] || {});
  guild.channels[key] = channelId || null;
  config[guildId] = guild;
  writeConfig(config);
  return guild;
}

function setAutomod(guildId, automodSettings) {
  const config = readConfig();
  const guild = normalizeGuildConfig(config[guildId] || {});
  guild.automod = { ...guild.automod, ...automodSettings };
  config[guildId] = guild;
  writeConfig(config);
  return guild;
}

function setTicketStaffRole(guildId, roleId) {
  const config = readConfig();
  const guild = normalizeGuildConfig(config[guildId] || {});
  guild.ticketStaffRoleId = roleId || null;
  config[guildId] = guild;
  writeConfig(config);
  return guild;
}

function updateSetupState(guildId, patch = {}) {
  const config = readConfig();
  const guild = normalizeGuildConfig(config[guildId] || {});
  guild.onboarding = {
    ...guild.onboarding,
    ...patch,
  };
  config[guildId] = guild;
  writeConfig(config);
  return guild.onboarding;
}

function resetGuildSetup(guildId) {
  const config = readConfig();
  const guild = normalizeGuildConfig(config[guildId] || {});
  guild.onboarding = { ...defaultGuildConfig().onboarding };
  config[guildId] = guild;
  writeConfig(config);
  return guild;
}

module.exports = {
  getGuildConfig,
  setGuildConfig,
  setChannel,
  setAutomod,
  setTicketStaffRole,
  updateSetupState,
  resetGuildSetup,
  defaultGuildConfig,
  normalizeGuildConfig,
  readConfig,
  writeConfig,
};
