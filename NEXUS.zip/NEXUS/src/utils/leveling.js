const fs = require('node:fs');
const path = require('node:path');
const dataDir = path.join(__dirname, '..', '..', 'data');
const filePath = path.join(dataDir, 'levels.json');
const configPath = path.join(dataDir, 'leveling-config.json');
const DEFAULT_CONFIG = {
  enabled: true, cooldownSeconds: 60, minXp: 15, maxXp: 25, minMessageLength: 3, ignoredChannels: [], ignoredRoles: [],
  rewards: {}, levelUpMessages: true, maxLevel: 0, firstPlaceRoleId: null, rankColor: '#8b5cf6', messageXpMode: 'random',
  reactionXpEnabled: false, reactionMinXp: 1, reactionMaxXp: 3, reactionCooldownSeconds: 300,
  reactionAwardAuthor: true, reactionAwardReactors: false,
  voiceXpEnabled: false, voiceXpPerInterval: 5, voiceCooldownSeconds: 180, voiceMinMembers: 2,
  antiAfkHours: 2, roleBoosts: {}, channelBoosts: {}, stackBoosts: true,
};
function ensureFile() { fs.mkdirSync(dataDir, { recursive: true }); if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, '{}', 'utf8'); }
function readLevels() { ensureFile(); try { const data = JSON.parse(fs.readFileSync(filePath, 'utf8')); return data && typeof data === 'object' ? data : {}; } catch { return {}; } }
function writeLevels(data) { ensureFile(); fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8'); }
function readLevelConfigs() { try { const data = JSON.parse(fs.readFileSync(configPath, 'utf8')); return data && typeof data === 'object' ? data : {}; } catch { return {}; } }
function getLevelConfig(guildId) {
  const all = readLevelConfigs(); const saved = all[guildId] || {};
  return { ...DEFAULT_CONFIG, ...saved,
    ignoredChannels: Array.isArray(saved.ignoredChannels) ? saved.ignoredChannels : [],
    ignoredRoles: Array.isArray(saved.ignoredRoles) ? saved.ignoredRoles : [],
    rewards: saved.rewards && typeof saved.rewards === 'object' ? saved.rewards : {},
    roleBoosts: saved.roleBoosts && typeof saved.roleBoosts === 'object' ? saved.roleBoosts : {},
    channelBoosts: saved.channelBoosts && typeof saved.channelBoosts === 'object' ? saved.channelBoosts : {},
  };
}
function setLevelConfig(guildId, patch) { fs.mkdirSync(dataDir, { recursive: true }); const all = readLevelConfigs(); all[guildId] = { ...getLevelConfig(guildId), ...patch }; fs.writeFileSync(configPath, JSON.stringify(all, null, 2), 'utf8'); return getLevelConfig(guildId); }
function getXpRequiredForLevel(level) { const n = Math.max(0, Number(level) || 0); return 5 * (n ** 2) + 50 * n + 100; }
function getLevelFromXp(xp) { if (!Number.isFinite(xp) || xp <= 0) return 0; return Math.max(0, Math.floor((Math.sqrt(20 * xp + 500) - 50) / 10)); }
function emptyUserData() { return { xp: 0, level: 0, lastMessageAt: 0, lastReactionAt: 0, lastVoiceXpAt: 0, totalMessages: 0, reactions: 0, voiceSeconds: 0, weeklyXp: 0, monthlyXp: 0, weekKey: '', monthKey: '' }; }
function getUserData(guildId, userId) { const data = readLevels(); const guild = data[guildId] || {}; return { ...emptyUserData(), ...(guild[userId] || {}) }; }
function setUserData(guildId, userId, userData) {
  const data = readLevels(); data[guildId] = data[guildId] || {}; const old = { ...emptyUserData(), ...(data[guildId][userId] || {}) };
  const merged = { ...old, ...userData };
  merged.xp = Math.max(0, Math.floor(Number(merged.xp) || 0)); merged.level = getLevelFromXp(merged.xp);
  for (const key of ['lastMessageAt','lastReactionAt','lastVoiceXpAt','totalMessages','reactions','voiceSeconds','weeklyXp','monthlyXp']) merged[key] = Math.max(0, Number(merged[key]) || 0);
  data[guildId][userId] = merged; writeLevels(data); return merged;
}
function isoWeekKey(date = new Date()) { const d = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate())); const day = d.getUTCDay() || 7; d.setUTCDate(d.getUTCDate() + 4 - day); const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1)); const week = Math.ceil((((d - yearStart) / 86400000) + 1) / 7); return `${d.getUTCFullYear()}-W${String(week).padStart(2, '0')}`; }
function monthKey(date = new Date()) { return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}`; }
function awardXp(guildId, userId, amount = null, now = Date.now(), context = {}) {
  const cfg = getLevelConfig(guildId); let current = getUserData(guildId, userId);
  if (!cfg.enabled) return { ignored: true, reason: 'disabled', ...current };
  if (context.channelId && cfg.ignoredChannels.includes(context.channelId)) return { ignored: true, reason: 'ignored_channel', ...current };
  if (context.roleIds?.some(id => cfg.ignoredRoles.includes(id))) return { ignored: true, reason: 'ignored_role', ...current };
  const source = context.source || 'message';
  if (source === 'reaction' && !cfg.reactionXpEnabled) return { ignored: true, reason: 'reaction_disabled', ...current };
  if (source === 'message' && String(context.messageContent || '').trim().length < Math.max(1, Number(cfg.minMessageLength) || 1)) return { ignored: true, reason: 'message_too_short', ...current };
  const week = isoWeekKey(new Date(now)), month = monthKey(new Date(now));
  if (current.weekKey !== week) { current.weekKey = week; current.weeklyXp = 0; }
  if (current.monthKey !== month) { current.monthKey = month; current.monthlyXp = 0; }
  if (source === 'voice' && Number(context.voiceSeconds) > 0) current.voiceSeconds += Number(context.voiceSeconds);
  if (source === 'reaction' && context.countReaction) current.reactions += 1;
  if (source === 'voice' && !cfg.voiceXpEnabled) { setUserData(guildId, userId, current); return { ignored: true, reason: 'voice_disabled', ...current }; }
  if (source === 'voice' && context.noXp) { setUserData(guildId, userId, current); return { ignored: true, reason: 'anti_afk', ...current }; }
  const lastKey = source === 'reaction' ? 'lastReactionAt' : source === 'voice' ? 'lastVoiceXpAt' : 'lastMessageAt';
  const cooldown = source === 'reaction' ? cfg.reactionCooldownSeconds : source === 'voice' ? cfg.voiceCooldownSeconds : cfg.cooldownSeconds;
  const cooldownMs = Math.max(0, Number(cooldown) || 0) * 1000;
  if (now - Number(current[lastKey] || 0) < cooldownMs) { setUserData(guildId, userId, current); return { ignored: true, reason: 'cooldown', ...current }; }
  let base;
  if (amount != null) base = Math.max(0, Math.floor(Number(amount) || 0));
  else if (source === 'reaction') base = Math.floor(Math.random() * (Math.max(cfg.reactionMinXp, cfg.reactionMaxXp) - Math.min(cfg.reactionMinXp, cfg.reactionMaxXp) + 1)) + Math.min(cfg.reactionMinXp, cfg.reactionMaxXp);
  else if (source === 'voice') base = Math.max(0, Math.floor(Number(cfg.voiceXpPerInterval) || 0));
  else if (cfg.messageXpMode === 'perword') base = Math.min(1000, String(context.messageContent || '').split(/\s+/).filter(w => w.replace(/[^a-z0-9]/gi, '').length >= 3).length * Math.max(1, Number(cfg.maxXp) || 1));
  else base = Math.floor(Math.random() * (Math.max(cfg.minXp, cfg.maxXp) - Math.min(cfg.minXp, cfg.maxXp) + 1)) + Math.min(cfg.minXp, cfg.maxXp);
  const roleMultipliers = (context.roleIds || []).map(id => Number(cfg.roleBoosts[id]) || 0).filter(n => n > 0);
  const channelBoost = Number(cfg.channelBoosts[context.channelId]) || 0;
  let multiplier = 1;
  if (cfg.stackBoosts) multiplier += roleMultipliers.reduce((sum, value) => sum + value, 0) / 100 + channelBoost / 100;
  else multiplier += Math.max(0, ...roleMultipliers, channelBoost) / 100;
  const gained = Math.max(0, Math.floor(base * multiplier));
  const previousLevel = getLevelFromXp(current.xp || 0);
  current.xp = (current.xp || 0) + gained; current.weeklyXp = (current.weeklyXp || 0) + gained; current.monthlyXp = (current.monthlyXp || 0) + gained;
  current[lastKey] = now;
  if (source === 'message') current.totalMessages = (current.totalMessages || 0) + 1;
  const nextLevel = getLevelFromXp(current.xp);
  if (cfg.maxLevel > 0 && nextLevel > cfg.maxLevel) { const capXp = getXpRequiredForLevel(cfg.maxLevel); current.xp = Math.min(current.xp, capXp); }
  const nextData = setUserData(guildId, userId, { ...current, xp: current.xp });
  return { ...nextData, ignored: false, leveledUp: nextData.level > previousLevel, previousLevel, gainedXp: gained, source };
}
function getGuildLeaderBoard(guildId, limit = 10, type = 'xp') {
  const data = readLevels(); const keyMap = { xp: 'xp', level: 'xp', weekly: 'weeklyXp', monthly: 'monthlyXp', reactions: 'reactions', voice: 'voiceSeconds', messages: 'totalMessages' };
  const key = keyMap[type] || 'xp';
  const week = isoWeekKey(), month = monthKey();
  return Object.entries(data[guildId] || {}).map(([userId, record]) => { const normalized = { ...emptyUserData(), ...record, userId, xp: Number(record.xp || 0), level: getLevelFromXp(Number(record.xp || 0)) }; if (normalized.weekKey !== week) normalized.weeklyXp = 0; if (normalized.monthKey !== month) normalized.monthlyXp = 0; return normalized; }).sort((a,b) => Number(b[key] || 0) - Number(a[key] || 0) || b.xp - a.xp).slice(0, Math.max(1, limit));
}
function getServerRank(guildId, userId, type = 'xp') { const board = getGuildLeaderBoard(guildId, Number.MAX_SAFE_INTEGER, type); const index = board.findIndex(entry => entry.userId === userId); return index >= 0 ? index + 1 : null; }
function getProgressBar(current, required, length = 20) { const ratio = required > 0 ? Math.min(Math.max(current / required, 0), 1) : 0; const filled = Math.round(length * ratio); return '[' + '█'.repeat(filled) + '░'.repeat(length - filled) + ']'; }
module.exports = { awardXp, getLevelFromXp, getUserData, setUserData, getGuildLeaderBoard, getServerRank, getProgressBar, getXpRequiredForLevel, readLevels, writeLevels, getLevelConfig, setLevelConfig, DEFAULT_CONFIG, isoWeekKey, monthKey };
