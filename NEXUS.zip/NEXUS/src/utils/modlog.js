const { EmbedBuilder } = require('discord.js');
const { getGuildConfig } = require('./config');

async function logModEvent(client, guildId, options = {}) {
  if (!guildId || !client) return;

  const config = getGuildConfig(guildId);
  const channelId = config.channels?.modlog;
  if (!channelId) return;

  const guild = client.guilds.cache.get(guildId) || await client.guilds.fetch(guildId).catch(() => null);
  if (!guild) return;

  const channel = guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId).catch(() => null);
  if (!channel || !channel.isTextBased()) return;

  const embed = new EmbedBuilder()
    .setTitle(options.title || 'Modlog Event')
    .setDescription(options.description || 'No details provided.')
    .setColor(options.color || 0x5865f2)
    .setTimestamp(new Date())
    .setFooter({ text: options.footer || 'Nexus Modlog' });

  if (Array.isArray(options.fields) && options.fields.length) {
    embed.addFields(options.fields);
  }

  await channel.send({ embeds: [embed] }).catch(() => {});
}

async function logMessageEvent(client, guildId, eventType, message) {
  if (!message || !guildId) return;
  const content = message.content ? message.content.slice(0, 900) : 'No content';
  const author = message.author ? `${message.author.tag} (${message.author.id})` : 'Unknown';
  await logModEvent(client, guildId, {
    title: `Message ${eventType}`,
    description: `A message was ${eventType.toLowerCase()} in <#${message.channel.id}>.`,
    color: eventType === 'Deleted' ? 0xef4444 : 0xf59e0b,
    fields: [
      { name: 'Author', value: author, inline: true },
      { name: 'Channel', value: `<#${message.channel.id}>`, inline: true },
      { name: 'Content', value: content || 'No content', inline: false },
    ],
  });
}

module.exports = { logModEvent, logMessageEvent };
