const fs = require('node:fs');
const path = require('node:path');

const DEFAULTS = {
  ownerUserId: process.env.OWNER_ID || '',
  nexusUserId: '',
  triggerAliases: ['champyash', 'yash', 'l'],
  nexusAliases: ['nexus'],
  portfolioKeywords: ['dev', 'developers', 'portfillo'],
  smpKeywords: ['rooi', 'smp', 'ip', 'server', 'minecraft'],
  urls: { portfolio: 'https://champyash.lovable.app', smp: 'https://rooismp.vercel.app' },
  features: { yash: true, nexus: true, portfolio: true, smp: true },
};
function loadConfig() {
  try {
    const filePath = path.join(__dirname, '..', '..', 'config.json');
    const parsed = JSON.parse(fs.existsSync(filePath) ? fs.readFileSync(filePath, 'utf8') : '{}');
    return { ...DEFAULTS, ...parsed, ownerUserId: String(parsed.ownerUserId || process.env.OWNER_ID || ''), nexusUserId: String(parsed.nexusUserId || ''), urls: { ...DEFAULTS.urls, ...(parsed.urls || {}) }, features: { ...DEFAULTS.features, ...(parsed.features || {}) } };
  } catch { return { ...DEFAULTS }; }
}
function normalizeText(value) { return String(value || '').normalize('NFKC').toLowerCase().replace(/[’']/g, "'").replace(/\s+/g, ' ').trim(); }
function escapeRegex(value) { return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function hasWordBoundaryMatch(content, keyword) {
  const word = normalizeText(keyword);
  if (!word) return false;
  return new RegExp(`(^|[^a-z0-9_])${escapeRegex(word)}($|[^a-z0-9_])`, 'i').test(normalizeText(content));
}
function hasAny(content, keywords) { return (keywords || []).some(k => hasWordBoundaryMatch(content, k)); }
function getSingleTriggerReply(content, message, configOverride = null) {
  const config = configOverride || loadConfig();
  const lower = normalizeText(content);
  if (!lower) return null;
  const ownerAlias = hasAny(lower, [...new Set([...(config.triggerAliases || [])])]);
  if (config.features.yash && ownerAlias) return { type: 'yash', sequence: [
    'He is dead! :smiling_face_with_tear:',
    `**✦ NEXAVORA — ENTER MY DIGITAL WORLD ✦**\nExplore my portfolio and creations:\n${config.urls.portfolio}`,
    `**⚔ ROOI SMP — YOUR NEXT ADVENTURE AWAITS ⚔**\nBuild your base, team up, and make your mark!\n${config.urls.smp}`,
  ] };

  const portfolioIntent = hasAny(lower, config.portfolioKeywords) || /\b(my|your)\s+(portfolio|projects|creations)\b/i.test(lower) || /\b(portfolio|nexavora)\b/i.test(lower);
  if (config.features.portfolio && portfolioIntent && !/^what is (a |the )?portfolio\??$/i.test(lower)) {
    return { type: 'portfolio', sequence: [`**✦ Check out Nexavora!**\nExplore my projects and creations:\n${config.urls.portfolio}`] };
  }
  const directRooi = hasAny(lower, ['rooi', 'rooi smp']);
  const smpContext = hasAny(lower, [...(config.smpKeywords || []), 'minecraft', 'survival server', 'smp ip', 'server website', 'join the server']) || (/\bserver\b/i.test(lower) && /\b(minecraft|survival|join|ip|smp)\b/i.test(lower));
  if (config.features.smp && (directRooi || smpContext)) {
    return { type: 'smp', sequence: [`**⚔ ROOI SMP — YOUR ADVENTURE STARTS HERE ⚔**\nBuild, survive, fight, and create your own story!\n${config.urls.smp}`] };
  }
  const botMention = Boolean(message?.client?.user?.id && message?.mentions?.users?.has(message.client.user.id));
  const nexusIdMention = Boolean(config.nexusUserId && message?.mentions?.users?.has(config.nexusUserId));
  if (config.features.nexus && (botMention || nexusIdMention || hasAny(lower, [...new Set([...(config.nexusAliases || []), 'nexus'])]))) {
    // Prefix commands are handled by the command router, not by this keyword response.
    return { type: 'nexus', sequence: ['Meow Ghop Ghop Ghop 🐱'] };
  }
  return null;
}
module.exports = { loadConfig, getSingleTriggerReply, hasWordBoundaryMatch, normalizeText };
