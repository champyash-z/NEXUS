const { PermissionFlagsBits } = require('discord.js');
const { getGuildConfig } = require('./config');
const { getGuildSecurity } = require('../database/database');
const { addWarning, getWarnings } = require('./warnings');
const { logModEvent } = require('./modlog');

// Per-member rolling activity. Heat cools over time so normal conversation is not punished.
const activity = new Map();
const activeIncidents = new Set();
const invitePattern = /(?:discord\.gg\/|discord(?:app)?\.com\/invite\/)/i;
const WARNING = '⚠️ Nexus AutoMod detected spam. Please slow down.';
const ABUSIVE_TERMS = ['fuck you', 'fucking idiot', 'motherfucker', 'bitch', 'asshole', 'dumbass', 'retard', 'chutiya', 'chutiye', 'gandu', 'gaand', 'madarchod', 'behenchod', 'bhenchod', 'bhosdike', 'bsdk', 'harami', 'kamina'];
const ABUSE_EXEMPT_CONTEXT = /\b(meaning of|define|definition|translate|translation|what does|quoted|educational)\b/i;
const MAX_TRACKED = 10000;
const MINUTE = 60_000;

function normalized(value) {
  return String(value || '').normalize('NFKC').toLowerCase()
    .replace(/https?:\/\/\S+/g, '<url>').replace(/[.,!?;:'"()[\]{}<>*_~`]/g, ' ')
    .replace(/\s+/g, ' ').trim();
}
function isModerator(member) {
  if (!member) return false;
  return member.permissions.has(PermissionFlagsBits.ManageMessages)
    || member.permissions.has(PermissionFlagsBits.ModerateMembers)
    || member.permissions.has(PermissionFlagsBits.KickMembers)
    || member.permissions.has(PermissionFlagsBits.BanMembers)
    || member.permissions.has(PermissionFlagsBits.Administrator);
}
function containsAbuse(content) {
  const text = normalized(content);
  if (!text || ABUSE_EXEMPT_CONTEXT.test(text)) return false;
  return ABUSIVE_TERMS.some(term => {
    const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s+');
    return new RegExp(`(^|\\s)${escaped}($|\\s)`, 'i').test(text);
  });
}
async function logFilterAction(message, client, reason) {
  if (message.deletable) await message.delete().catch(() => {});
  addWarning(message.guild.id, message.author.id, { reason: `Auto-moderation: ${reason}`, moderatorId: client.user.id, createdAt: new Date().toISOString() });
  await logModEvent(client, message.guild.id, {
    title: 'Nexus AutoMod • Content filter',
    description: `${message.author.tag} triggered ${reason} in <#${message.channel.id}>.`,
    color: 0xdc2626,
    fields: [{ name: 'User', value: `${message.author.tag} (${message.author.id})`, inline: true }, { name: 'Channel', value: `<#${message.channel.id}>`, inline: true }],
  });
  return true;
}
function countEmoji(text) {
  try { return [...String(text || '').matchAll(/\p{Extended_Pictographic}/gu)].length; }
  catch { return 0; }
}
function heatForMessage(message, previous, now = Date.now(), options = {}) {
  const content = normalized(message.content);
  const elapsed = previous.lastAt ? Math.max(0, now - previous.lastAt) : Infinity;
  const decay = previous.lastAt ? Math.max(0, (now - previous.lastAt) / 1000) * 4 : 0;
  let heat = Math.max(0, Number(previous.heat || 0) - decay) + 2;
  const windowMs = Math.max(3000, Math.min(120_000, Number(options.windowMs) || 10_000));
  const recent = (previous.messages || []).filter(item => now - item.at <= windowMs);
  const duplicates = content ? recent.filter(item => item.content === content).length : 0;
  if (elapsed < 1500) heat += 12;
  if (elapsed < 500) heat += 12;
  if (duplicates >= 1) heat += 42;
  if (duplicates >= 2) heat += 55;
  if (recent.length >= 4) heat += Math.min(25, (recent.length - 3) * 8);
  const mentions = (message.mentions?.users?.size || 0) + (message.mentions?.roles?.size || 0);
  if (mentions) heat += Math.min(30, mentions * 5);
  if (message.mentions?.everyone) heat += 35;
  const emojiCount = countEmoji(message.content);
  if (emojiCount > 5) heat += Math.min(15, (emojiCount - 5) * 1.5);
  const newlines = (String(message.content || '').match(/\n/g) || []).length;
  if (newlines > 5) heat += Math.min(12, newlines - 5);
  if (message.attachments?.size > 4) heat += 8;
  if (invitePattern.test(message.content || '')) heat += 45;
  return { heat, content, duplicates, recentCount: recent.length + 1, elapsed };
}
function exempt(message, config) {
  const member = message.member;
  if (!member || isModerator(member)) return true;
  if ((config.automod.exemptChannels || []).includes(message.channel.id)) return true;
  const security = getGuildSecurity(message.guild.id);
  if ((security.allowlist || []).includes(message.author.id) || (security.trusted_users || []).includes(message.author.id)) return true;
  const exemptRoles = [...(config.automod.trustedRoles || []), ...(config.roles.automodExempt || []), ...(security.trusted_roles || [])];
  return member.roles?.cache?.some(role => exemptRoles.includes(role.id)) || false;
}
function timeoutForViolation(baseMinutes, warnings) {
  const recent = warnings.filter(item => Date.now() - new Date(item.createdAt || 0).getTime() < 30 * 24 * 60 * MINUTE).length;
  const base = Math.max(1, Math.min(1440, Number(baseMinutes) || 5));
  return Math.min(28 * 24 * 60, base * (2 ** Math.min(recent, 5)));
}
async function deleteRecentSpam(message, userId, content) {
  if (message.deletable) await message.delete().catch(() => {});
  // Best-effort cleanup is deliberately bounded; Discord bulk delete cannot remove messages older than 14 days.
  const fetched = await message.channel.messages.fetch({ limit: 12 }).catch(() => null);
  if (!fetched) return;
  const matches = fetched.filter(item => item.id !== message.id && item.author?.id === userId
    && item.deletable && Date.now() - item.createdTimestamp < 10_000
    && normalized(item.content) === content);
  for (const item of matches.values()) await item.delete().catch(() => {});
}
async function handleAutomod(message, client) {
  if (!message.guild || message.author.bot || message.webhookId) return false;
  const config = getGuildConfig(message.guild.id);
  const automod = config.automod || {};
  if (exempt(message, config)) return false;
  if (automod.abuse_filter !== false && containsAbuse(message.content)) return logFilterAction(message, client, 'abusive-language filter');
  if (automod.antiinvite !== false && invitePattern.test(message.content || '')) return logFilterAction(message, client, 'invite-link filter');
  if (automod.antispam === false) return false;

  const now = Date.now();
  const key = `${message.guild.id}:${message.author.id}`;
  const previous = activity.get(key) || { heat: 0, lastAt: 0, messages: [], violations: 0 };
  const heatWindowMs = Math.max(3000, Math.min(120_000, Number(automod.heatWindowSeconds) || 10)) * 1000;
  const duplicateWindowMs = Math.max(3000, Math.min(120_000, Number(automod.duplicateWindowSeconds) || 10)) * 1000;
  const scored = heatForMessage(message, previous, now, { windowMs: duplicateWindowMs });
  const messages = [...(previous.messages || []).filter(item => now - item.at <= heatWindowMs), { at: now, content: scored.content }].slice(-12);
  const state = { heat: scored.heat, lastAt: now, messages, violations: previous.violations || 0 };
  activity.set(key, state);
  if (activity.size > MAX_TRACKED) {
    for (const [trackedKey, tracked] of activity) if (now - tracked.lastAt > 120_000) activity.delete(trackedKey);
  }

  const rapidLimit = Math.max(5, Number(automod.maxMessages) || 7);
  const duplicateLimit = Math.max(3, Number(automod.maxIdentical) || 3);
  const heatLimit = Math.max(60, Math.min(200, Number(automod.heatLimit) || 100));
  const rapid = messages.length >= rapidLimit && messages[messages.length - 1].at - messages[0].at <= heatWindowMs;
  const duplicate = scored.duplicates + 1 >= duplicateLimit;
  const mentionLimit = Math.max(3, Number(automod.mentionLimit) || 6);
  const mentionSpam = (message.mentions.users.size + message.mentions.roles.size + (message.mentions.everyone ? 5 : 0)) >= mentionLimit;
  const triggered = duplicate || rapid || mentionSpam || scored.heat >= heatLimit;
  if (!triggered) return false;

  const incidentKey = `${key}:automod`;
  if (activeIncidents.has(incidentKey)) {
    if (message.deletable) await message.delete().catch(() => {});
    return true;
  }
  activeIncidents.add(incidentKey);
  try {
    const reason = duplicate ? `repeated identical message (${scored.duplicates + 1} times)`
      : mentionSpam ? 'excessive mentions' : rapid ? `rapid messaging (${messages.length} messages in ${Math.round(heatWindowMs / 1000)} seconds)` : `spam heat reached ${Math.round(scored.heat)}`;
    const action = ['log', 'delete', 'timeout', 'kick'].includes(automod.action) ? automod.action : 'timeout';
    if (action !== 'log') await deleteRecentSpam(message, message.author.id, scored.content);
    const warnings = getWarnings(message.guild.id, message.author.id);
    const timeoutMinutes = timeoutForViolation(automod.timeoutMinutes, warnings);
    let actionResult = 'messages deleted';
    if (action === 'log') actionResult = 'logged only';
    else if (action === 'timeout' && message.member?.moderatable) {
      try {
        await message.member.timeout(timeoutMinutes * MINUTE, `Nexus AutoMod: ${reason}`);
        actionResult += `; timeout applied for ${timeoutMinutes} minute(s)`;
      } catch (error) {
        actionResult += `; timeout failed (${error.code || error.message})`;
        console.error(`[automod] Timeout failed for ${message.author.id}: ${error.message}`);
      }
    } else if (action === 'timeout') {
      actionResult += '; timeout unavailable (check role hierarchy and Moderate Members permission)';
    } else if (action === 'kick' && message.member?.kickable) {
      await message.member.kick(`Nexus AutoMod: ${reason}`).catch(error => { actionResult += `; kick failed (${error.code || error.message})`; });
      actionResult += '; kick attempted';
    }
    if (action !== 'log') addWarning(message.guild.id, message.author.id, {
      reason: `Auto-moderation: ${reason}`, moderatorId: client.user.id, createdAt: new Date().toISOString(),
    });
    state.heat = 0;
    state.violations = (state.violations || 0) + 1;
    state.messages = [];
    activity.set(key, state);
    if (action !== 'log') await message.channel.send({ content: `${WARNING} <@${message.author.id}>`, allowedMentions: { users: [message.author.id] } }).catch(error => console.error(`[automod] Notice send failed: ${error.message}`));
    await logModEvent(client, message.guild.id, {
      title: '🧯 Nexus AutoMod • Spam action',
      description: `${message.author.tag} triggered spam protection in <#${message.channel.id}>.`,
      color: 0xdc2626,
      fields: [
        { name: 'Reason', value: reason, inline: false },
        { name: 'Heat', value: `${Math.round(scored.heat)} / ${heatLimit}`, inline: true },
        { name: 'Result', value: actionResult.slice(0, 1024), inline: false },
      ],
    });
  } finally {
    setTimeout(() => activeIncidents.delete(incidentKey), 3000).unref?.();
  }
  return true;
}
module.exports = { handleAutomod, normalized, containsAbuse, heatForMessage, timeoutForViolation };
