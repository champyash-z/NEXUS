const { PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, ChannelType, AttachmentBuilder } = require('discord.js');
const { getWarnings, addWarning, clearWarnings } = require('./utils/warnings');
const { getUserData, setUserData, awardXp, getLevelFromXp, getXpRequiredForLevel, getProgressBar, getGuildLeaderBoard, getServerRank, getLevelConfig, setLevelConfig } = require('./utils/leveling');
const { addReminder, listReminders, cancelReminder, parseDuration } = require('./utils/reminders');
const { getGuildConfig, setGuildConfig, updateSetupState, resetGuildSetup } = require('./utils/config');
const { PRESETS, MODULES, buildSetupEmbed, buildSetupWizard, applySetupSelection } = require('./commands/setup');
const { getGuildSecurity, upsertGuildSecurity, getIncidents } = require('./database/database');
const protection = require('./security/protection');
const onboarding = require('./utils/onboarding');
const { getTicketRecord, addEvent, closeTicketAndTranscript, fetchAllMessages, makeTranscript, db } = require('./utils/tickets');
const fs = require('node:fs');
const path = require('node:path');
const suggestionsPath = path.join(__dirname, '..', 'data', 'suggestions.json');
const rolePanelsPath = path.join(__dirname, '..', 'data', 'rolepanels.json');
function readJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, data) { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8'); }
function isSetupAuthorized(message) { return Boolean(message.guild?.ownerId === message.author.id || message.member?.permissions?.has(PermissionFlagsBits.Administrator) || message.member?.permissions?.has(PermissionFlagsBits.ManageGuild)); }


const PREFIXES = ['!', '.', '?'];
const prefixList = PREFIXES.map(p => `\`${p}\``).join(', ');

function hasPermission(message, permission) {
  return Boolean(message.member?.permissions?.has(permission));
}

async function parseUser(message, token) {
  if (!token) return null;
  const id = String(token).replace(/[<@!>]/g, '');
  if (!/^\d{17,20}$/.test(id)) return null;
  return message.mentions.users.get(id) || await message.client.users.fetch(id).catch(() => null);
}

function usage(message, text) {
  return message.reply(`Usage: \`${message.client.prefixes[0]}${text}\` (prefixes supported: ${prefixList})`);
}


function buildModerationEmbed({ title, description, color = 0xfacc15, fields = [], guild = null }) {
  const embed = new EmbedBuilder().setColor(color).setTitle(title).setDescription(description).addFields(fields).setTimestamp(new Date()).setFooter({ text: 'NEXUS • Moderation' });
  if (guild) embed.setAuthor({ name: guild.name, iconURL: guild.iconURL({ size: 128 }) || undefined });
  return embed;
}

async function sendModerationDM(user, guild, { title, reason, moderator, color = 0xfacc15, duration = null, warningCount = null }) {
  const fields = [
    { name: 'Server', value: String(guild.name || 'Unknown server').slice(0, 1024), inline: true },
    { name: 'Moderator', value: String(moderator || 'Server moderation team').slice(0, 1024), inline: true },
    { name: 'Reason', value: String(reason || 'No reason provided').slice(0, 1024), inline: false },
  ];
  if (duration) fields.push({ name: 'Duration', value: duration.slice(0, 1024), inline: true });
  if (Number.isInteger(warningCount)) fields.push({ name: 'Recorded warnings', value: String(warningCount), inline: true });
  const embed = new EmbedBuilder().setColor(color).setAuthor({ name: `${guild.name} • Nexus Moderation`, iconURL: guild.iconURL({ size: 128 }) || undefined }).setTitle(title).setDescription('A moderation action has been applied to your account in this server. If you believe this was a mistake, contact the server staff.').addFields(fields).setTimestamp(new Date()).setFooter({ text: 'NEXUS • Please keep any appeal respectful' });
  try { await user.send({ embeds: [embed], allowedMentions: { parse: [] } }); return true; }
  catch { return false; }
}

function mentionedIdsInOrder(content, pattern) {
  return [...String(content || '').matchAll(pattern)].map(match => match[1]);
}

async function handleWeatherCommand(message, args) {
  const query = args.join(' ').trim();
  if (!query) return message.reply('Usage: `!weather <city, state, or country>`\nExample: `!weather Baikunthpur`');

  try {
    const geoUrl = new URL('https://geocoding-api.open-meteo.com/v1/search');
    geoUrl.searchParams.set('name', query);
    geoUrl.searchParams.set('count', '10');
    geoUrl.searchParams.set('language', 'en');
    geoUrl.searchParams.set('format', 'json');
    const geoResponse = await fetch(geoUrl, { signal: AbortSignal.timeout(8000) });
    if (!geoResponse.ok) throw new Error(`Geocoding service returned ${geoResponse.status}`);
    const geoData = await geoResponse.json();
    const places = Array.isArray(geoData.results) ? geoData.results : [];
    if (!places.length) return message.reply('City not found.');

    const normalized = query.toLocaleLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
    const place = places.find(item => {
      const candidates = [item.name, item.admin1, item.country].filter(Boolean).map(v => String(v).toLocaleLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim());
      return candidates.includes(normalized);
    }) || places[0];

    const forecastUrl = new URL('https://api.open-meteo.com/v1/forecast');
    forecastUrl.searchParams.set('latitude', String(place.latitude));
    forecastUrl.searchParams.set('longitude', String(place.longitude));
    forecastUrl.searchParams.set('current', 'temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code');
    forecastUrl.searchParams.set('timezone', 'auto');
    const weatherResponse = await fetch(forecastUrl, { signal: AbortSignal.timeout(8000) });
    if (!weatherResponse.ok) throw new Error(`Weather service returned ${weatherResponse.status}`);
    const weatherData = await weatherResponse.json();
    const current = weatherData.current;
    if (!current || !Number.isFinite(current.temperature_2m)) throw new Error('Weather data unavailable');

    const weatherDescriptions = {
      0: 'Clear sky', 1: 'Mainly clear', 2: 'Partly cloudy', 3: 'Overcast',
      45: 'Fog', 48: 'Depositing rime fog', 51: 'Light drizzle', 53: 'Moderate drizzle', 55: 'Dense drizzle',
      56: 'Light freezing drizzle', 57: 'Dense freezing drizzle', 61: 'Slight rain', 63: 'Moderate rain', 65: 'Heavy rain',
      66: 'Light freezing rain', 67: 'Heavy freezing rain', 71: 'Slight snow', 73: 'Moderate snow', 75: 'Heavy snow',
      77: 'Snow grains', 80: 'Slight rain showers', 81: 'Moderate rain showers', 82: 'Violent rain showers',
      85: 'Slight snow showers', 86: 'Heavy snow showers', 95: 'Thunderstorm', 96: 'Thunderstorm with slight hail', 99: 'Thunderstorm with heavy hail'
    };
    const condition = weatherDescriptions[current.weather_code] || 'Conditions unavailable';
    const locationParts = [place.name, place.admin1, place.country].filter((v, i, arr) => v && arr.indexOf(v) === i);
    const locationName = locationParts.join(', ');
    const embed = new EmbedBuilder()
      .setColor(0x3498db)
      .setTitle(`Weather in ${locationName}`)
      .setDescription(`**${condition}**`)
      .addFields(
        { name: 'Temp', value: `${current.temperature_2m}°C`, inline: true },
        { name: 'Wind', value: `${current.wind_speed_10m} km/h`, inline: true },
        { name: 'Feels like', value: `${current.apparent_temperature ?? current.temperature_2m}°C`, inline: true },
        { name: 'Humidity', value: `${current.relative_humidity_2m ?? 'N/A'}%`, inline: true }
      );
    return message.reply({ embeds: [embed] });
  } catch (error) {
    console.error(`[weather] ${error.message}`);
    return message.reply('Weather service is temporarily unavailable. Please try again shortly.');
  }
}

async function runPrefixCommand(message, commandName, args) {
  // Bare !welcome/.welcome/?welcome plays the soundboard clip. Existing
  // welcome-management subcommands (status/setup/message/etc.) remain unchanged.
  if (commandName === 'welcome' && args.length === 0) {
    return require('./community-features').handleCommand(message, ['soundboard', 'play', 'welcome']);
  }
  const communityCommands = new Set(['counting', 'count', 'guess', 'guessnumber', 'coinflip', 'flip', 'giveaway', 'gstart', 'invites', 'invite', 'soundboard', 'sound', 'suspens', 'sus', 'laugh']);
  if (commandName === 'weather') return handleWeatherCommand(message, args);
  if (communityCommands.has(commandName)) {
    return require('./community-features').handleCommand(message, [commandName, ...args]);
  }
  const guild = message.guild;
  const targetUser = () => parseUser(message, args[0]);

  if (commandName === 'stop') {
    const stoppedSuspense = await require('./community-features').stopSuspense(message);
    if (stoppedSuspense) return;
  }
  if (['music','play','search','pause','resume','skip','stop','join','leave','previous','nowplaying','np','seek','forward','rewind','volume','queue','q','shuffle','clear','remove','move','playnext','loop','autoplay','playrecent','selectrandom','filter','playlist'].includes(commandName)) {
    const music = require('./music');
    if (commandName === 'music') return music.handleCommand(message, ['music', ...args]);
    if (commandName === 'playlist') return music.handleCommand(message, ['playlist', ...args]);
    return music.handleCommand(message, [commandName, ...args]);
  }

  switch (commandName) {
    case 'chess': return require('./chess').handleCommand(message, args);
    case 'ai': {
      if (['safety', 'mod'].includes(String(args[0] || '').toLowerCase())) return require('./utils/aiSafety').handleSafetyCommand(message, args.slice(1));
      return require('./ai/system').handleCommand(message, args);
    }
    case 'dm':
    case 'msg': {
      if (!message.guild) return message.reply('This command can only be used in a server.');
      if (!message.member?.permissions?.has(PermissionFlagsBits.Administrator) && !message.member?.permissions?.has(PermissionFlagsBits.ManageGuild) && message.guild.ownerId !== message.author.id) return message.reply('Only the server owner or a Manage Server administrator can use this command.');
      const commandUsed = (message.content.trim().match(/^[!.?](dm|msg)\b/i) || [null, commandName])[1].toLowerCase();
      const raw = message.content.slice(message.content.search(/\S+/) + 1).trim();
      const body = raw.replace(/^(?:dm|msg)\b/i, '').trim();
      if (!body) return message.reply('Usage: `!dm @user your message` or `!dm USER_ID your message` (also `.dm` and `?dm`).');
      const allMatch = body.match(/^all\s+([\s\S]+)$/i);
      if (commandUsed === 'dm' && allMatch) return message.reply('`dm` sends a direct message to one user. Use `!dm @user your message` or `!dm USER_ID your message`.');
      if (allMatch) {
        const text = allMatch[1].trim();
        if (!text) return message.reply('Please include the message after `all`.');
        const prompt = await message.reply(`⚠️ You are about to DM **${message.guild.memberCount}** server members (bots will be skipped). Reply \`confirm\` within 30 seconds to send, or \`cancel\` to abort. Message preview:\n> ${text.slice(0, 500)}`);
        const confirmation = await message.channel.awaitMessages({ filter: m => m.author.id === message.author.id && /^(confirm|cancel)$/i.test(m.content.trim()), max: 1, time: 30000, errors: ['time'] }).catch(() => null);
        if (!confirmation?.first() || /^cancel$/i.test(confirmation.first().content.trim())) return message.channel.send('Mass DM cancelled or timed out.');
        let fetchedMembers;
        try { fetchedMembers = await message.guild.members.fetch(); }
        catch (error) { return message.channel.send(`❌ I could not fetch the full member list, so no DMs were sent. Check the **Server Members Intent** and bot permissions. (${error.message.slice(0, 180)})`); }
        const members = [...fetchedMembers.values()].filter(m => !m.user.bot);
        let sent = 0, failed = 0;
        await message.channel.send(`📨 Starting confirmed server DM to ${members.length} members. This may take a while.`);
        for (const member of members) {
          try { await member.send({ content: text.slice(0, 1900), allowedMentions: { parse: [] } }); sent++; }
          catch { failed++; }
          await new Promise(resolve => setTimeout(resolve, 1100));
        }
        return message.channel.send(`✅ Mass DM finished. Sent: **${sent}** · Failed/DMs closed: **${failed}**.`);
      }
      const match = body.match(/^(<@!?\d{17,20}>|\d{17,20})\s+([\s\S]+)$/);
      if (!match) return message.reply('Usage: `!dm @user your message` or `!dm USER_ID your message`. For confirmed server-wide messaging, use `!msg all your message`.');
      const userId = match[1].replace(/[<@!>]/g, '');
      const user = message.mentions.users.get(userId) || await message.client.users.fetch(userId).catch(() => null);
      if (!user) return message.reply('I could not find that user. Mention them or provide their Discord user ID.');
      try { await user.send({ content: match[2].trim().slice(0, 1900), allowedMentions: { parse: [] } }); return message.reply(`✅ DM sent to **${user.tag}**.`); }
      catch { return message.reply(`❌ I could not DM **${user.tag}**. Their DMs may be closed.`); }
    }
    case 'help': {
      const pages = [
        {
          title: '🛡️ Moderation', emoji: '🛡️', color: 0xef4444,
          description: 'NEXUS HELP • Prefixes: `!` `.` `?`\nModeration commands are grouped here. Use the navigation buttons to browse Setup & Safety, Community, Levels, Arcade, Counting & Games, Invites & Soundboard, Music & AI, and the quick-start page. Use a reason so staff can understand the context later.',
          fields: [
            { name: 'Member actions', value: '`!warn @member [reason]`\n`!warnings @member`\n`!clearwarnings @member`\n`!timeout @member 10m [reason]`\n`!mute @member [reason]` · `!unmute @member`\n`!kick @member [reason]`\n`!ban @member [reason]`', inline: false },
            { name: 'Channel cleanup', value: '`!purge 25` — delete recent messages\n`!purge all` — clear eligible recent messages', inline: false },
            { name: 'Example', value: '`!timeout @Alex 10m Flooding chat`', inline: false }
          ]
        },
        {
          title: '⚙️ Server Setup & Safety', emoji: '⚙️', color: 0x0ea5e9,
          description: 'Configure Nexus modules and protection from one place.',
          fields: [
            { name: 'Guided setup', value: '`!setup start` · `!setup status` · `!setup reset`', inline: false },
            { name: 'Configuration', value: '`!config show`\n`!config channel modlog #channel`\n`!config channel welcome #channel`\n`!config staffrole @role`', inline: false },
            { name: 'Security controls', value: '`!security status`\n`!security enable` · `!security disable`\n`!security mode alert|contain`\n`!security log #channel`\n`!security lockdown` · `!security unlockdown`\n`!security logs`', inline: false },
            { name: 'AI moderation', value: '`!ai mod status` · `!ai mod enable|disable`\n`!ai mod add words word1, word2`\n`!ai mod mute|unmute #channel`\n`!ai mod bypass add|remove|list`', inline: false }
          ]
        },
        {
          title: '📚 Quick Start & Categories', emoji: '📚', color: 0x7c3aed,
          description: 'Welcome to Nexus. Browse one focused category per page with the buttons below. Every prefix command supports `!`, `.` and `?`.',
          fields: [
            { name: 'Prefixes', value: '`!` · `.` · `?`\nExamples: `!help`, `.help`, `?help`.', inline: false },
            { name: 'Quick commands', value: '`!ping` — latency\n`!serverinfo` — server overview\n`!userinfo @member` — member details\n`!setup start` — guided setup', inline: false },
            { name: 'Category guide', value: '🛡️ Moderation\n📚 Quick Start & Category Guide\n⚙️ Server Setup & Safety\n👋 Community Tools\n🏆 Levels & Member Info\n🎮 Nexus Arcade\n🎲 Games, Counting & Giveaways\n📨 Invites, Soundboard & Suspense\n🎵 Music & AI', inline: false }
          ]
        },
        {
          title: '👋 Community Tools', emoji: '👋', color: 0x14b8a6,
          description: 'Welcome flows, tickets, suggestions, reminders, polls, and self-service roles.',
          fields: [
            { name: 'Welcome & verification', value: '`!welcome status`\n`!welcome setup` · `!welcome message`\n`!welcome leave` · `!welcome leavemessage`\n`!welcome verify` · `!welcome autorole` · `!welcome dm` · `!welcome gate`', inline: false },
            { name: 'Tickets & feedback', value: '`!ticket panel` · `!ticket help`\n`!suggest submit <idea>` · `!suggest review`\n`!rolepanel add|remove|send`', inline: false },
            { name: 'Quick interactions', value: '`!p Question | Option 1 | Option 2`\n`!remind me 30m <message>`\n`!remind list` · `!remind cancel <id>`', inline: false }
          ]
        },
        {
          title: '🏆 Levels & Member Info', emoji: '🏆', color: 0xf59e0b,
          description: 'Give active members a reason to participate and track progress over time.',
          fields: [
            { name: 'Member stats', value: '`!rank` · `!rank @member`\n`!leaderboard` · `!leaderboard 2`\n`!userinfo @member` · `!serverinfo`', inline: false },
            { name: 'Level management', value: '`!levels status` · `!levels enable|disable`\n`!levels config` · `!levels reward`\n`!xp add|remove|set|reset`', inline: false },
            { name: 'Example', value: '`!rank @Alex`', inline: false }
          ]
        },
        {
          title: '🎮 Nexus Arcade', emoji: '🎮', color: 0x8b5cf6,
          description: 'Play lightweight games in your server. Start with the game list to see what is available.',
          fields: [
            { name: 'Game controls', value: '`!games` — game help\n`!game list` — available games\n`!game create <game idea>` — start a game\n`!game scores` — view scores\n`!game stop` — stop your active game\n`!chess start [password]` — start touchscreen chess', inline: false },
            { name: 'Chess', value: '`!chess start [password]` · `!chess join [password]`\n`!chess invite @player` · `!chess save <name>`\n`!chess load <name> <password>` · `!chess saves`\nPlay with touchscreen piece/destination menus or coordinate moves.', inline: false },
            { name: 'Tip', value: 'Use the interactive controls shown on each game panel; they are tied to the active game session.', inline: false }
          ]
        },
        {
          title: '🎲 Games, Counting & Giveaways', emoji: '🎲', color: 0xec4899,
          description: 'Community mini-features with their own commands and clear setup steps.',
          fields: [
            { name: 'Counting channel', value: '`!counting setup #channel` — staff setup\n`!counting stats` — current count and best\n`!counting reset` — staff reset\nMembers count up one number at a time; consecutive turns by the same member are not allowed.', inline: false },
            { name: 'Guess the number', value: '`!guess setup #channel` — configure the channel (staff)\n`!guess start` — start once; secret range 1–100,000\n`!guess stats` — view stats · `!guess stop` — pause\nAfter starting, members send plain numbers in that channel. Nexus picks a new number automatically after each win.', inline: false },
            { name: 'Coin flip', value: '`!coinflip` or `!flip` — animated heads-or-tails toss.', inline: false },
            { name: 'Giveaways', value: '`!giveaway <duration> <winners> <prize>` — e.g. `!giveaway 2h 2 Nitro`\nMembers enter with the button on the giveaway embed. Staff need Manage Server.', inline: false }
          ]
        },
        {
          title: '📨 Invites & Soundboard', emoji: '📨', color: 0x0d9488,
          description: 'Track invite activity and play short sounds in voice chat.',
          fields: [
            { name: 'Invite tracker', value: '`!invites setup` — initialize invite snapshots (staff)\n`!invites` — your invite stats\n`!invites @member` — another member’s stats\n`!invites leaderboard` — active invite leaderboard\nInvite attribution can be unavailable for vanity links or simultaneous joins.', inline: false },
            { name: 'Soundboard', value: '`!soundboard list` — list available sounds\n`!soundboard play welcome` or bare `!welcome` — play the welcome sound once in your current voice channel\n`!soundboard add <name>` — attach an audio file to the command (staff)\n`!soundboard remove <name>` — remove a custom sound (staff).\n`!laugh` — play the laugh sound silently (also works with `.` and `?` prefixes)\n`!suspens` or `!sus` — queue and play the suspense sound once\n`!stop` — stop current audio and clear the queue', inline: false }
          ]
        },
        {
          title: '🎵 Music & AI', emoji: '🎵', color: 0x06b6d4,
          description: 'Listen together in voice channels or use the AI assistant. Music playback requires the bot to have voice permissions.',
          fields: [
            { name: 'Music playback', value: '`!play <YouTube link or search>`\n`!search <query>` · `!queue`\n`!pause` · `!resume` · `!skip` · `!stop`\n`!join` · `!leave` · `!nowplaying`\n`!volume 50` · `!loop off|track|queue`\n`!shuffle` · `!filter <name|off>`', inline: false },
            { name: 'Playlists & settings', value: '`!playlist create|add|play|view|list`\n`!music setup` · `!music status` · `!music settings`', inline: false },
            { name: 'AI assistant', value: '`!ai help` — AI command guidance\nAI responses are intentionally kept in their native format.', inline: false }
          ]
        }
      ];
      const makeEmbed = index => {
        const page = pages[index];
        return new EmbedBuilder().setColor(page.color).setTitle(page.title).setDescription(page.description)
          .addFields(page.fields).setFooter({ text: `NEXUS HELP • Page ${index + 1} of ${pages.length} • Prefixes: !  .  ?` }).setTimestamp();
      };
      const makeRow = index => new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`nexus_help_first_${message.author.id}`).setEmoji('⏮️').setLabel('First').setStyle(ButtonStyle.Secondary).setDisabled(index === 0),
        new ButtonBuilder().setCustomId(`nexus_help_prev_${message.author.id}`).setEmoji('◀️').setLabel('Back').setStyle(ButtonStyle.Primary).setDisabled(index === 0),
        new ButtonBuilder().setCustomId(`nexus_help_page_${message.author.id}`).setLabel(`${index + 1} / ${pages.length}`).setStyle(ButtonStyle.Secondary).setDisabled(true),
        new ButtonBuilder().setCustomId(`nexus_help_next_${message.author.id}`).setEmoji('▶️').setLabel('Next').setStyle(ButtonStyle.Primary).setDisabled(index === pages.length - 1),
        new ButtonBuilder().setCustomId(`nexus_help_last_${message.author.id}`).setEmoji('⏭️').setLabel('Last').setStyle(ButtonStyle.Secondary).setDisabled(index === pages.length - 1)
      );
      let index = 0;
      const sent = await message.reply({ embeds: [makeEmbed(index)], components: [makeRow(index)] });
      const collector = sent.createMessageComponentCollector({ time: 180000, filter: interaction => interaction.user.id === message.author.id && interaction.customId.startsWith(`nexus_help_`) });
      collector.on('collect', async interaction => {
        const action = interaction.customId.split('_')[2];
        if (action === 'first') index = 0;
        else if (action === 'prev') index = Math.max(0, index - 1);
        else if (action === 'next') index = Math.min(pages.length - 1, index + 1);
        else if (action === 'last') index = pages.length - 1;
        await interaction.update({ embeds: [makeEmbed(index)], components: [makeRow(index)] }).catch(() => {});
      });
      collector.on('end', async () => {
        await sent.edit({ components: [] }).catch(() => {});
      });
      return sent;
    }
    case 'ping': {
      const startedAt = Date.now();
      const sent = await message.reply('🏓 Pong! **…ms**');
      const roundTripMs = Date.now() - startedAt;
      return sent.edit(`:ping_pong: Pong! **${roundTripMs}ms**`);
    }

    case 'p': {
      if (!guild) return message.reply('Polls can only be created in a server.');
      const raw = args.join(' ').trim();
      if (!raw || /^(help)$/i.test(raw)) {
        return message.reply([
          '**Nexus Poll Help**',
          '`!p Question | Option 1 | Option 2`',
          'You can also use `.p` or `?p`.',
          'Provide 2–10 options separated by `|`.',
          'Example: `!p Best color? | Red | Blue | Green`'
        ].join('\\n'));
      }
      const parts = raw.split('|').map(value => value.trim()).filter(Boolean);
      if (parts.length < 3 || parts.length > 11) {
        return message.reply('Usage: `!p Question | Option 1 | Option 2` — add 2–10 options separated by `|`.');
      }
      const question = parts.shift();
      try {
        const pollData = require('./polls/native').buildOptions(question, parts, 24, false);
        await message.channel.send({ poll: pollData.poll });
        return;
      } catch (error) {
        return message.reply(`Could not create poll: ${error.message}`);
      }
    }

    case 'config': {
      if (!guild) return message.reply('Use this command inside a server.');
      if (!isSetupAuthorized(message)) return message.reply('You need Manage Server or Administrator permission to configure Nexus.');
      const sub = (args[0] || 'show').toLowerCase();
      const config = getGuildConfig(guild.id);
      if (sub === 'show') {
        const channels = Object.entries(config.channels || {}).map(([key, id]) => `**${key}:** ${id ? `<#${id}>` : 'Not set'}`).join('\n');
        return message.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle('Nexus Server Configuration').setDescription(channels || 'No channels configured.').addFields({ name: 'Ticket staff role', value: config.ticketStaffRoleId ? `<@&${config.ticketStaffRoleId}>` : 'Not set' })] });
      }
      if (sub === 'channel') {
        const rawKey = (args[1] || '').toLowerCase();
        const keys = { modlog: 'modlog', welcome: 'welcome', departure: 'departure', suggestions: 'suggestions', levelup: 'levelup', announcements: 'announcements', giveaways: 'giveaways', tickets: 'tickets', ticketcategory: 'ticketCategory', ticket_category: 'ticketCategory' };
        const key = keys[rawKey];
        if (!key) return usage(message, 'config channel <modlog|welcome|departure|suggestions|levelup|announcements|giveaways|tickets|ticketcategory> <#channel>');
        const channel = message.mentions.channels.first();
        if (!channel) return usage(message, `config channel ${rawKey} <#channel>`);
        if (key === 'welcome') onboarding.setOnboarding(guild.id, { welcomeChannelId: channel.id });
        if (key === 'ticketCategory' && channel.type !== ChannelType.GuildCategory) return message.reply('For ticketcategory, mention a category channel.');
        if (key !== 'ticketCategory' && !channel.isTextBased()) return message.reply('Please mention a text-based channel.');
        setGuildConfig(guild.id, { ...config, channels: { ...config.channels, [key]: channel.id } });
        return message.reply(`Configured **${key}** as ${channel}.`);
      }
      if (sub === 'staffrole') {
        const role = message.mentions.roles.first();
        if (!role || role.id === guild.roles.everyone.id) return usage(message, 'config staffrole @role');
        setGuildConfig(guild.id, { ...config, ticketStaffRoleId: role.id });
        return message.reply(`Configured ticket staff role as ${role}.`);
      }
      return message.reply('Use `!config show`, `!config channel suggestions #channel`, `!config channel modlog #channel`, or `!config staffrole @role`.');
    }

    case 'serverinfo': {
      if (!guild) return message.reply('Use this command inside a server.');
      const embed = new EmbedBuilder().setColor(0x5865F2).setTitle(guild.name).setThumbnail(guild.iconURL({ size: 256 }))
        .addFields(
          { name: 'Server ID', value: guild.id, inline: true },
          { name: 'Members', value: String(guild.memberCount), inline: true },
          { name: 'Created', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true }
        );
      return message.reply({ embeds: [embed] });
    }

    case 'userinfo': {
      const user = args[0] ? await targetUser() : message.author;
      if (!user) return usage(message, 'userinfo @user');
      const targetMember = guild ? await guild.members.fetch(user.id).catch(() => null) : null;
      const embed = new EmbedBuilder().setColor(0x5865F2).setTitle(`User info: ${user.tag}`).setThumbnail(user.displayAvatarURL({ size: 256 }))
        .addFields({ name: 'User ID', value: user.id }, { name: 'Account created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:D>` });
      if (targetMember) embed.addFields({ name: 'Joined server', value: targetMember.joinedTimestamp ? `<t:${Math.floor(targetMember.joinedTimestamp / 1000)}:D>` : 'Unknown' });
      return message.reply({ embeds: [embed] });
    }

    case 'purge': {
      if (!guild) return message.reply('Use this command inside a server.');
      if (!hasPermission(message, PermissionFlagsBits.ManageMessages)) return message.reply('Meow Ghop Ghop Ghop 🐱');
      if (!message.channel.isTextBased() || !message.channel.bulkDelete || !message.channel.messages?.fetch) {
        return message.reply('This channel does not support bulk deletion.');
      }

      const rawAmount = (args[0] || '').trim().toLowerCase();
      const deleteAll = rawAmount === 'all';
      const targetCount = deleteAll ? Number.MAX_SAFE_INTEGER : Number.parseInt(rawAmount, 10);

      if (!deleteAll && (!Number.isInteger(targetCount) || targetCount < 1)) {
        return usage(message, 'purge <number|all>');
      }

      let totalDeleted = 0;
      let remaining = deleteAll ? Number.MAX_SAFE_INTEGER : targetCount;

      while (remaining > 0) {
        const limit = Math.min(100, remaining);
        const messages = await message.channel.messages.fetch({ limit: deleteAll ? 100 : limit });
        if (messages.size === 0) break;
        const batch = [...messages.values()];
        const deleted = await message.channel.bulkDelete(deleteAll ? batch : batch.slice(0, remaining), true);
        totalDeleted += deleted.size;
        remaining = deleteAll ? Number.MAX_SAFE_INTEGER : Math.max(0, targetCount - totalDeleted);

        if (deleteAll && deleted.size === 0) break;
        if (deleteAll && batch.length < 100) break;
        if (!deleteAll && remaining === 0) break;
      }

      return message.reply({ content: deleteAll ? `🧹 Deleted ${totalDeleted} message(s) from this channel.` : `🧹 Deleted ${totalDeleted} message(s).` });
    }

    case 'kick': {
      if (!guild) return message.reply('Use this command inside a server.');
      if (!hasPermission(message, PermissionFlagsBits.KickMembers)) return message.reply('Meow Ghop Ghop Ghop 🐱');
      const user = await targetUser();
      if (!user) return usage(message, 'kick @user [reason]');
      if (user.id === message.author.id) return message.reply('You cannot kick yourself.');
      const target = await guild.members.fetch(user.id).catch(() => null);
      if (!target) return message.reply('That user is not a member of this server.');
      if (!target.kickable) return message.reply('I cannot kick that member. Check my role position and Kick Members permission.');
      const reason = args.slice(1).join(' ').trim() || `Kicked by ${message.author.tag}`;
      await target.kick(reason);
      const dmSent = await sendModerationDM(user, guild, { title: '👢 You were kicked', reason, moderator: message.author.tag, color: 0xef4444, duration: 'You may be able to rejoin unless the server has other restrictions.' });
      return message.reply({ embeds: [buildModerationEmbed({ title: '👢 Member Kicked', description: `**${user.tag}** was removed from the server.`, color: 0xef4444, guild, fields: [
        { name: 'Member', value: `${user.tag} (${user.id})`, inline: false }, { name: 'Moderator', value: message.author.tag, inline: true }, { name: 'Reason', value: reason.slice(0, 1024), inline: false }, { name: 'DM', value: dmSent ? 'Delivered' : 'Could not deliver (DMs may be closed)', inline: false }
      ] })] });
    }

    case 'ban': {
      if (!guild) return message.reply('Use this command inside a server.');
      if (!hasPermission(message, PermissionFlagsBits.BanMembers)) return message.reply('Meow Ghop Ghop Ghop 🐱');
      const user = await targetUser();
      if (!user) return usage(message, 'ban @user [reason]');
      if (user.id === message.author.id) return message.reply('You cannot ban yourself.');
      const target = await guild.members.fetch(user.id).catch(() => null);
      if (target && !target.bannable) return message.reply('I cannot ban that member. Check my role position and Ban Members permission.');
      const remainingArgs = args.slice(1);
      let deleteDays = 0;
      const daysIndex = remainingArgs.findIndex(value => value === '--days' || value === '--delete-days');
      if (daysIndex >= 0) {
        const value = Number(remainingArgs[daysIndex + 1]);
        if (!Number.isInteger(value) || value < 0 || value > 7) return usage(message, 'ban @user [--days 0-7] [reason]');
        deleteDays = value;
        remainingArgs.splice(daysIndex, 2);
      }
      const reason = remainingArgs.join(' ').trim() || `Banned by ${message.author.tag}`;
      await guild.members.ban(user.id, { reason, deleteMessageSeconds: deleteDays * 86400 });
      const dmSent = await sendModerationDM(user, guild, { title: '🔨 You were banned', reason, moderator: message.author.tag, color: 0xef4444, duration: 'Permanent unless the server staff lifts the ban.' });
      return message.reply({ embeds: [buildModerationEmbed({ title: '🔨 Member Banned', description: `**${user.tag}** was banned from the server.`, color: 0xef4444, guild, fields: [
        { name: 'Member', value: `${user.tag} (${user.id})`, inline: false }, { name: 'Moderator', value: message.author.tag, inline: true }, { name: 'Reason', value: reason.slice(0, 1024), inline: false }, { name: 'Deleted messages', value: deleteDays ? `Last ${deleteDays} day(s)` : 'None', inline: true }, { name: 'DM', value: dmSent ? 'Delivered' : 'Could not deliver (DMs may be closed)', inline: false }
      ] })] });
    }

    case 'timeout': {
      if (!guild) return message.reply('Use this command inside a server.');
      if (!hasPermission(message, PermissionFlagsBits.ModerateMembers)) return message.reply('Meow Ghop Ghop Ghop 🐱');
      const user = await targetUser();
      const minutes = Number.parseInt(args[1], 10);
      if (!user || !Number.isInteger(minutes) || minutes < 1 || minutes > 40320) return usage(message, 'timeout @user <minutes> [reason]');
      if (user.id === message.author.id) return message.reply('You cannot timeout yourself.');
      const target = await guild.members.fetch(user.id).catch(() => null);
      if (!target) return message.reply('That user is not a member of this server.');
      if (!target.moderatable) return message.reply('I cannot timeout that member. Check role hierarchy and permissions.');
      const reason = args.slice(2).join(' ').trim() || `Timed out by ${message.author.tag}`;
      const timeoutUntil = Date.now() + minutes * 60_000;
      await target.timeout(minutes * 60_000, reason);
      const duration = `${minutes} minute(s) • ends <t:${Math.floor(timeoutUntil / 1000)}:F> (<t:${Math.floor(timeoutUntil / 1000)}:R>)`;
      const dmSent = await sendModerationDM(user, guild, { title: '⏳ You were timed out', reason, moderator: message.author.tag, color: 0xf59e0b, duration });
      return message.reply({ embeds: [buildModerationEmbed({ title: '⏳ Member Timed Out', description: `**${user.tag}** can no longer send messages until the timeout expires.`, color: 0xf59e0b, guild, fields: [
        { name: 'Member', value: `${user.tag} (${user.id})`, inline: false }, { name: 'Moderator', value: message.author.tag, inline: true }, { name: 'Duration', value: duration, inline: false }, { name: 'Reason', value: reason.slice(0, 1024), inline: false }, { name: 'DM', value: dmSent ? 'Delivered' : 'Could not deliver (DMs may be closed)', inline: false }
      ] })] });
    }

    case 'warn': {
      if (!guild) return message.reply('Use this command inside a server.');
      if (!hasPermission(message, PermissionFlagsBits.ModerateMembers)) return message.reply('Meow Ghop Ghop Ghop 🐱');
      const user = await targetUser();
      const reason = args.slice(1).join(' ').trim();
      if (!user || !reason) return usage(message, 'warn @user <reason>');
      if (user.id === message.author.id) return message.reply('You cannot warn yourself.');
      const records = addWarning(guild.id, user.id, { reason, moderatorId: message.author.id, createdAt: new Date().toISOString() });
      const dmSent = await sendModerationDM(user, guild, { title: '⚠️ You received a warning', reason, moderator: message.author.tag, color: 0xfacc15, warningCount: records.length });
      return message.reply({ embeds: [buildModerationEmbed({ title: '⚠️ Member Warned', description: `A warning has been recorded for **${user.tag}**.`, color: 0xfacc15, guild, fields: [
        { name: 'Member', value: `${user.tag} (${user.id})`, inline: false }, { name: 'Moderator', value: message.author.tag, inline: true }, { name: 'Warning count', value: String(records.length), inline: true }, { name: 'Reason', value: reason.slice(0, 1024), inline: false }, { name: 'DM', value: dmSent ? 'Delivered' : 'Could not deliver (DMs may be closed)', inline: false }
      ] })] });
    }

    case 'warnings': {
      if (!guild) return message.reply('Use this command inside a server.');
      if (!hasPermission(message, PermissionFlagsBits.ModerateMembers)) return message.reply('Meow Ghop Ghop Ghop 🐱');
      const user = await targetUser();
      if (!user) return usage(message, 'warnings @user');
      const records = getWarnings(guild.id, user.id);
      if (!records.length) return message.reply(`**${user.tag}** has no warnings.`);
      const lines = records.slice(-10).map((w, i) => {
        const time = w.createdAt || w.at;
        const timeStr = time ? ` • <t:${Math.floor(new Date(time).getTime() / 1000)}:R>` : '';
        return `**${Math.max(1, records.length - Math.min(10, records.length) + i + 1)}.** ${w.reason} — <@${w.moderatorId}>${timeStr}`;
      });
      return message.reply({ content: `Warnings for **${user.tag}** (${records.length} total):\n${lines.join('\n')}` });
    }

    case 'clearwarnings': {
      if (!guild) return message.reply('Use this command inside a server.');
      if (!hasPermission(message, PermissionFlagsBits.ModerateMembers)) return message.reply('Meow Ghop Ghop Ghop 🐱');
      const user = await targetUser();
      if (!user) return usage(message, 'clearwarnings @user');
      const count = clearWarnings(guild.id, user.id);
      return message.reply(`Cleared ${count} warning(s) for **${user.tag}**.`);
    }

    case 'mute': {
      message.client.mutedChannels.add(message.channel.id);
      return message.reply('Okay now I will not say anything, sorry for disturbing you.');
    }

    case 'unmute': {
      message.client.mutedChannels.delete(message.channel.id);
      return message.reply('You cant keep me quiet for long! Yahoo, I am back!');
    }

    case 'rank': {
      if (!guild) return message.reply('Use this command inside a server.');
      const user = args[0] ? await targetUser() : message.author;
      if (!user) return usage(message, 'rank @user');
      const data = getUserData(guild.id, user.id);
      const xp = Number(data.xp || 0);
      const level = getLevelFromXp(xp);
      const currentLevelXp = level === 0 ? 0 : getXpRequiredForLevel(level - 1);
      const nextLevelXp = getXpRequiredForLevel(level);
      const progress = Math.max(0, xp - currentLevelXp);
      const needed = Math.max(1, nextLevelXp - currentLevelXp);
      const rank = getServerRank(guild.id, user.id);
      const rankCfg = getLevelConfig(guild.id); const rankColor = /^#[0-9a-f]{6}$/i.test(rankCfg.rankColor || '') ? Number.parseInt(rankCfg.rankColor.slice(1), 16) : 0x8b5cf6;
      const embed = new EmbedBuilder().setColor(rankColor).setTitle(`${user.username}'s Rank`)
        .setThumbnail(user.displayAvatarURL({ size: 256 }))
        .setDescription(`**Level:** ${level}\\n**XP:** ${xp}\\n**Server rank:** ${rank ? `#${rank}` : 'Unranked'}\\n${getProgressBar(progress, needed)} ${progress}/${needed} XP`);
      return message.reply({ embeds: [embed] });
    }

    case 'leaderboard': {
      if (!guild) return message.reply('Use this command inside a server.');
      const allowedTypes = ['xp', 'weekly', 'monthly', 'reactions', 'voice', 'messages'];
      const first = String(args[0] || 'xp').toLowerCase();
      const type = allowedTypes.includes(first) ? first : 'xp';
      const pageArg = allowedTypes.includes(first) ? args[1] : args[0];
      const page = Math.max(1, Math.min(1000, Number.parseInt(pageArg || '1', 10) || 1));
      const entries = getGuildLeaderBoard(guild.id, page * 10, type).slice((page - 1) * 10, page * 10);
      if (!entries.length) return message.reply(page === 1 ? 'No leaderboard data yet. Members need to earn XP or activity stats first.' : 'There are no entries on that leaderboard page.');
      const lines = await Promise.all(entries.map(async (entry, index) => {
        const user = await message.client.users.fetch(entry.userId).catch(() => null);
        const medal = (page - 1) * 10 + index + 1;
        let metric = `Level **${entry.level}** · **${Number(entry.xp || 0).toLocaleString()} XP**`;
        if (type === 'weekly') metric = `**${Number(entry.weeklyXp || 0).toLocaleString()} weekly XP** · Level ${entry.level}`;
        if (type === 'monthly') metric = `**${Number(entry.monthlyXp || 0).toLocaleString()} monthly XP** · Level ${entry.level}`;
        if (type === 'reactions') metric = `**${Number(entry.reactions || 0).toLocaleString()} reactions** · Level ${entry.level}`;
        if (type === 'voice') metric = `**${Math.floor(Number(entry.voiceSeconds || 0) / 3600)}h ${Math.floor((Number(entry.voiceSeconds || 0) % 3600) / 60)}m voice** · Level ${entry.level}`;
        if (type === 'messages') metric = `**${Number(entry.totalMessages || 0).toLocaleString()} messages** · Level ${entry.level}`;
        return `**${medal}.** ${user ? user.tag : `<@${entry.userId}>`} — ${metric}`;
      }));
      const title = { xp: 'XP & Level', weekly: 'Weekly XP', monthly: 'Monthly XP', reactions: 'Reaction Activity', voice: 'Voice Time', messages: 'Messages' }[type];
      const embed = new EmbedBuilder().setColor(0x8b5cf6).setTitle(`🏆 Nexus ${title} Leaderboard · Page ${page}`).setDescription(lines.join('\n')).setFooter({ text: 'Use !leaderboard [xp|weekly|monthly|reactions|voice|messages] [page].' });
      return message.reply({ embeds: [embed] });
    }

    case 'levels': {
      if (!guild) return message.reply('Use this command inside a server.');
      const sub = (args[0] || 'status').toLowerCase(); let cfg = getLevelConfig(guild.id);
      if (sub === 'help') return message.reply('Level commands: `!rank [@user]`, `!leaderboard [xp|weekly|monthly|reactions|voice|messages] [page]`, `!levels status|enable|disable`, `!levels config cooldown <seconds>`, `!levels config minlength <1-200>`, `!levels config rankcolor #RRGGBB`, `!levels config maxlevel <0-10000>`, `!levels config xp <min> <max>`, `!levels config mode <random|perword>`, `!levels config reaction on|off`, `!levels config reaction range <min> <max>`, `!levels config reaction awards <off|author|reactor|both>`, `!levels config voice on|off`, `!levels config voice xp <amount>`, `!levels config voice cooldown <seconds>`, `!levels config voice minmembers <count>`, `!levels config voice antiafk <hours|0>`, `!levels config boost role @role <percent|off>`, `!levels config boost channel #channel <percent|off>`, `!levels config boost stacking on|off`, `!levels config ignorechannel add|remove #channel`, `!levels config ignorerole add|remove @role`, `!levels reward add <level> @role`, `!levels reward remove <level>`, `!levels reward firstplace @role|off`, `!xp add|remove|set|setlevel|reset ...`.');
      if (sub === 'status') return message.reply(`**Nexus Leveling**\nEnabled: **${cfg.enabled ? 'Yes' : 'No'}**\nMessage XP cooldown: **${cfg.cooldownSeconds}s**\nMessage XP range: **${cfg.minXp}–${cfg.maxXp}**\nMessage mode: **${cfg.messageXpMode || 'random'}**\nReaction XP: **${cfg.reactionXpEnabled ? 'On' : 'Off'}** (range ${cfg.reactionMinXp}-${cfg.reactionMaxXp}, cooldown ${cfg.reactionCooldownSeconds}s)\nVoice XP: **${cfg.voiceXpEnabled ? 'On' : 'Off'}** (${cfg.voiceXpPerInterval} XP / interval; min ${cfg.voiceMinMembers} members)\nMinimum message length: **${cfg.minMessageLength || 3}** · Max level: **${cfg.maxLevel || 'Unlimited'}** · Rank color: **${cfg.rankColor || '#8b5cf6'}**\nVoice anti-AFK: **${cfg.antiAfkHours ? `${cfg.antiAfkHours}h` : 'Off'}** · First-place role: ${cfg.firstPlaceRoleId ? `<@&${cfg.firstPlaceRoleId}>` : 'Off'}\nBoost stacking: **${cfg.stackBoosts ? 'On' : 'Off'}**\nIgnored channels: ${cfg.ignoredChannels.length ? cfg.ignoredChannels.map(id => `<#${id}>`).join(', ') : 'None'}\nIgnored roles: ${cfg.ignoredRoles.length ? cfg.ignoredRoles.map(id => `<@&${id}>`).join(', ') : 'None'}\nLevel-up messages: **${cfg.levelUpMessages ? 'On' : 'Off'}**\nRewards configured: **${Object.keys(cfg.rewards).length}**`);
      if (!isSetupAuthorized(message)) return message.reply('You need Manage Server or Administrator permission to configure leveling.');
      if (sub === 'enable' || sub === 'disable') { cfg = setLevelConfig(guild.id, { enabled: sub === 'enable' }); return message.reply(`Leveling ${cfg.enabled ? '**enabled**' : '**disabled**'}.`); }
      if (sub === 'config') {
        const option = (args[1] || '').toLowerCase();
        if (option === 'cooldown') { const seconds = Number(args[2]); if (!Number.isInteger(seconds) || seconds < 5 || seconds > 3600) return usage(message, 'levels config cooldown <5-3600 seconds>'); setLevelConfig(guild.id, { cooldownSeconds: seconds }); return message.reply(`XP cooldown set to **${seconds} seconds**.`); }
        if (option === 'minlength') { const length = Number(args[2]); if (!Number.isInteger(length) || length < 1 || length > 200) return usage(message, 'levels config minlength <1-200 characters>'); setLevelConfig(guild.id, { minMessageLength: length }); return message.reply(`Messages must now contain at least **${length} characters** to earn message XP.`); }
        if (option === 'rankcolor') { const color = String(args[2] || '').toLowerCase(); if (!/^#[0-9a-f]{6}$/.test(color)) return usage(message, 'levels config rankcolor #RRGGBB'); setLevelConfig(guild.id, { rankColor: color }); return message.reply(`Rank card embed color set to **${color}**.`); }
        if (option === 'maxlevel') { const level = Number(args[2]); if (!Number.isInteger(level) || level < 0 || level > 10000) return usage(message, 'levels config maxlevel <0-10000; 0 means unlimited>'); setLevelConfig(guild.id, { maxLevel: level }); return message.reply(level === 0 ? 'Maximum level disabled; leveling is unlimited.' : `Maximum organic level set to **${level}**.`); }
        if (option === 'xp') { const min = Number(args[2]), max = Number(args[3]); if (!Number.isInteger(min) || !Number.isInteger(max) || min < 1 || max < min || max > 1000) return usage(message, 'levels config xp <min 1-1000> <max min-1000>'); setLevelConfig(guild.id, { minXp: min, maxXp: max }); return message.reply(`XP gain range set to **${min}–${max} XP**.`); }
        if (option === 'announcements') { const value = (args[2] || '').toLowerCase(); if (!['on', 'off'].includes(value)) return usage(message, 'levels config announcements <on|off>'); setLevelConfig(guild.id, { levelUpMessages: value === 'on' }); return message.reply(`Level-up announcements turned **${value}**.`); }
        if (option === 'mode') { const value = (args[2] || '').toLowerCase(); if (!['random', 'perword'].includes(value)) return usage(message, 'levels config mode <random|perword>'); setLevelConfig(guild.id, { messageXpMode: value }); return message.reply(`Message XP mode set to **${value}**.`); }
        if (option === 'reaction') {
          const subOption = (args[2] || '').toLowerCase();
          if (['on', 'off'].includes(subOption)) { setLevelConfig(guild.id, { reactionXpEnabled: subOption === 'on' }); return message.reply(`Reaction XP turned **${subOption}**.`); }
          if (subOption === 'range') { const min = Number(args[3]), max = Number(args[4]); if (!Number.isInteger(min) || !Number.isInteger(max) || min < 0 || max < min || max > 1000) return usage(message, 'levels config reaction range <min 0-1000> <max min-1000>'); setLevelConfig(guild.id, { reactionMinXp: min, reactionMaxXp: max }); return message.reply(`Reaction XP range set to **${min}–${max}**.`); }
          if (subOption === 'cooldown') { const seconds = Number(args[3]); if (!Number.isInteger(seconds) || seconds < 5 || seconds > 86400) return usage(message, 'levels config reaction cooldown <5-86400 seconds>'); setLevelConfig(guild.id, { reactionCooldownSeconds: seconds }); return message.reply(`Reaction XP cooldown set to **${seconds}s**.`); }
          if (subOption === 'awards') { const value = (args[3] || '').toLowerCase(); if (!['off', 'author', 'reactor', 'both'].includes(value)) return usage(message, 'levels config reaction awards <off|author|reactor|both>'); setLevelConfig(guild.id, { reactionAwardAuthor: ['author', 'both'].includes(value), reactionAwardReactors: ['reactor', 'both'].includes(value) }); return message.reply(`Reaction XP recipients set to **${value}**.`); }
          return usage(message, 'levels config reaction <on|off|range <min> <max>|cooldown <seconds>|awards <off|author|reactor|both>');
        }
        if (option === 'voice') {
          const subOption = (args[2] || '').toLowerCase();
          if (['on', 'off'].includes(subOption)) { setLevelConfig(guild.id, { voiceXpEnabled: subOption === 'on' }); return message.reply(`Voice XP turned **${subOption}**.`); }
          if (subOption === 'xp') { const amount = Number(args[3]); if (!Number.isInteger(amount) || amount < 0 || amount > 1000) return usage(message, 'levels config voice xp <0-1000>'); setLevelConfig(guild.id, { voiceXpPerInterval: amount }); return message.reply(`Voice XP set to **${amount} per eligible interval**.`); }
          if (subOption === 'cooldown') { const seconds = Number(args[3]); if (!Number.isInteger(seconds) || seconds < 10 || seconds > 86400) return usage(message, 'levels config voice cooldown <10-86400 seconds>'); setLevelConfig(guild.id, { voiceCooldownSeconds: seconds }); return message.reply(`Voice XP cooldown set to **${seconds}s**.`); }
          if (subOption === 'minmembers') { const count = Number(args[3]); if (!Number.isInteger(count) || count < 2 || count > 99) return usage(message, 'levels config voice minmembers <2-99>'); setLevelConfig(guild.id, { voiceMinMembers: count }); return message.reply(`Voice XP now requires **${count} active members** in a voice channel.`); }
          if (subOption === 'antiafk') { const hours = Number(args[3]); if (!Number.isFinite(hours) || hours < 0 || hours > 24) return usage(message, 'levels config voice antiafk <0-24 hours>'); setLevelConfig(guild.id, { antiAfkHours: hours }); return message.reply(hours === 0 ? 'Voice XP anti-AFK cap disabled.' : `Voice XP will stop earning after **${hours} hours** in one active voice session.`); }
          return usage(message, 'levels config voice <on|off|xp <amount>|cooldown <seconds>|minmembers <count>');
        }
        if (option === 'boost') {
          const kind = (args[2] || '').toLowerCase(); const item = kind === 'role' ? message.mentions.roles.first() : kind === 'channel' ? message.mentions.channels.first() : null; const rawPercent = (kind === 'stacking' ? args[3] : args[4] || '').toLowerCase();
          if (!['role', 'channel', 'stacking'].includes(kind)) return usage(message, 'levels config boost <role @role|channel #channel|stacking on|off> <percent|off>');
          if (kind === 'stacking') { const value = (args[3] || '').toLowerCase(); if (!['on', 'off'].includes(value)) return usage(message, 'levels config boost stacking <on|off>'); setLevelConfig(guild.id, { stackBoosts: value === 'on' }); return message.reply(`XP boost stacking turned **${value}**.`); }
          if (!item) return usage(message, `levels config boost ${kind} <${kind === 'role' ? '@role' : '#channel'}> <percent|off>`);
          const boostsKey = kind === 'role' ? 'roleBoosts' : 'channelBoosts'; const boosts = { ...cfg[boostsKey] };
          if (rawPercent === 'off') delete boosts[item.id]; else { const percent = Number(args[4]); if (!Number.isFinite(percent) || percent < 0 || percent > 500) return usage(message, `levels config boost ${kind} ${kind === 'role' ? '@role' : '#channel'} <0-500 percent|off>`); boosts[item.id] = percent; }
          setLevelConfig(guild.id, { [boostsKey]: boosts }); return message.reply(`${kind === 'role' ? item : item} XP boost ${rawPercent === 'off' ? 'removed' : `set to **${rawPercent === 'stacking' ? '' : args[4]}%**`}.`);
        }
        if (['ignorechannel', 'ignorerole'].includes(option)) {
          const action = (args[2] || '').toLowerCase(); if (!['add', 'remove'].includes(action)) return usage(message, `levels config ${option} <add|remove> <${option === 'ignorechannel' ? '#channel' : '@role'}>`);
          const item = option === 'ignorechannel' ? message.mentions.channels.first() : message.mentions.roles.first(); if (!item) return usage(message, `levels config ${option} <add|remove> <${option === 'ignorechannel' ? '#channel' : '@role'}>`);
          const key = option === 'ignorechannel' ? 'ignoredChannels' : 'ignoredRoles'; const current = cfg[key] || []; const next = action === 'add' ? [...new Set([...current, item.id])] : current.filter(id => id !== item.id); setLevelConfig(guild.id, { [key]: next }); return message.reply(`${item} ${action === 'add' ? 'added to' : 'removed from'} the XP ${option === 'ignorechannel' ? 'channel' : 'role'} exclusion list.`);
        }
        return message.reply('Use `!levels help` to see XP sources, boosters, restrictions, rewards, and leaderboard commands.');
      }
      if (sub === 'reward') {
        const action = (args[1] || '').toLowerCase();
        if (action === 'firstplace') {
          const token = String(args[2] || '').toLowerCase();
          if (token === 'off') { setLevelConfig(guild.id, { firstPlaceRoleId: null }); return message.reply('First-place role rotation disabled.'); }
          const role = message.mentions.roles.first(); if (!role) return usage(message, 'levels reward firstplace @role|off');
          if (role.position >= guild.members.me.roles.highest.position || role.permissions.has(PermissionFlagsBits.Administrator) || role.permissions.has(PermissionFlagsBits.ManageGuild)) return message.reply('Choose a non-dangerous role below the Nexus bot role.');
          setLevelConfig(guild.id, { firstPlaceRoleId: role.id }); return message.reply(`First-place leaderboard role set to ${role}. Nexus will rotate it every 10 minutes.`);
        }
        const level = Number(args[2]);
        if (!['add', 'remove'].includes(action) || !Number.isInteger(level) || level < 1 || level > 10000) return usage(message, 'levels reward add <level> @role | levels reward remove <level>');
        if (action === 'remove') { const rewards = { ...cfg.rewards }; delete rewards[String(level)]; setLevelConfig(guild.id, { rewards }); return message.reply(`Removed the role reward for level **${level}**.`); }
        const role = message.mentions.roles.first(); if (!role) return usage(message, 'levels reward add <level> @role');
        if (role.position >= guild.members.me.roles.highest.position) return message.reply('Move the Nexus bot role above the reward role before configuring it.');
        const existingReward = cfg.rewards[String(level)]; const rewardIds = Array.isArray(existingReward) ? existingReward : existingReward ? [existingReward] : []; if (rewardIds.includes(role.id)) return message.reply(`${role} is already a reward for level ${level}.`); setLevelConfig(guild.id, { rewards: { ...cfg.rewards, [String(level)]: [...rewardIds, role.id] } }); return message.reply(`Members who reach level **${level}** will receive ${[...rewardIds, role.id].map(id => `<@&${id}>`).join(', ')}.`);
      }
      return message.reply('Use `!levels help`.');
    }

    case 'xp': {
      if (!guild) return message.reply('Use this command inside a server.');
      if (!isSetupAuthorized(message)) return message.reply('You need Manage Server or Administrator permission to manage XP.');
      const action = (args[0] || '').toLowerCase();
      if (action === 'reset' && String(args[1] || '').toLowerCase() === 'server') {
        const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`xp_reset_server_confirm:${guild.id}:${message.author.id}`).setLabel('Reset all server XP').setStyle(ButtonStyle.Danger), new ButtonBuilder().setCustomId('xp_reset_server_cancel').setLabel('Cancel').setStyle(ButtonStyle.Secondary));
        return message.channel.send({ content: '⚠️ This permanently resets XP and leveling records for every member in this server. This cannot be undone.', components: [row] });
      }
      const userToken = action === 'setlevel' ? args[1] : args[1]; const user = await parseUser(message, userToken);
      if (!['add', 'remove', 'set', 'setlevel', 'reset'].includes(action) || !user) return usage(message, 'xp <add|remove|set|setlevel|reset> @user [amount|level] | xp reset server');
      const current = getUserData(guild.id, user.id); const amount = Number(args[2]);
      if (action !== 'reset' && (!Number.isInteger(amount) || amount < 0 || amount > 1000000000)) return usage(message, `xp ${action} @user <amount>`);
      let xp = action === 'reset' ? 0 : action === 'add' ? current.xp + amount : action === 'remove' ? Math.max(0, current.xp - amount) : action === 'setlevel' ? getXpRequiredForLevel(amount) : amount;
      const updated = setUserData(guild.id, user.id, { ...current, xp, lastMessageAt: current.lastMessageAt });
      return message.reply(`Updated leveling for **${user.tag}**: **${updated.xp.toLocaleString()} XP**, level **${updated.level}**.`);
    }

    case 'remind': {
      if (!guild) return message.reply('Use this command inside a server.');
      const sub = (args[0] || 'help').toLowerCase();
      if (sub === 'help') return message.reply('Reminder commands: `!remind me <duration> <message>`, `!remind list`, `!remind cancel <id>`. Durations: `30s`, `10m`, `2h`, `1d`.');
      if (sub === 'me') {
        const duration = args[1]; const text = args.slice(2).join(' ').trim();
        if (!duration || !text || !parseDuration(duration)) return usage(message, 'remind me <30s|10m|2h|1d> <message>');
        const reminder = addReminder({ guildId: guild.id, userId: message.author.id, message: text, duration });
        return message.reply(`⏰ Reminder created with ID \`${reminder.id}\`. I will DM you in ${duration}.`);
      }
      if (sub === 'list') {
        const reminders = listReminders(guild.id, message.author.id);
        return message.reply(reminders.length ? reminders.map(r => `• \`${r.id}\` — ${r.duration} — ${r.message}`).join('\n').slice(0, 1900) : 'You have no active reminders.');
      }
      if (sub === 'cancel') {
        const id = args[1]; if (!id) return usage(message, 'remind cancel <id>');
        return message.reply(cancelReminder(id) ? `Reminder \`${id}\` cancelled.` : `Reminder \`${id}\` was not found.`);
      }
      return message.reply('Use `!remind help` for reminder commands.');
    }

    case 'suggest': {
      if (!guild) return message.reply('Use this command inside a server.');
      const sub = (args[0] || 'submit').toLowerCase();
      const config = getGuildConfig(guild.id);
      if (sub === 'help') return message.reply('Use `!suggest submit <idea>` or `!suggest review <SUG-ID> <Approved|Denied|Implemented> [reason]`. Configure the suggestions channel in server settings first.');
      if (!config.channels?.suggestions) return message.reply('No suggestions channel is configured yet. Please configure the suggestions channel before using `!suggest`.');
      const suggestions = readJson(suggestionsPath, {}); const list = suggestions[guild.id] || [];
      if (sub === 'submit') {
        const idea = args.slice(1).join(' ').trim(); if (!idea) return usage(message, 'suggest submit <idea>');
        const channel = guild.channels.cache.get(config.channels.suggestions) || await guild.channels.fetch(config.channels.suggestions).catch(() => null);
        if (!channel?.isTextBased()) return message.reply('The configured suggestions channel is unavailable.');
        const id = `SUG-${Date.now()}`;
        const record = { id, authorId: message.author.id, idea, status: 'Pending', votes: { up: 0, down: 0 }, voters: { up: [], down: [] }, createdAt: Date.now() };
        list.push(record); suggestions[guild.id] = list; writeJson(suggestionsPath, suggestions);
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`suggest_up_${id}`).setLabel('Upvote').setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId(`suggest_down_${id}`).setLabel('Downvote').setStyle(ButtonStyle.Danger),
          new ButtonBuilder().setCustomId(`suggest_view_${id}`).setLabel('View Voters').setStyle(ButtonStyle.Secondary));
        const embed = new EmbedBuilder().setColor(0x10b981).setTitle(`Suggestion ${id}`).setDescription(idea).addFields(
          { name: 'Submitted By', value: `<@${message.author.id}>`, inline: true }, { name: 'Status', value: 'Pending', inline: true }, { name: 'Votes', value: '👍 0 / 👎 0', inline: true });
        await channel.send({ embeds: [embed], components: [row] });
        return message.reply(`Suggestion \`${id}\` submitted to ${channel}.`);
      }
      if (sub === 'review') {
        if (!hasPermission(message, PermissionFlagsBits.ManageMessages)) return message.reply('You need Manage Messages permission to review suggestions.');
        const id = args[1]; const decision = (args[2] || '').toLowerCase();
        const allowed = { approved: 'Approved', denied: 'Denied', implemented: 'Implemented' };
        const record = list.find(item => item.id.toLowerCase() === String(id || '').toLowerCase());
        if (!record || !allowed[decision]) return usage(message, 'suggest review <SUG-ID> <Approved|Denied|Implemented> [reason]');
        record.status = allowed[decision]; record.reviewReason = args.slice(3).join(' ') || 'No reason provided';
        writeJson(suggestionsPath, suggestions);
        return message.reply(`Suggestion ${record.id} marked as **${record.status}**.`);
      }
      return message.reply('Use `!suggest help` for usage.');
    }

    case 'rolepanel': {
      if (!guild) return message.reply('Use this command inside a server.');
      if (!hasPermission(message, PermissionFlagsBits.Administrator)) return message.reply('Administrator permission is required to manage role panels.');
      const sub = (args[0] || 'help').toLowerCase(); const panels = readJson(rolePanelsPath, {}); panels[guild.id] = panels[guild.id] || [];
      if (sub === 'help') return message.reply('Role panel: `!rolepanel add @role "Label" [description]`, `!rolepanel remove @role`, `!rolepanel send`.');
      if (sub === 'add') {
        const role = message.mentions.roles.first(); const label = args[1]?.replace(/^['"]|['"]$/g, ''); const description = args.slice(2).join(' ').replace(/^['"]|['"]$/g, '');
        if (!role || !label) return usage(message, 'rolepanel add @role "Label" [description]');
        const existing = panels[guild.id].find(item => item.roleId === role.id);
        if (existing) { existing.label = label; existing.description = description; } else panels[guild.id].push({ roleId: role.id, label, description });
        writeJson(rolePanelsPath, panels); return message.reply(`Role panel entry saved for ${role}.`);
      }
      if (sub === 'remove') {
        const role = message.mentions.roles.first(); if (!role) return usage(message, 'rolepanel remove @role');
        panels[guild.id] = panels[guild.id].filter(item => item.roleId !== role.id); writeJson(rolePanelsPath, panels);
        return message.reply(`Removed ${role} from the role panel.`);
      }
      if (sub === 'send') {
        const entries = panels[guild.id]; if (!entries.length) return message.reply('Add at least one role first with `!rolepanel add @role "Label"`.');
        const options = entries.slice(0, 25).map(item => ({ label: String(item.label || guild.roles.cache.get(item.roleId)?.name || 'Role').slice(0, 100), value: item.roleId, description: String(item.description || 'Self-assignable role').slice(0, 100) }));
        const select = new StringSelectMenuBuilder().setCustomId('selfrole_select').setPlaceholder('Select a role to add or remove').setMinValues(1).setMaxValues(options.length).addOptions(options);
        const embed = new EmbedBuilder().setTitle('Self-Assignable Roles').setDescription('Choose roles from the menu below. Select a role again to toggle it.').setColor(0x8b5cf6);
        await message.channel.send({ embeds: [embed], components: [new ActionRowBuilder().addComponents(select)] }); return message.reply('Role panel posted.');
      }
      return message.reply('Use `!rolepanel help`.');
    }

    case 'setup': {
      if (!guild) return message.reply('Use this command inside a server.');
      if (!isSetupAuthorized(message)) return message.reply('You need Manage Server or Administrator permission to use setup.');
      const sub = (args[0] || 'start').toLowerCase(); const config = getGuildConfig(guild.id);
      if (sub === 'help') return message.reply('Setup commands: `!setup start`, `!setup status`, `!setup reset`.');
      if (sub === 'status') return message.reply(`Setup status: **${config.onboarding?.active ? 'In progress' : 'Not started'}**\nPreset: **${config.onboarding?.preset || 'custom'}**\nStep: **${config.onboarding?.step || 0}**`);
      if (sub === 'reset') {
        const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('setup_reset_confirm').setLabel('Reset Setup').setStyle(ButtonStyle.Danger), new ButtonBuilder().setCustomId('setup_reset_cancel').setLabel('Keep Current Setup').setStyle(ButtonStyle.Secondary));
        return message.channel.send({ content: 'This clears Nexus setup progress but does not delete existing server data. Continue?', components: [row] });
      }
      if (sub === 'start') {
        const preset = PRESETS.custom; updateSetupState(guild.id, { active: true, step: 0, preset: 'custom', moduleList: preset.modules, modulePage: 0, completed: false, startedBy: message.author.id });
        const wizard = buildSetupWizard(guild.id); return message.channel.send({ embeds: [wizard.embed], components: wizard.components });
      }
      return message.reply('Use `!setup help`.');
    }

    case 'security': {
      if (!guild) return message.reply('Use this command inside a server.');
      if (!isSetupAuthorized(message)) return message.reply('You need Manage Server or Administrator permission to configure security.');
      const sub = (args[0] || 'status').toLowerCase();
      let cfg = getGuildSecurity(guild.id);
      if (sub === 'help') return message.reply({ embeds: [new EmbedBuilder().setColor(0x0f766e).setTitle('🛡️ NEXUS SECURITY • COMMAND CENTER').setDescription('Configure server protection with clear, grouped controls. All commands also support `.` and `?`.').addFields(
        { name: 'Protection', value: '`!security enable` · `!security disable` · `!security status`\n`!security mode alert|contain`\n`!security lockdown` · `!security unlockdown` · `!security logs`' },
        { name: 'Trusted members', value: '`!security allowlist add|remove|list @user`\n`!security allowrole add|remove|list @role`\n`!security quarantine-role @role` · `!security release @user`' },
        { name: 'Detection thresholds', value: '`!security threshold join <count> <seconds>`\n`!security threshold mentions|spam|duplicate <count> <seconds>`\n`!security spam log|delete|timeout|kick`' },
        { name: 'Join gate', value: '`!security gate status|enable|disable`\n`!security gate age|avatar|newaccount|botadd`\n`!security log #channel`' }
      ).setFooter({ text: 'NEXUS SECURITY • Prefixes: !  .  ?' })] });
      if (sub === 'enable' || sub === 'disable') {
        cfg = upsertGuildSecurity(guild.id, { enabled: sub === 'enable' ? 1 : 0, response_mode: ['alert', 'contain'].includes(cfg.response_mode) ? cfg.response_mode : 'alert' });
        return message.reply(`🛡️ Anti-raid and anti-nuke protection ${sub === 'enable' ? '**enabled**' : '**disabled**'}.`);
      }
      if (sub === 'status') return message.reply(`**Nexus Security Status**\nEnabled: **${Number(cfg.enabled) === 1 ? 'Yes' : 'No'}**\nResponse: **${cfg.response_mode || 'alert'}**\nLog channel: ${(cfg.security_log_channel || getGuildConfig(guild.id).channels?.modlog) ? `<#${cfg.security_log_channel || getGuildConfig(guild.id).channels.modlog}>` : 'Not set'}\nTrusted users: ${(cfg.allowlist || []).length} · Trusted roles: ${(cfg.trusted_roles || []).length}\nLockdown: **${cfg.lockdown_state?.active ? 'Active' : 'Inactive'}**\nRaid trigger: **${cfg.thresholds?.join_count || 8} joins / ${cfg.thresholds?.join_window_seconds || 12}s**; mentions: **${cfg.thresholds?.mention_count || 30} / ${cfg.thresholds?.mention_window_seconds || 20}s**\nJoin gate: **${Number(cfg.thresholds?.join_gate_enabled) === 1 ? 'Enabled' : 'Disabled'}** · Account age: **${cfg.thresholds?.min_account_age_days || 0} days** · Avatar action: **${cfg.thresholds?.no_avatar_action || 'log'}** · New-account action: **${cfg.thresholds?.new_account_action || 'log'}** · Bot-add action: **${cfg.thresholds?.bot_add_action || 'log'}** · Quarantine role: ${cfg.thresholds?.quarantine_role_id ? `<@&${cfg.thresholds.quarantine_role_id}>` : 'Not configured'}\nAnti-spam: **${getGuildConfig(guild.id).automod?.action || 'timeout'}** · ${getGuildConfig(guild.id).automod?.maxMessages || 7} messages / 10s · duplicate threshold ${getGuildConfig(guild.id).automod?.maxIdentical || 3}`);
      if (sub === 'mode') {
        const mode = (args[1] || '').toLowerCase(); if (!['alert', 'contain'].includes(mode)) return usage(message, 'security mode <alert|contain>');
        upsertGuildSecurity(guild.id, { enabled: 1, response_mode: mode });
        return message.reply(`Security response mode set to **${mode}**. ${mode === 'contain' ? 'Threshold events can trigger an automatic lockdown and a timeout for a manageable executor.' : 'The bot will log and alert without automatic lockdown.'}`);
      }
      if (sub === 'log') {
        const channel = message.mentions.channels.first(); if (!channel?.isTextBased()) return usage(message, 'security log #channel');
        upsertGuildSecurity(guild.id, { security_log_channel: channel.id }); return message.reply(`Security logs will be sent to ${channel}.`);
      }
      if (sub === 'allowlist') {
        const action = (args[1] || 'list').toLowerCase(); const token = args[2] || ''; const id = token.replace(/[<@!>]/g, '');
        if (action === 'list') return message.reply(`Security allowlist: ${(cfg.allowlist || []).length ? cfg.allowlist.map(x => `<@${x}>`).join(', ') : 'Empty'}`);
        if (!['add', 'remove'].includes(action) || !/^\d{17,20}$/.test(id)) return usage(message, 'security allowlist <add|remove|list> <@user|userID>');
        const next = action === 'add' ? [...new Set([...(cfg.allowlist || []), id])] : (cfg.allowlist || []).filter(x => x !== id);
        upsertGuildSecurity(guild.id, { allowlist: next }); return message.reply(action === 'add' ? `Added <@${id}> to the security allowlist.` : `Removed <@${id}> from the security allowlist.`);
      }
      if (sub === 'allowrole') {
        const action = (args[1] || 'list').toLowerCase(); const role = message.mentions.roles.first();
        if (action === 'list') return message.reply(`Trusted roles: ${(cfg.trusted_roles || []).length ? cfg.trusted_roles.map(id => `<@&${id}>`).join(', ') : 'None'}`);
        if (!['add', 'remove'].includes(action) || !role) return usage(message, 'security allowrole <add|remove|list> @role');
        const next = action === 'add' ? [...new Set([...(cfg.trusted_roles || []), role.id])] : (cfg.trusted_roles || []).filter(id => id !== role.id);
        upsertGuildSecurity(guild.id, { trusted_roles: next }); return message.reply(`${role} ${action === 'add' ? 'added to' : 'removed from'} the trusted security role list.`);
      }
      if (sub === 'spam') {
        const action = (args[1] || '').toLowerCase(); if (!['log', 'delete', 'timeout', 'kick'].includes(action)) return usage(message, 'security spam <log|delete|timeout|kick>');
        const current = getGuildConfig(guild.id);
        setGuildConfig(guild.id, { automod: { ...current.automod, action } });
        upsertGuildSecurity(guild.id, { thresholds: { ...cfg.thresholds, spam_action: action } });
        return message.reply(`Unified AutoMod action set to **${action}**. Duplicate and rapid-message detection now use one heat-based detector.`);
      }
      if (sub === 'quarantine-role') {
        const role = message.mentions.roles.first(); if (!role) return usage(message, 'security quarantine-role @role');
        const dangerous = [PermissionFlagsBits.Administrator, PermissionFlagsBits.ManageGuild, PermissionFlagsBits.ManageRoles, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.BanMembers, PermissionFlagsBits.KickMembers, PermissionFlagsBits.ManageWebhooks, PermissionFlagsBits.ManageMessages, PermissionFlagsBits.ModerateMembers, PermissionFlagsBits.ManageEvents, PermissionFlagsBits.ManageThreads, PermissionFlagsBits.ManageNicknames];
        if (dangerous.some(permission => role.permissions.has(permission))) return message.reply('The quarantine role must not have Administrator, moderation, role, channel, or webhook-management permissions.');
        if (!guild.members.me?.permissions.has(PermissionFlagsBits.ManageRoles) || role.position >= guild.members.me.roles.highest.position) return message.reply('Grant Manage Roles and move the Nexus role above the quarantine role first.');
        const thresholds = { ...cfg.thresholds, quarantine_role_id: role.id }; upsertGuildSecurity(guild.id, { thresholds }); return message.reply(`Quarantine role set to ${role}. In contain mode, Nexus can remove manageable roles from suspicious executors and apply this role; use \`!security release @user\` to restore saved roles.`);
      }
      if (sub === 'release') {
        const user = await parseUser(message, args[1]); if (!user) return usage(message, 'security release @user');
        const result = await protection.releaseQuarantinedMember(guild, user.id);
        return message.reply(result.restored ? `Quarantine released for ${user}. Restored ${result.roles} role(s).` : `Could not release ${user}: ${result.reason}.`);
      }
      if (sub === 'gate') {
        const option = (args[1] || 'status').toLowerCase(); const thresholds = { ...cfg.thresholds };
        if (option === 'status') return message.reply(`**Nexus Join Gate**\nEnabled: **${Number(thresholds.join_gate_enabled) === 1 ? 'Yes' : 'No'}**\nMinimum account age: **${thresholds.min_account_age_days || 0} days**\nNo custom avatar action: **${thresholds.no_avatar_action || 'log'}**\nNew account action: **${thresholds.new_account_action || 'log'}**\nUnauthorized bot-add action: **${thresholds.bot_add_action || 'log'}**\nActions supported: log, timeout, kick, ban (bot-add supports log, kick, ban).`);
        if (option === 'enable' || option === 'disable') { thresholds.join_gate_enabled = option === 'enable' ? 1 : 0; upsertGuildSecurity(guild.id, { enabled: 1, thresholds }); return message.reply(`Join gate ${option === 'enable' ? '**enabled**' : '**disabled**'}. Current filters: account-age and no-custom-avatar. Set actions to log first, then enable enforcement after testing.`); }
        if (option === 'age') { const days = Number(args[2]); if (!Number.isInteger(days) || days < 0 || days > 3650) return usage(message, 'security gate age <0-3650 days>'); thresholds.min_account_age_days = days; upsertGuildSecurity(guild.id, { thresholds }); return message.reply(`Join-gate minimum account age set to **${days} days**. Set 0 to disable the age check.`); }
        if (option === 'avatar' || option === 'newaccount') { const action = (args[2] || '').toLowerCase(); if (!['log', 'timeout', 'kick', 'ban'].includes(action)) return usage(message, `security gate ${option} <log|timeout|kick|ban>`); thresholds[option === 'avatar' ? 'no_avatar_action' : 'new_account_action'] = action; upsertGuildSecurity(guild.id, { thresholds }); return message.reply(`Join-gate ${option === 'avatar' ? 'no-custom-avatar' : 'new-account'} action set to **${action}**.`); }
        if (option === 'botadd') { const action = (args[2] || '').toLowerCase(); if (!['log', 'kick', 'ban'].includes(action)) return usage(message, 'security gate botadd <log|kick|ban>'); thresholds.bot_add_action = action; upsertGuildSecurity(guild.id, { thresholds }); return message.reply(`Unauthorized bot-add action set to **${action}**. Enable the join gate to activate this filter.`); }
        return usage(message, 'security gate <status|enable|disable|age <days>|avatar <log|timeout|kick|ban>|newaccount <log|timeout|kick|ban>|botadd <log|kick|ban>');
      }
      if (sub === 'threshold') {
        const key = (args[1] || '').toLowerCase(); const thresholds = { ...cfg.thresholds };
        if (['join', 'mentions', 'spam', 'duplicate'].includes(key)) {
          const count = Number(args[2]), seconds = Number(args[3]);
          const minCount = key === 'mentions' ? 5 : key === 'join' ? 3 : key === 'spam' ? 4 : 3;
          if (!Number.isInteger(count) || count < minCount || count > 500 || !Number.isInteger(seconds) || seconds < 3 || seconds > 120) return usage(message, `security threshold ${key} <${minCount}-500 count> <3-120 seconds>`);
          if (key === 'join') { thresholds.join_count = count; thresholds.join_window_seconds = seconds; }
          else if (key === 'mentions') { thresholds.mention_count = count; thresholds.mention_window_seconds = seconds; }
          else if (key === 'spam') { thresholds.spam_count = count; thresholds.spam_window_seconds = seconds; }
          else { thresholds.duplicate_count = count; thresholds.duplicate_window_seconds = seconds; }
          upsertGuildSecurity(guild.id, { thresholds });
          if (key === 'spam' || key === 'duplicate') {
            const current = getGuildConfig(guild.id);
            const patch = key === 'spam' ? { maxMessages: count, heatWindowSeconds: seconds } : { maxIdentical: count, duplicateWindowSeconds: seconds };
            setGuildConfig(guild.id, { automod: { ...current.automod, ...patch } });
          }
          return message.reply(`Anti-${key === 'join' ? 'raid join' : key === 'mentions' ? 'raid mention' : key} threshold set to **${count} events in ${seconds} seconds**.`);
        }
        const allowed = Object.keys(protection.DEFAULT_THRESHOLDS).filter(name => !['join_count', 'join_window_seconds', 'mention_count', 'mention_window_seconds', 'join_gate_enabled', 'min_account_age_days', 'no_avatar_action', 'new_account_action', 'bot_add_action', 'spam_action', 'spam_count', 'spam_window_seconds', 'duplicate_count', 'duplicate_window_seconds'].includes(name));
        const count = Number(args[2]); if (!allowed.includes(key) || !Number.isInteger(count) || count < 1 || count > 100) return usage(message, `security threshold <${allowed.join('|')}> <1-100>`);
        thresholds[key] = count; upsertGuildSecurity(guild.id, { thresholds }); return message.reply(`Anti-nuke threshold for **${key}** set to **${count} events per minute**.`);
      }
      if (sub === 'lockdown' || sub === 'panic') {
        const result = await protection.applyLockdown(guild, `${sub === 'panic' ? 'Panic mode' : 'Manual lockdown'} requested by ${message.author.tag}`);
        return message.reply(result.reason === 'missing_permissions' ? 'I need Manage Channels permission to apply a lockdown.' : result.reason === 'all_failed' ? `I could not lock any channels. Failed: ${result.failed}. Check my channel permissions.` : result.applied ? `🔒 ${sub === 'panic' ? 'Panic mode activated' : 'Lockdown applied'} to ${result.count} channel(s). Failed: ${result.failed || 0}. Use !security unlockdown to restore permissions.` : 'A lockdown is already active.');
      }
      if (sub === 'unlockdown') {
        const result = await protection.restoreLockdown(guild, message.author.id);
        return message.reply(result.reason === 'not_active' ? 'No active Nexus lockdown was found.' : `🔓 Lockdown restore finished. Restored: ${result.restored}; failed: ${result.failed}.`);
      }
      if (sub === 'logs') {
        const incidents = getIncidents(guild.id, 10); return message.reply(incidents.length ? incidents.map(i => `• **${i.type}** — ${i.summary}`).join('\n').slice(0, 1900) : 'No security incidents recorded yet.');
      }
      return message.reply('Use `!security help`.');
    }

    case 'welcome': {
      if (!guild) return message.reply('Use this command inside a server.');
      if (!isSetupAuthorized(message)) return message.reply('You need Manage Server or Administrator permission to configure welcome and verification.');
      const sub = (args[0] || 'status').toLowerCase(); const cfg = onboarding.getOnboarding(guild.id);
      if (sub === 'help') return message.reply({ embeds: [new EmbedBuilder().setColor(0x0d9488).setTitle('👋 NEXUS WELCOME • SETUP GUIDE').setDescription('Build a clean member arrival and verification experience. Requires Manage Server or Administrator.').addFields(
        { name: 'Welcome & leave messages', value: '`!welcome setup #channel`\n`!welcome message <text>`\n`!welcome leave #channel`\n`!welcome leavemessage <text>`\nPlaceholders: `{member}`, `{server}`, `{count}`' },
        { name: 'Verification', value: '`!welcome verify #channel @verifiedRole [@unverifiedRole]`\n`!welcome gate enable|disable`\n`!welcome panel`' },
        { name: 'Member automation', value: '`!welcome autorole @role|off`\n`!welcome dm on|off`\n`!welcome status`' }
      ).setFooter({ text: 'NEXUS WELCOME • Prefixes: !  .  ?' })] });
      if (sub === 'status') return message.reply(`**Welcome & Verification**\nWelcome channel: ${cfg.welcomeChannelId ? `<#${cfg.welcomeChannelId}>` : 'Not set'}\nLeave channel: ${cfg.leaveChannelId ? `<#${cfg.leaveChannelId}>` : 'Not set'}\nWelcome DM: **${cfg.dmEnabled ? 'On' : 'Off'}**\nAuto-role: ${cfg.autoRoleId ? `<@&${cfg.autoRoleId}>` : 'Not set'}\nVerification: **${cfg.verificationEnabled ? 'Enabled' : 'Disabled'}**\nGate: **${cfg.gateEnabled ? 'Enabled' : 'Disabled'}**\nVerification channel: ${cfg.verificationChannelId ? `<#${cfg.verificationChannelId}>` : 'Not set'}\nVerified role: ${cfg.verifiedRoleId ? `<@&${cfg.verifiedRoleId}>` : 'Not set'}\nUnverified role: ${cfg.unverifiedRoleId ? `<@&${cfg.unverifiedRoleId}>` : 'Not set'}`);
      if (sub === 'setup') {
        const channel = message.mentions.channels.first(); if (!channel?.isTextBased()) return usage(message, 'welcome setup #channel');
        onboarding.setOnboarding(guild.id, { welcomeChannelId: channel.id }); return message.reply(`Welcome messages will be sent to ${channel}.`);
      }
      if (sub === 'message') {
        const text = message.content.replace(/^\s*[!.?]welcome\s+message\s*/i, '').trim();
        if (!text) return usage(message, 'welcome message Welcome {member} to {server}!');
        onboarding.setOnboarding(guild.id, { welcomeMessage: text.slice(0, 1800) }); return message.reply('Welcome message updated. Placeholders: `{member}`, `{server}`, `{count}`.');
      }
      if (sub === 'leave') { const channel = message.mentions.channels.first(); if (!channel?.isTextBased()) return usage(message, 'welcome leave #channel'); onboarding.setOnboarding(guild.id, { leaveChannelId: channel.id }); return message.reply(`Member departure messages will be sent to ${channel}.`); }
      if (sub === 'leavemessage') { const text = message.content.replace(/^\s*[!.?]welcome\s+leavemessage\s*/i, '').trim(); if (!text) return usage(message, 'welcome leavemessage {member} left {server}.'); onboarding.setOnboarding(guild.id, { leaveMessage: text.slice(0, 1800) }); return message.reply('Departure message updated. Placeholders: `{member}`, `{server}`, `{count}`.'); }
      if (sub === 'verify') {
        if (cfg.gateEnabled) return message.reply('Disable the verification gate with `!welcome gate disable` before changing verification roles or channels.');
        const channelId = mentionedIdsInOrder(message.content, /<#(\d{17,20})>/g)[0];
        const channel = (channelId && (guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId).catch(() => null))) || message.mentions.channels.first();
        const roleIds = mentionedIdsInOrder(message.content, /<@&(\d{17,20})>/g);
        const verifiedRole = roleIds[0] ? (guild.roles.cache.get(roleIds[0]) || await guild.roles.fetch(roleIds[0]).catch(() => null)) : null;
        const unverifiedRole = roleIds[1] ? (guild.roles.cache.get(roleIds[1]) || await guild.roles.fetch(roleIds[1]).catch(() => null)) : null;
        if (!channel?.isTextBased() || !verifiedRole) return usage(message, 'welcome verify #channel @Verified @Unverified');
        if (unverifiedRole && verifiedRole.id === unverifiedRole.id) return message.reply('The Verified and Unverified roles must be different roles.');
        const botMember = guild.members.me;
        if (!botMember?.permissions.has(PermissionFlagsBits.ManageRoles) || verifiedRole.position >= botMember.roles.highest.position || (unverifiedRole && unverifiedRole.position >= botMember.roles.highest.position)) return message.reply('Move the Nexus bot role above both verification roles and grant Manage Roles before configuring verification.');
        const updated = onboarding.setOnboarding(guild.id, { verificationEnabled: true, verificationChannelId: channel.id, verifiedRoleId: verifiedRole.id, unverifiedRoleId: unverifiedRole?.id || null });
        await channel.send(onboarding.makeVerifyPanel(guild, updated));
        return message.reply({ embeds: [buildModerationEmbed({ title: '✅ Verification Configured', description: `Verification panel posted in ${channel}. The role mapping below follows the exact order of your command.`, color: 0x22c55e, guild, fields: [
          { name: 'Verified role (assigned after success)', value: `<@&${verifiedRole.id}>`, inline: true },
          { name: 'Unverified role (removed after success)', value: unverifiedRole ? `<@&${unverifiedRole.id}>` : 'Not configured', inline: true },
          { name: 'Next step', value: 'Check channel permissions, then enable the gate with `!welcome gate enable` only after testing the role mapping.', inline: false }
        ] })] });
      }
      if (sub === 'autorole') {
        const token = (args[1] || '').toLowerCase();
        if (token === 'off') { onboarding.setOnboarding(guild.id, { autoRoleId: null }); return message.reply('Welcome auto-role disabled.'); }
        const role = message.mentions.roles.first(); if (!role) return usage(message, 'welcome autorole @role|off');
        if (role.position >= guild.members.me.roles.highest.position) return message.reply('Move the Nexus bot role above the auto-role first.');
        onboarding.setOnboarding(guild.id, { autoRoleId: role.id }); return message.reply(`New members will receive ${role} when they join.`);
      }
      if (sub === 'dm') {
        const value = (args[1] || '').toLowerCase(); if (!['on', 'off'].includes(value)) return usage(message, 'welcome dm <on|off>');
        onboarding.setOnboarding(guild.id, { dmEnabled: value === 'on' }); return message.reply(`Welcome DMs turned **${value}**. Some members may have DMs disabled.`);
      }
      if (sub === 'gate') {
        const action = (args[1] || '').toLowerCase();
        if (action === 'enable') {
          try { const result = await onboarding.applyVerificationGate(guild, cfg); return message.reply(result.reason === 'already_active' ? 'The verification gate is already active.' : `🔐 Verification gate enabled across ${result.count} channel(s). Unverified members can access the welcome/verification channels; other channel overwrites were saved for restoration.`); }
          catch (error) { return message.reply(`Could not enable verification gate: ${error.message}`); }
        }
        if (action === 'disable') {
          const result = await onboarding.removeVerificationGate(guild, cfg); return message.reply(result.reason === 'not_active' ? 'The verification gate is not active.' : result.failed ? `Gate restoration is incomplete. Restored ${result.restored}; failed: ${result.failed}. The saved snapshot is retained; run !welcome gate disable again after fixing permissions.` : `Verification gate disabled. Restored ${result.restored} channel(s).`);
        }
        return usage(message, 'welcome gate <enable|disable>');
      }
      if (sub === 'panel') {
        if (!cfg.verificationEnabled || !cfg.verificationChannelId) return message.reply('Configure verification first with `!welcome verify #channel @verifiedRole [@unverifiedRole]`.');
        const channel = guild.channels.cache.get(cfg.verificationChannelId) || await guild.channels.fetch(cfg.verificationChannelId).catch(() => null);
        if (!channel?.isTextBased()) return message.reply('The configured verification channel no longer exists.');
        await channel.send(onboarding.makeVerifyPanel(guild, cfg)); return message.reply(`Verification panel reposted in ${channel}.`);
      }
      return message.reply('Use `!welcome help`.');
    }

    case 'ticket': {
      if (!guild) return message.reply('Use this command inside a server.');
      const sub = (args[0] || 'help').toLowerCase(); const config = getGuildConfig(guild.id);
      const isTicketStaff = ticket => Boolean(hasPermission(message, PermissionFlagsBits.ManageChannels) || hasPermission(message, PermissionFlagsBits.Administrator) || (ticket?.staff_role_id && message.member?.roles?.cache?.has(ticket.staff_role_id)));
      const ticket = getTicketRecord(guild.id, message.channel.id);
      const safeName = value => String(value || '').toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').slice(0, 90) || 'ticket';
      if (sub === 'help') return message.reply('Ticket commands: `!ticket setup #category @staffrole [#logchannel]`, `!ticket panel [title]`, `!ticket panel --title "Title" --description "Instructions" --banner https://...`, `!ticket claim`, `!ticket unclaim`, `!ticket close [reason]`, `!ticket info`, `!ticket priority <Low|Normal|High|Urgent>`, `!ticket rename <name>`, `!ticket add @user`, `!ticket remove @user`, `!ticket transcript`, `!ticket notes`, `!ticket stats`, `!ticket transfer @staffrole`, `!ticket reopen`, `!ticket close_request`, `!ticket autoclose <hours>`.');
      if (sub === 'setup') {
        if (!isSetupAuthorized(message)) return message.reply('You need Manage Server permission to configure tickets.');
        const channelIds = mentionedIdsInOrder(message.content, /<#(\d{17,20})>/g);
        const mentionedChannels = [];
        for (const id of channelIds) {
          const channel = guild.channels.cache.get(id) || await guild.channels.fetch(id).catch(() => null);
          if (channel) mentionedChannels.push(channel);
        }
        const category = mentionedChannels.find(c => c.type === ChannelType.GuildCategory);
        const roleId = mentionedIdsInOrder(message.content, /<@&(\d{17,20})>/g)[0];
        const role = roleId ? (guild.roles.cache.get(roleId) || await guild.roles.fetch(roleId).catch(() => null)) : message.mentions.roles.first();
        if (!category || !role) return usage(message, 'ticket setup #ticket-category @Staff #ticket-logs');
        const log = mentionedChannels.find(c => c.id !== category.id && c.isTextBased());
        if (log && !log.isTextBased()) return message.reply('Ticket logs must be a text channel.');
        setGuildConfig(guild.id, { ...config, ticketStaffRoleId: role.id, channels: { ...config.channels, ticketCategory: category.id, ...(log ? { tickets: log.id } : {}) } });
        return message.reply({ embeds: [buildModerationEmbed({ title: '🎫 Ticket System Configured', description: 'Nexus has saved the ticket category, staff role and ticket-log channel.', color: 0x7c3aed, guild, fields: [
          { name: 'Ticket category', value: `<#${category.id}>`, inline: true }, { name: 'Staff role', value: `<@&${role.id}>`, inline: true }, { name: 'Ticket logs', value: log ? `<#${log.id}>` : 'Not changed', inline: true },
          { name: 'Next step', value: 'Post a support panel with `!ticket panel`.', inline: false }
        ] })] });
      }
      if (sub === 'panel') {
        if (!isSetupAuthorized(message)) return message.reply('You need Manage Server permission to publish a ticket panel.');
        const readFlag = name => { const i = args.findIndex(value => value.toLowerCase() === name); return i >= 0 ? args[i + 1] : null; };
        const titleFlag = readFlag('--title'); const descriptionFlag = readFlag('--description'); const bannerUrl = readFlag('--banner');
        const flagIndices = args.map((value, index) => ['--title', '--description', '--banner'].includes(value.toLowerCase()) ? index : -1).filter(index => index >= 0);
        const title = titleFlag || (flagIndices.length ? args.slice(1, flagIndices[0]).join(' ') : args.slice(1).join(' ')) || 'NEXUS SUPPORT CENTER';
        const description = descriptionFlag || 'Welcome to **Nexus Support**. Choose the category that best matches your request.\n\n🛠️ **Support** · General help\n🐛 **Bug Report** · Report an issue\n💡 **Feature Request** · Suggest an improvement\n🤝 **Partnership** · Business inquiries\n💳 **Billing** · Payment or purchase questions\n🚩 **User Report** · Report a member\n📌 **Other** · Anything else\n\nYour ticket is private. Please provide accurate details and avoid opening duplicate tickets.';
        if (bannerUrl && !/^https:\/\//i.test(bannerUrl)) return message.reply('The banner URL must be a direct HTTPS URL.');
        const embed = new EmbedBuilder().setColor(0x7c3aed).setAuthor({ name: `${guild.name} • Nexus Support`, iconURL: guild.iconURL({ size: 128 }) || undefined }).setTitle(`🎫 ${title}`.slice(0, 256)).setDescription(description.slice(0, 3500)).addFields({ name: '🔒 Private tickets', value: 'Only you and authorized support staff can see your ticket.', inline: true }, { name: '⚡ What happens next?', value: 'A support channel is created after you submit the ticket form.', inline: true }).setFooter({ text: 'Nexus Support • Clear details help us respond faster' }).setTimestamp();
        if (bannerUrl) embed.setImage(bannerUrl);
        const select = new StringSelectMenuBuilder().setCustomId('ticket_category_select').setPlaceholder('Choose a ticket category…').addOptions([{ label: 'Support', value: 'Support', description: 'General questions and help', emoji: '🛠️' }, { label: 'Bug Report', value: 'Bug Report', description: 'Report a bug or technical issue', emoji: '🐛' }, { label: 'Feature Request', value: 'Feature Request', description: 'Suggest an improvement', emoji: '💡' }, { label: 'Partnership', value: 'Partnership', description: 'Business and partnership inquiries', emoji: '🤝' }, { label: 'Billing', value: 'Billing', description: 'Payments and purchases', emoji: '💳' }, { label: 'User Report', value: 'User Report', description: 'Report a member', emoji: '🚩' }, { label: 'Other', value: 'Other', description: 'Other requests', emoji: '📌' }]);
        await message.channel.send({ embeds: [embed], components: [new ActionRowBuilder().addComponents(select)] }); return message.reply('Ticket panel posted.');
      }
      if (sub === 'autoclose') {
        if (!isSetupAuthorized(message)) return message.reply('You need Manage Server permission to configure auto-close.');
        const hours = Number(args[1]); if (!Number.isInteger(hours) || hours < 0 || hours > 720) return usage(message, 'ticket autoclose <0-720 hours>');
        setGuildConfig(guild.id, { ...config, ticketAutoCloseHours: hours }); return message.reply(hours === 0 ? 'Automatic ticket closure disabled.' : `Tickets will be warned and auto-closed after ${hours} hours of inactivity.`);
      }
      if (sub === 'stats') {
        if (!isSetupAuthorized(message)) return message.reply('You need Manage Server permission to view ticket statistics.');
        const totals = db.prepare("SELECT COUNT(*) total, SUM(CASE WHEN status IN ('open','claimed') THEN 1 ELSE 0 END) open, SUM(CASE WHEN status='closed' THEN 1 ELSE 0 END) closed FROM tickets WHERE guild_id=?").get(guild.id);
        const ratings = db.prepare('SELECT COUNT(*) count, AVG(rating) average FROM ticket_ratings WHERE guild_id=?').get(guild.id);
        return message.reply({ embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle('Nexus Ticket Statistics').addFields({ name: 'All tickets', value: String(totals.total || 0), inline: true }, { name: 'Open', value: String(totals.open || 0), inline: true }, { name: 'Closed', value: String(totals.closed || 0), inline: true }, { name: 'Ratings', value: String(ratings.count || 0), inline: true }, { name: 'Average rating', value: ratings.average == null ? 'Not rated yet' : `${Number(ratings.average).toFixed(2)} / 5`, inline: true })] });
      }
      if (sub === 'close_request') {
        if (!ticket) return message.reply('Use this inside your open ticket.');
        if (ticket.owner_id !== message.author.id && !isTicketStaff(ticket)) return message.reply('Only the ticket creator or support staff can request closure.');
        db.prepare("UPDATE tickets SET close_requested_at=? WHERE channel_id=? AND status IN ('open','claimed')").run(Date.now(), message.channel.id);
        addEvent(message.channel.id, 'close_requested', message.author.id);
        return message.reply(`${ticket.staff_role_id ? `<@&${ticket.staff_role_id}> ` : ''}🔒 <@${ticket.owner_id}> has requested that this ticket be closed. Staff can use !ticket close when ready.`);
      }
      if (sub === 'reopen') {
        if (!isSetupAuthorized(message)) return message.reply('Only server administrators can reopen archived tickets.');
        const closed = db.prepare("SELECT * FROM tickets WHERE guild_id=? AND channel_id=? AND status='closed'").get(guild.id, message.channel.id);
        if (!closed) return message.reply('This channel is not a closed ticket.');
        db.prepare("UPDATE tickets SET status='open',closed_at=NULL,closed_by=NULL,close_reason=NULL,last_activity_at=? WHERE channel_id=?").run(Date.now(), message.channel.id);
        await message.channel.setName(message.channel.name.replace(/^closed-/, '').slice(0, 100)).catch(() => {});
        await message.channel.permissionOverwrites.edit(closed.owner_id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true }).catch(() => {});
        addEvent(message.channel.id, 'reopened', message.author.id); return message.reply('🔓 Ticket reopened.');
      }
      if (!ticket) return message.reply('This command must be used inside a registered ticket channel.');
      if (['claim','unclaim','close','priority','rename','add','remove','transcript','notes','transfer'].includes(sub) && !isTicketStaff(ticket)) return message.reply('Only authorized support staff can use this action.');
      if (sub === 'claim') {
        const result = db.prepare("UPDATE tickets SET claimed_by=?,claimed_at=?,status='claimed' WHERE channel_id=? AND status='open' AND claimed_by IS NULL").run(message.author.id, Date.now(), message.channel.id);
        if (!result.changes) return message.reply('This ticket is already claimed or is not open.');
        addEvent(message.channel.id, 'claimed', message.author.id); return message.reply(`Ticket claimed by ${message.author}.`);
      }
      if (sub === 'unclaim') {
        const result = db.prepare("UPDATE tickets SET claimed_by=NULL,claimed_at=NULL,status='open' WHERE channel_id=? AND status='claimed' AND (claimed_by=? OR ?=1)").run(message.channel.id, message.author.id, isSetupAuthorized(message) ? 1 : 0);
        if (!result.changes) return message.reply('Only the assigned staff member or an administrator can unclaim this ticket.');
        addEvent(message.channel.id, 'unclaimed', message.author.id); return message.reply('Ticket returned to the support queue.');
      }
      if (sub === 'close') {
        const reason = args.slice(1).join(' ') || 'No reason provided';
        await message.reply('Closing ticket, saving the transcript, and preparing the closure report…');
        const result = await closeTicketAndTranscript(message.client, message.channel, message.author, reason);
        if (!result.ok) return message.channel.send(result.reason === 'already-closing-or-closed' ? 'This ticket is already closing or closed.' : 'Could not close this ticket.').catch(() => {});
        return;
      }
      if (sub === 'info') {
        const embed = new EmbedBuilder().setColor(0x7c3aed).setTitle(`🎫 Ticket ${ticket.ticket_id}`).addFields({ name: 'Creator', value: `<@${ticket.owner_id}>`, inline: true }, { name: 'Category', value: ticket.category || 'Support', inline: true }, { name: 'Status', value: ticket.status, inline: true }, { name: 'Priority', value: ticket.priority || 'Normal', inline: true }, { name: 'Claimed by', value: ticket.claimed_by ? `<@${ticket.claimed_by}>` : 'Not assigned', inline: true }, { name: 'Opened', value: `<t:${Math.floor(ticket.created_at / 1000)}:F>`, inline: true }, { name: 'Subject', value: (ticket.subject || 'Not provided').slice(0, 1024) }, { name: 'Description', value: (ticket.description || 'Not provided').slice(0, 1024) });
        return message.reply({ embeds: [embed] });
      }
      if (sub === 'priority') {
        const level = (args[1] || '').toLowerCase(); const allowed = { low: 'Low', normal: 'Normal', high: 'High', urgent: 'Urgent' };
        if (!allowed[level]) return usage(message, 'ticket priority <Low|Normal|High|Urgent>');
        db.prepare('UPDATE tickets SET priority=? WHERE channel_id=?').run(allowed[level], message.channel.id); addEvent(message.channel.id, 'priority_changed', message.author.id, { priority: allowed[level] });
        return message.reply(`Ticket priority set to **${allowed[level]}**.`);
      }
      if (sub === 'rename') {
        const name = safeName(args.slice(1).join('-')); await message.channel.setName(name); addEvent(message.channel.id, 'renamed', message.author.id, { name }); return message.reply(`Ticket renamed to **${name}**.`);
      }
      if (sub === 'add' || sub === 'remove') {
        const user = await parseUser(message, args[1]); if (!user) return usage(message, `ticket ${sub} @user`);
        const member = await guild.members.fetch(user.id).catch(() => null); if (!member) return message.reply('That member is not in this server.');
        if (sub === 'add') await message.channel.permissionOverwrites.edit(user.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true });
        else { if (user.id === ticket.owner_id) return message.reply('You cannot remove the ticket creator.'); await message.channel.permissionOverwrites.delete(user.id).catch(() => {}); }
        addEvent(message.channel.id, sub === 'add' ? 'participant_added' : 'participant_removed', message.author.id, { userId: user.id });
        return message.reply(sub === 'add' ? `Added <@${user.id}> to this ticket.` : `Removed <@${user.id}> from this ticket.`);
      }
      if (sub === 'transfer') {
        const role = message.mentions.roles.first(); if (!role || role.id === guild.roles.everyone.id) return usage(message, 'ticket transfer @staffrole');
        const oldRole = ticket.staff_role_id; if (oldRole) await message.channel.permissionOverwrites.delete(oldRole).catch(() => {});
        await message.channel.permissionOverwrites.edit(role.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true });
        db.prepare('UPDATE tickets SET staff_role_id=? WHERE channel_id=?').run(role.id, message.channel.id); addEvent(message.channel.id, 'transferred', message.author.id, { fromRoleId: oldRole, toRoleId: role.id });
        return message.reply(`Ticket transferred to ${role}.`);
      }
      if (sub === 'transcript') {
        const messages = await fetchAllMessages(message.channel); const html = makeTranscript(message.channel, messages);
        const out = path.join(__dirname, '..', 'data', 'transcripts', `ticket-${message.channel.id}-manual.html`); fs.mkdirSync(path.dirname(out), { recursive: true }); fs.writeFileSync(out, html, 'utf8');
        return message.reply({ content: `Transcript generated (${messages.length} recorded messages).`, files: [new AttachmentBuilder(out, { name: `nexus-ticket-${message.channel.id}-transcript.html` })] });
      }
      if (sub === 'notes') {
        const thread = await message.channel.threads.create({ name: `staff-notes-${message.channel.id.slice(-6)}`, autoArchiveDuration: 1440, type: ChannelType.PrivateThread, invitable: false, reason: 'Private staff notes for ticket' });
        await thread.members.add(message.author.id).catch(() => {});
        if (ticket.staff_role_id) { const role = guild.roles.cache.get(ticket.staff_role_id); if (role) for (const [, member] of role.members) await thread.members.add(member.id).catch(() => {}); }
        addEvent(message.channel.id, 'staff_notes_created', message.author.id, { threadId: thread.id }); return message.reply(`Private staff notes thread created: ${thread}.`);
      }
      return message.reply('Unknown ticket action. Use `!ticket help`.');
    }

    default:
      return message.reply(`Unknown command. Use \`${PREFIXES[0]}help\`, \`${PREFIXES[1]}help\`, or \`${PREFIXES[2]}help\`.`);
  }
}

module.exports = { PREFIXES, runPrefixCommand };
