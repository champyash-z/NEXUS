require('dotenv').config();

function getOwnerSettings() {
  return {
    ownerId: String(process.env.OWNER_ID || '').trim(),
    ownerUsername: String(process.env.OWNER_USERNAME || '').trim().toLowerCase(),
  };
}

function isBotOwner(user) {
  const { ownerId, ownerUsername } = getOwnerSettings();
  const rawUserId = typeof user === 'object' ? user?.id : user;
  const rawUsername = typeof user === 'object' ? user?.username : null;
  const userId = String(rawUserId || '').trim();
  const username = String(rawUsername || '').trim().toLowerCase();

  if (userId && ownerId && userId === ownerId) return true;
  if (username && ownerUsername && username === ownerUsername) return true;
  return false;
}

function hasElevatedSecurityAccess(member, guildId, guildConfig = null) {
  if (!member || !guildId) return false;
  if (isBotOwner(member.id)) return true;
  if (member.permissions?.has('Administrator')) return true;
  if (member.id === member.guild?.ownerId) return true;

  const config = guildConfig || { trusted_roles: [], trusted_users: [], allowlist: [] };
  const userTrusted = Array.isArray(config.trusted_users) && config.trusted_users.includes(member.id);
  const roleTrusted = Array.isArray(config.trusted_roles) && member.roles?.cache?.some(role => config.trusted_roles.includes(role.id));
  const allowlisted = Array.isArray(config.allowlist) && config.allowlist.includes(member.id);
  return Boolean(userTrusted || roleTrusted || allowlisted);
}

function validateGuildContext(interaction) {
  if (!interaction || !interaction.guildId) {
    return { ok: false, reason: 'This command can only be used in a server.' };
  }
  return { ok: true };
}

module.exports = {
  getOwnerSettings,
  isBotOwner,
  hasElevatedSecurityAccess,
  validateGuildContext,
};
