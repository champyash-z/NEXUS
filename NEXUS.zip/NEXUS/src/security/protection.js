const { PermissionFlagsBits, AuditLogEvent, EmbedBuilder } = require('discord.js');
const { getGuildSecurity, upsertGuildSecurity, addIncident, addLockdownRecord, getIncidents } = require('../database/database');
const { getGuildConfig } = require('../utils/config');

const windows = new Map();
const joinWindows = new Map();
const mentionWindows = new Map();
const DEFAULT_THRESHOLDS = {
  channel_delete: 3, channel_create: 8, role_delete: 3, role_create: 8,
  member_ban: 4, member_kick: 6, member_prune: 1, member_role_update: 4, webhook_create: 2, webhook_delete: 2, webhook_update: 4, role_update: 4, guild_update: 2,
  channel_update: 8, channel_overwrite_create: 3, channel_overwrite_update: 3, channel_overwrite_delete: 3, integration_create: 1, integration_delete: 1, emoji_delete: 5, sticker_delete: 5, invite_create: 8, invite_delete: 8, bot_add: 1, join_count: 8, join_window_seconds: 12, mention_count: 30, mention_window_seconds: 20,
  join_gate_enabled: 0, min_account_age_days: 0, no_avatar_action: 'log', new_account_action: 'log', bot_add_action: 'log',
  spam_count: 8, spam_window_seconds: 8, duplicate_count: 4, duplicate_window_seconds: 20, spam_action: 'timeout',
};
const EVENT_NAMES = {
  [AuditLogEvent.ChannelDelete]: 'channel_delete', [AuditLogEvent.ChannelCreate]: 'channel_create',
  [AuditLogEvent.ChannelUpdate]: 'channel_update',
  [AuditLogEvent.ChannelOverwriteCreate]: 'channel_overwrite_create', [AuditLogEvent.ChannelOverwriteUpdate]: 'channel_overwrite_update', [AuditLogEvent.ChannelOverwriteDelete]: 'channel_overwrite_delete',
  [AuditLogEvent.WebhookDelete]: 'webhook_delete', [AuditLogEvent.WebhookUpdate]: 'webhook_update', [AuditLogEvent.MemberPrune]: 'member_prune',
  [AuditLogEvent.IntegrationCreate]: 'integration_create', [AuditLogEvent.IntegrationDelete]: 'integration_delete', [AuditLogEvent.EmojiDelete]: 'emoji_delete', [AuditLogEvent.StickerDelete]: 'sticker_delete', [AuditLogEvent.InviteCreate]: 'invite_create', [AuditLogEvent.InviteDelete]: 'invite_delete', [AuditLogEvent.RoleDelete]: 'role_delete',
  [AuditLogEvent.RoleCreate]: 'role_create', [AuditLogEvent.RoleUpdate]: 'role_update',
  [AuditLogEvent.MemberBanAdd]: 'member_ban', [AuditLogEvent.MemberKick]: 'member_kick',
  [AuditLogEvent.MemberRoleUpdate]: 'member_role_update', [AuditLogEvent.GuildUpdate]: 'guild_update',
  [AuditLogEvent.WebhookCreate]: 'webhook_create', [AuditLogEvent.BotAdd]: 'bot_add',
};
function isTrusted(guild, executorId, cfg) {
  if (!executorId) return true;
  if (executorId === guild.client.user.id || executorId === guild.ownerId) return true;
  if ((cfg.allowlist || []).includes(executorId) || (cfg.trusted_users || []).includes(executorId)) return true;
  const member = guild.members.cache.get(executorId);
  return Boolean(member && member.roles.cache.some(role => (cfg.trusted_roles || []).includes(role.id)));
}
async function postSecurityLog(guild, title, description, color = 0xef4444, fields = []) {
  const cfg = getGuildSecurity(guild.id);
  const channelId = cfg.security_log_channel || getGuildConfig(guild.id).channels?.modlog || null;
  let channel = channelId ? guild.channels.cache.get(channelId) : null;
  if (!channel && channelId) channel = await guild.channels.fetch(channelId).catch(() => null);
  if (channel?.isTextBased()) await channel.send({ embeds: [new EmbedBuilder().setColor(color).setTitle(title).setDescription(description).addFields(fields).setTimestamp()], allowedMentions: { parse: [] } }).catch(() => {});
}
async function applyLockdown(guild, reason = 'Manual security lockdown', automatic = false) {
  const cfg = getGuildSecurity(guild.id);
  if (!guild.members.me?.permissions.has(PermissionFlagsBits.ManageChannels)) return { applied: false, reason: 'missing_permissions', count: 0, failed: 0 };
  if (cfg.lockdown_state?.active) return { applied: false, reason: 'already_active' };
  const snapshot = { active: true, createdAt: Date.now(), reason, automatic, expiresAt: automatic ? Date.now() + 10 * 60 * 1000 : null, channels: [] };
  const channels = await guild.channels.fetch().catch(() => guild.channels.cache);
  let locked = 0, failed = 0;
  for (const channel of channels.values()) {
    if (!channel?.permissionOverwrites || channel.isThread?.() || !(channel.isTextBased?.() || channel.isVoiceBased?.())) continue;
    const everyone = channel.permissionOverwrites.cache.get(guild.roles.everyone.id);
    const saved = { id: channel.id, hadOverwrite: Boolean(everyone), allow: everyone?.allow.bitfield.toString() || '0', deny: everyone?.deny.bitfield.toString() || '0' };
    try { await channel.permissionOverwrites.edit(guild.roles.everyone.id, { SendMessages: false, AddReactions: false, SendMessagesInThreads: false, CreatePublicThreads: false, CreatePrivateThreads: false, Connect: false, Speak: false }, { reason }); snapshot.channels.push(saved); locked++; } catch { failed++; }
  }
  if (locked === 0 && failed > 0) return { applied: false, reason: 'all_failed', count: 0, failed };
  upsertGuildSecurity(guild.id, { lockdown_state: snapshot });
  addLockdownRecord(guild.id, guild.client.user.id, 'auto_lockdown', snapshot.channels.map(c => c.id), snapshot);
  return { applied: true, count: locked, failed };
}
async function restoreLockdown(guild, actorId = guild.client.user.id) {
  const cfg = getGuildSecurity(guild.id); const snapshot = cfg.lockdown_state;
  if (!snapshot?.active || !Array.isArray(snapshot.channels)) return { restored: 0, failed: 0, reason: 'not_active' };
  let restored = 0, failed = 0;
  for (const saved of snapshot.channels) {
    const channel = guild.channels.cache.get(saved.id) || await guild.channels.fetch(saved.id).catch(() => null);
    if (!channel?.permissionOverwrites) continue;
    try {
      if (Array.isArray(saved.overwrites)) {
        const overwrites = saved.overwrites.map(o => ({ id: o.id, type: o.type, allow: BigInt(o.allow), deny: BigInt(o.deny) }));
        await channel.permissionOverwrites.set(overwrites, 'Nexus legacy security lockdown restored');
      } else if (!saved.hadOverwrite) await channel.permissionOverwrites.delete(guild.roles.everyone.id, 'Nexus security lockdown restored');
      else await channel.permissionOverwrites.edit(guild.roles.everyone.id, { allow: BigInt(saved.allow), deny: BigInt(saved.deny) }, { reason: 'Nexus security lockdown restored' });
      restored++;
    } catch { failed++; }
  }
  if (failed === 0) upsertGuildSecurity(guild.id, { lockdown_state: { active: false, restoredAt: Date.now(), channels: [] } });
  addLockdownRecord(guild.id, actorId, 'unlockdown', snapshot.channels.map(c => c.id), { restored, failed });
  return { restored, failed };
}
function recordEvent(guildId, executorId, type, now = Date.now()) {
  const key = `${guildId}:${executorId || 'unknown'}:${type}`;
  const list = (windows.get(key) || []).filter(at => now - at <= 60_000); list.push(now); windows.set(key, list); return list.length;
}
async function quarantineMember(guild, userId, reason = 'Nexus security quarantine') {
  const cfg = getGuildSecurity(guild.id); const roleId = cfg.thresholds?.quarantine_role_id;
  if (!roleId) return { applied: false, reason: 'quarantine_role_not_configured' };
  const member = await guild.members.fetch(userId).catch(() => null);
  const role = guild.roles.cache.get(roleId) || await guild.roles.fetch(roleId).catch(() => null);
  const bot = guild.members.me;
  if (!member || !role || !bot?.permissions.has(PermissionFlagsBits.ManageRoles) || !member.manageable || role.position >= bot.roles.highest.position) return { applied: false, reason: 'missing_member_or_permissions' };
  const dangerous = [PermissionFlagsBits.Administrator, PermissionFlagsBits.ManageGuild, PermissionFlagsBits.ManageRoles, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.BanMembers, PermissionFlagsBits.KickMembers, PermissionFlagsBits.ManageWebhooks, PermissionFlagsBits.ManageMessages, PermissionFlagsBits.ModerateMembers, PermissionFlagsBits.ManageEvents, PermissionFlagsBits.ManageThreads, PermissionFlagsBits.ManageNicknames];
  if (dangerous.some(permission => role.permissions.has(permission))) return { applied: false, reason: 'quarantine_role_has_dangerous_permissions' };
  const removable = member.roles.cache.filter(item => item.id !== guild.id && item.id !== role.id && item.position < bot.roles.highest.position).map(item => item.id);
  const saved = { roles: removable, quarantinedAt: Date.now(), reason };
  try {
    if (removable.length) await member.roles.remove(removable, reason);
    if (!member.roles.cache.has(role.id)) await member.roles.add(role, reason);
  } catch (error) {
    if (removable.length) await member.roles.add(removable, 'Nexus quarantine rollback after role assignment failure').catch(() => {});
    return { applied: false, reason: `discord_rejected_change: ${error.message}` };
  }
  const thresholds = { ...cfg.thresholds, quarantined_members: { ...(cfg.thresholds?.quarantined_members || {}), [userId]: saved } };
  upsertGuildSecurity(guild.id, { thresholds });
  return { applied: true, removedRoles: removable.length, quarantineRoleId: role.id };
}
async function releaseQuarantinedMember(guild, userId) {
  const cfg = getGuildSecurity(guild.id); const records = { ...(cfg.thresholds?.quarantined_members || {}) }; const saved = records[userId];
  if (!saved) return { restored: false, reason: 'no_quarantine_record' };
  const member = await guild.members.fetch(userId).catch(() => null); const roleId = cfg.thresholds?.quarantine_role_id;
  if (!member) return { restored: false, reason: 'member_not_found' };
  const bot = guild.members.me; if (!bot?.permissions.has(PermissionFlagsBits.ManageRoles) || !member.manageable) return { restored: false, reason: 'missing_permissions' };
  try { if (roleId && member.roles.cache.has(roleId)) await member.roles.remove(roleId, 'Nexus security quarantine released'); } catch (error) { return { restored: false, reason: `remove_quarantine_role_failed: ${error.message}` }; }
  const restorable = (saved.roles || []).filter(id => { const role = guild.roles.cache.get(id); return role && role.id !== guild.id && role.position < bot.roles.highest.position; });
  try { if (restorable.length) await member.roles.add(restorable, 'Nexus security quarantine released'); }
  catch (error) { return { restored: false, reason: `restore_failed: ${error.message}` }; }
  delete records[userId]; upsertGuildSecurity(guild.id, { thresholds: { ...cfg.thresholds, quarantined_members: records } });
  return { restored: true, roles: restorable.length };
}

async function applyMemberAction(member, action, reason) {
  if (!member || member.id === member.guild.ownerId || action === 'log') return 'logged';
  if (action === 'timeout' && member.moderatable) { await member.timeout(10 * 60 * 1000, reason); return 'timed out for 10 minutes'; }
  if (action === 'kick' && member.kickable) { await member.kick(reason); return 'kicked'; }
  if (action === 'ban' && member.bannable) { await member.ban({ reason, deleteMessageSeconds: 0 }); return 'banned'; }
  return 'action unavailable (check bot permissions and role hierarchy)';
}
async function applyJoinGate(member, cfg) {
  if (Number(cfg.thresholds?.join_gate_enabled) !== 1 || isTrusted(member.guild, member.id, cfg)) return;
  const ageDays = (Date.now() - Number(member.user.createdTimestamp || Date.now())) / 86400000;
  const minAge = Math.max(0, Number(cfg.thresholds?.min_account_age_days) || 0);
  let action = null, reason = '';
  if (minAge > 0 && ageDays < minAge) { action = cfg.thresholds?.new_account_action || 'log'; reason = `Account age ${ageDays.toFixed(1)} days is below the configured ${minAge}-day minimum`; }
  else if (!member.user.avatar && ['log', 'timeout', 'kick', 'ban'].includes(cfg.thresholds?.no_avatar_action)) { action = cfg.thresholds.no_avatar_action; reason = 'Member joined without a custom avatar'; }
  if (!action) return;
  const result = await applyMemberAction(member, action, `Nexus join gate: ${reason}`);
  addIncident({ guild_id: member.guild.id, type: 'join_gate', summary: `${member.user.tag} matched a join-gate filter: ${reason}`, details: { userId: member.id, accountAgeDays: Number(ageDays.toFixed(2)), action, result }, executor_id: null, target_id: member.id, severity: action === 'log' ? 'medium' : 'high' });
  await postSecurityLog(member.guild, '🧱 Join-gate filter triggered', `${member.user.tag} (${member.id}) matched a join filter.`, action === 'log' ? 0xf59e0b : 0xef4444, [
    { name: 'Reason', value: reason.slice(0, 1024), inline: false }, { name: 'Configured action', value: action, inline: true }, { name: 'Result', value: result, inline: true },
  ]);
}

function hasDangerousPermissionEscalation(entry) {
  if (entry.action !== AuditLogEvent.RoleUpdate) return false;
  const change = (entry.changes || []).find(item => item.key === 'permissions' && item.new !== undefined && item.new !== null);
  if (!change) return false;
  try {
    const permissions = BigInt(change.new);
    const previous = change.old == null ? 0n : BigInt(change.old);
    const dangerous = PermissionFlagsBits.Administrator | PermissionFlagsBits.ManageGuild | PermissionFlagsBits.ManageRoles | PermissionFlagsBits.ManageChannels | PermissionFlagsBits.BanMembers | PermissionFlagsBits.KickMembers | PermissionFlagsBits.ManageWebhooks | PermissionFlagsBits.ManageMessages;
    return ((permissions & ~previous) & BigInt(dangerous)) !== 0n;
  } catch { return false; }
}

async function handleAuditLogEntry(entry, guild) {
  const cfg = getGuildSecurity(guild.id);
  if (Number(cfg.enabled) !== 1) return;
  const type = EVENT_NAMES[entry.action]; if (!type) return;
  if (entry.executorId && entry.executorId !== guild.ownerId && entry.executorId !== guild.client.user.id && !guild.members.cache.has(entry.executorId)) await guild.members.fetch(entry.executorId).catch(() => null);
  if (isTrusted(guild, entry.executorId, cfg)) return;
  if (hasDangerousPermissionEscalation(entry)) {
    const details = { action: entry.action, executorId: entry.executorId, targetId: entry.targetId, changes: entry.changes || [], immediate: true };
    addIncident({ guild_id: guild.id, type: 'dangerous_role_permission', summary: 'An untrusted executor added dangerous permissions to a role', details, executor_id: entry.executorId, target_id: entry.targetId, severity: 'critical' });
    await postSecurityLog(guild, '🚨 Dangerous role permission change', 'An untrusted executor added dangerous permissions to a role. Review the audit log immediately.', 0x991b1b, [{ name: 'Executor', value: entry.executorId ? `<@${entry.executorId}> (${entry.executorId})` : 'Unknown', inline: true }, { name: 'Role', value: entry.targetId || 'Unknown', inline: true }, { name: 'Response', value: cfg.response_mode || 'alert', inline: true }]);
    if (cfg.response_mode === 'contain') {
      await applyLockdown(guild, 'Nexus containment: dangerous role permission escalation', true);
      if (entry.executorId) await quarantineMember(guild, entry.executorId, 'Nexus containment after dangerous role permission escalation').catch(() => null);
      const executor = entry.executorId ? await guild.members.fetch(entry.executorId).catch(() => null) : null;
      if (executor?.moderatable && executor.id !== guild.ownerId) await executor.timeout(60 * 60 * 1000, 'Nexus containment after dangerous role permission escalation').catch(() => {});
    }
    return;
  }
  const count = recordEvent(guild.id, entry.executorId, type);
  if (type === 'bot_add' && Number(cfg.thresholds?.join_gate_enabled) === 1) {
    const botAction = ['log', 'kick', 'ban'].includes(cfg.thresholds?.bot_add_action) ? cfg.thresholds.bot_add_action : 'log';
    const target = entry.targetId ? await guild.members.fetch(entry.targetId).catch(() => null) : null;
    if (botAction !== 'log' && target?.user?.bot) {
      const result = await applyMemberAction(target, botAction, `Nexus security: unauthorized bot addition by ${entry.executorId || 'unknown executor'}`);
      addIncident({ guild_id: guild.id, type: 'unauthorized_bot_add', summary: `Unauthorized bot addition detected; configured action: ${botAction}`, details: { executorId: entry.executorId, targetId: entry.targetId, result }, executor_id: entry.executorId, target_id: entry.targetId, severity: 'high' });
      await postSecurityLog(guild, '🤖 Unauthorized bot addition', `Nexus detected a bot added by an untrusted executor.`, 0xef4444, [{ name: 'Executor', value: entry.executorId ? `<@${entry.executorId}>` : 'Unknown', inline: true }, { name: 'Bot', value: target ? `${target.user.tag} (${target.id})` : String(entry.targetId || 'Unknown'), inline: true }, { name: 'Action', value: result, inline: true }]);
    }
  }
  const threshold = Number(cfg.thresholds?.[type] ?? DEFAULT_THRESHOLDS[type] ?? 3);
  if (count !== threshold) return;
  const details = { action: entry.action, count, threshold, reason: entry.reason || null, executorId: entry.executorId, targetId: entry.targetId };
  addIncident({ guild_id: guild.id, type, summary: `Security threshold triggered: ${type} (${count}/${threshold} per minute)`, details, executor_id: entry.executorId, target_id: entry.targetId, severity: 'high' });
  await postSecurityLog(guild, '🚨 Anti-nuke alert', `Suspicious activity reached the configured threshold.`, 0xef4444, [
    { name: 'Event', value: type, inline: true }, { name: 'Count / threshold', value: `${count} / ${threshold}`, inline: true },
    { name: 'Executor', value: entry.executorId ? `<@${entry.executorId}> (${entry.executorId})` : 'Unknown', inline: false },
    { name: 'Target', value: entry.targetId || 'Unknown', inline: true }, { name: 'Response', value: cfg.response_mode || 'alert', inline: true },
  ]);
  if (cfg.response_mode === 'contain') {
    const result = await applyLockdown(guild, `Nexus anti-nuke containment: ${type}`, true);
    if (entry.executorId) await quarantineMember(guild, entry.executorId, `Nexus anti-nuke containment after ${type}`).catch(() => null);
    const member = entry.executorId ? await guild.members.fetch(entry.executorId).catch(() => null) : null;
    if (member?.moderatable && member.id !== guild.ownerId) await member.timeout(60 * 60 * 1000, `Nexus anti-nuke containment after ${type}`).catch(() => {});
    await postSecurityLog(guild, '🔒 Containment activated', `Lockdown ${result.applied ? 'applied' : 'not applied'} (${result.count || 0} channels).`, 0xf59e0b);
  }
}
async function handleMemberJoin(member) {
  const cfg = getGuildSecurity(member.guild.id);
  if (Number(cfg.enabled) !== 1) return;
  await applyJoinGate(member, cfg).catch(error => console.error(`[security:join-gate] ${error.message}`));
  const now = Date.now(); const windowMs = Math.max(5, Number(cfg.thresholds?.join_window_seconds ?? DEFAULT_THRESHOLDS.join_window_seconds)) * 1000;
  const list = (joinWindows.get(member.guild.id) || []).filter(item => now - item.at <= windowMs); list.push({ at: now, userId: member.id }); joinWindows.set(member.guild.id, list);
  const threshold = Math.max(3, Number(cfg.thresholds?.join_count ?? DEFAULT_THRESHOLDS.join_count));
  if (list.length < threshold) return;
  // Fire once per active burst; the next burst can trigger after the window expires.
  if (list.some(item => item.triggered)) return;
  list.forEach(item => { item.triggered = true; }); joinWindows.set(member.guild.id, list);
  addIncident({ guild_id: member.guild.id, type: 'join_raid', summary: `Join burst detected (${list.length} members in ${Math.round(windowMs / 1000)} seconds)`, details: { count: list.length, windowMs }, severity: 'high' });
  await postSecurityLog(member.guild, '🚨 Possible join raid detected', `${list.length} members joined within ${Math.round(windowMs / 1000)} seconds.`, 0xef4444, [{ name: 'Action', value: cfg.response_mode === 'contain' ? 'Automatic lockdown configured' : 'Alert only' }]);
  if (cfg.response_mode === 'contain') await applyLockdown(member.guild, 'Nexus anti-raid join burst detected', true);
}
async function handleMessageRaid(message) {
  if (!message.guild) return false;
  const cfg = getGuildSecurity(message.guild.id);
  if (Number(cfg.enabled) !== 1 || isTrusted(message.guild, message.author.id, cfg)) return false;
  const now = Date.now();
  const mentions = Number(message.mentions?.users?.size || 0) + Number(message.mentions?.roles?.size || 0) + (message.mentions?.everyone ? 5 : 0);
  if (mentions > 0) {
    const windowMs = Math.max(5, Number(cfg.thresholds?.mention_window_seconds ?? DEFAULT_THRESHOLDS.mention_window_seconds)) * 1000;
    const list = (mentionWindows.get(message.guild.id) || []).filter(item => now - item.at <= windowMs);
    list.push({ at: now, count: mentions, userId: message.author.id }); mentionWindows.set(message.guild.id, list);
    const total = list.reduce((sum, item) => sum + item.count, 0);
    const threshold = Math.max(5, Number(cfg.thresholds?.mention_count ?? DEFAULT_THRESHOLDS.mention_count));
    if (total >= threshold && !list.some(item => item.triggered)) {
      list.forEach(item => { item.triggered = true; }); mentionWindows.set(message.guild.id, list);
      addIncident({ guild_id: message.guild.id, type: 'mention_raid', summary: `Mention raid threshold triggered (${total} mentions in ${Math.round(windowMs / 1000)} seconds)`, details: { total, threshold, windowMs, recentSenders: [...new Set(list.map(item => item.userId))] }, severity: 'high' });
      await postSecurityLog(message.guild, '🚨 Possible mention raid detected', `${total} user/role/everyone mentions were detected in ${Math.round(windowMs / 1000)} seconds.`, 0xef4444, [{ name: 'Distinct senders', value: String(new Set(list.map(item => item.userId)).size), inline: true }, { name: 'Response', value: cfg.response_mode || 'alert', inline: true }]);
      if (cfg.response_mode === 'contain') await applyLockdown(message.guild, 'Nexus anti-raid mention burst detected', true);
    }
  }

  // Message spam and duplicate detection are handled by the unified heat-based AutoMod
  // pipeline in utils/automod.js. Keeping one detector avoids double punishments.
  return false;
}

async function restoreExpiredLockdowns(client, now = Date.now()) {
  for (const guild of client.guilds.cache.values()) {
    const cfg = getGuildSecurity(guild.id); const state = cfg.lockdown_state;
    if (state?.active && state.automatic && Number(state.expiresAt) > 0 && now >= Number(state.expiresAt)) {
      const result = await restoreLockdown(guild, client.user.id).catch(() => null);
      if (result && result.failed === 0) await postSecurityLog(guild, '🔓 Automatic lockdown expired', `Restored ${result.restored} channel(s).`, 0x22c55e);
    }
  }
}
function getProtectionDefaults() { return { enabled: 0, response_mode: 'alert', thresholds: { ...DEFAULT_THRESHOLDS } }; }
module.exports = { DEFAULT_THRESHOLDS, EVENT_NAMES, getProtectionDefaults, handleAuditLogEntry, handleMemberJoin, handleMessageRaid, applyLockdown, restoreLockdown, restoreExpiredLockdowns, postSecurityLog, getIncidents, applyJoinGate, quarantineMember, releaseQuarantinedMember };
