const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder().setName('purge').setDescription('Remove all messages or delete a specific amount from this channel.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addStringOption(option => option.setName('amount').setDescription('Use a number like 50, or type all to remove everything').setRequired(true)),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: 'Use this command inside a server.', flags: 64 });
    await interaction.deferReply({ flags: 64 });
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageMessages)) return interaction.editReply({ content: 'Meow Ghop Ghop Ghop 🐱' });

    const channel = interaction.channel;
    if (!channel?.bulkDelete || !channel?.messages?.fetch) {
      return interaction.editReply({ content: 'This channel does not support bulk deletion.' });
    }

    const rawAmount = interaction.options.getString('amount', true).trim().toLowerCase();
    const deleteAll = rawAmount === 'all';
    const targetCount = deleteAll ? Number.MAX_SAFE_INTEGER : Number(rawAmount);

    if (!deleteAll && (!Number.isInteger(targetCount) || targetCount < 1)) {
      return interaction.editReply({ content: 'Use a positive number like `50` or type `all`.' });
    }

    let totalDeleted = 0;
    let remainingToDelete = deleteAll ? Number.MAX_SAFE_INTEGER : targetCount;

    while (remainingToDelete > 0) {
      const limit = Math.min(100, remainingToDelete);
      const messages = await channel.messages.fetch({ limit: deleteAll ? 100 : limit });
      if (messages.size === 0) break;

      const batch = [...messages.values()];
      const deleteBatch = deleteAll ? batch : batch.slice(0, Math.min(batch.length, remainingToDelete));
      const deleted = await channel.bulkDelete(deleteBatch, true);
      totalDeleted += deleted.size;
      remainingToDelete = deleteAll ? Number.MAX_SAFE_INTEGER : Math.max(0, targetCount - totalDeleted);

      if (deleteAll && deleted.size === 0) break;
      if (deleteAll && batch.length < 100) break;
      if (!deleteAll && remainingToDelete === 0) break;
      if (!deleteAll && deleted.size < deleteBatch.length) break;
    }

    await interaction.editReply({
      content: deleteAll
        ? `Deleted ${totalDeleted} message(s) from this channel.`
        : `Deleted ${totalDeleted} message(s). Messages older than 14 days cannot be bulk-deleted by Discord.`
    });
  }
};
