const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getWarnings } = require('../utils/warnings');

module.exports = {
  data: new SlashCommandBuilder().setName('warnings').setDescription('View recorded warnings for a member.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('Member whose warnings to view').setRequired(true)),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: 'Use this command inside a server.', flags: 64 });
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ModerateMembers)) return interaction.reply({ content: 'Meow Ghop Ghop Ghop 🐱', flags: 64 });
    const user = interaction.options.getUser('user', true);
    const warnings = getWarnings(interaction.guildId, user.id);
    if (!warnings.length) return interaction.reply({ content: `**${user.tag}** has no recorded warnings.`, flags: 64 });
    const lines = warnings.slice(-10).map((w, i) => {
      const time = w.createdAt || w.at;
      const timeStr = time ? ` • <t:${Math.floor(new Date(time).getTime() / 1000)}:R>` : '';
      return `**${Math.max(1, warnings.length - Math.min(10, warnings.length) + i + 1)}.** ${w.reason} — <@${w.moderatorId}>${timeStr}`;
    });
    await interaction.reply({ content: `Warnings for **${user.tag}** (${warnings.length} total):\n${lines.join('\n')}`.slice(0, 1900), flags: 64 });
  }
};
