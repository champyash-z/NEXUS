const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder().setName('kick').setDescription('Kick a member from this server.')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption(o => o.setName('user').setDescription('Member to kick').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the kick').setMaxLength(500).setRequired(false)),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: 'Use this command inside a server.', flags: 64 });
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.KickMembers)) return interaction.reply({ content: 'Meow Ghop Ghop Ghop 🐱', flags: 64 });
    const user = interaction.options.getUser('user', true);
    const reason = interaction.options.getString('reason') || `Kicked by ${interaction.user.tag}`;
    if (user.id === interaction.user.id) return interaction.reply({ content: 'You cannot kick yourself.', flags: 64 });
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) return interaction.reply({ content: 'That user is not a member of this server.', flags: 64 });
    if (!member.kickable) return interaction.reply({ content: 'I cannot kick that member. Check my role position and permissions.', flags: 64 });
    await member.kick(reason);
    await interaction.reply({ content: `Kicked **${user.tag}**. Reason: ${reason}`, flags: 64 });
  }
};
