const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder().setName('timeout').setDescription('Timeout a member for a number of minutes.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('Member to timeout').setRequired(true))
    .addIntegerOption(o => o.setName('duration_minutes').setDescription('Duration in minutes (1–40320)').setMinValue(1).setMaxValue(40320).setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for timeout').setMaxLength(500).setRequired(false)),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: 'Use this command inside a server.', flags: 64 });
    await interaction.deferReply({ flags: 64 });
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ModerateMembers)) return interaction.editReply({ content: 'Meow Ghop Ghop Ghop 🐱' });
    const user = interaction.options.getUser('user', true);
    if (user.id === interaction.user.id) return interaction.editReply({ content: 'You cannot timeout yourself.' });
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) return interaction.editReply({ content: 'That user is not a member of this server.' });
    if (!member.moderatable) return interaction.editReply({ content: 'I cannot timeout that member. Check role hierarchy and permissions.' });
    const minutes = interaction.options.getInteger('duration_minutes', true);
    const reason = interaction.options.getString('reason') || `Timed out by ${interaction.user.tag}`;
    await member.timeout(minutes * 60_000, reason);
    await interaction.editReply({ content: `Timed out **${user.tag}** for ${minutes} minute(s). Reason: ${reason}` });
  }
};
