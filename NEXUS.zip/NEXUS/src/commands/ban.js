const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder().setName('ban').setDescription('Ban a user from this server.')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(o => o.setName('user').setDescription('User to ban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the ban').setMaxLength(500).setRequired(false))
    .addIntegerOption(o => o.setName('delete_days').setDescription('Delete up to 7 days of messages (default 0)').setMinValue(0).setMaxValue(7).setRequired(false)),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: 'Use this command inside a server.', flags: 64 });
    await interaction.deferReply({ flags: 64 });
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.BanMembers)) return interaction.editReply({ content: 'Meow Ghop Ghop Ghop 🐱' });
    const user = interaction.options.getUser('user', true);
    if (user.id === interaction.user.id) return interaction.editReply({ content: 'You cannot ban yourself.' });
    const reason = interaction.options.getString('reason') || `Banned by ${interaction.user.tag}`;
    const deleteMessageSeconds = (interaction.options.getInteger('delete_days') || 0) * 86400;
    await interaction.guild.members.ban(user.id, { reason, deleteMessageSeconds });
    await interaction.editReply({ content: `Banned **${user.tag}**. Reason: ${reason}` });
  }
};
