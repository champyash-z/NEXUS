const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, updateSetupState, resetGuildSetup, setGuildConfig } = require('../utils/config');

const MODULES = [
  { key: 'moderation', label: 'Moderation', description: 'Kick, ban, timeout, and warning workflows.' },
  { key: 'automod', label: 'AutoMod', description: 'Spam, invite, and link filtering.' },
  { key: 'security', label: 'Anti-raid & anti-nuke', description: 'Detect join bursts and suspicious destructive audit-log activity.' },
  { key: 'smartWelcome', label: 'Smart welcome & verification', description: 'Welcome templates, auto-role, and button-based verification.' },
  { key: 'departure', label: 'Departure messages', description: 'Goodbye messages for leaving members.' },
  { key: 'autoroles', label: 'Auto-roles', description: 'Assign roles automatically on join.' },
  { key: 'reactionRoles', label: 'Reaction roles', description: 'Interactive role selection menus.' },
  { key: 'tickets', label: 'Tickets', description: 'Staff support ticket system.' },
  { key: 'suggestions', label: 'Suggestions', description: 'Member suggestion submission and voting.' },
  { key: 'levelingPlus', label: 'XP, levels & leaderboard', description: 'Cooldown-protected XP, role rewards, ranks, and paginated leaderboards.' },
  { key: 'polls', label: 'Polls', description: 'Create quick polls and feedback questions.' },
  { key: 'giveaways', label: 'Giveaways', description: 'Timed giveaway draws and announcements.' },
  { key: 'starboard', label: 'Starboard', description: 'Highlight popular messages.' },
  { key: 'reminders', label: 'Reminders', description: 'Scheduled reminders and automation.' },
  { key: 'logging', label: 'Logging', description: 'Audit channel activity and moderation events.' },
  { key: 'customCommands', label: 'Custom commands', description: 'Autoresponders and custom triggers.' },
  { key: 'socialNotifications', label: 'Social notifications', description: 'Twitch, YouTube, and social alerts.' },
];

const PRESETS = {
  gaming: {
    label: 'Gaming community',
    modules: ['moderation', 'automod', 'smartWelcome', 'tickets', 'levelingPlus', 'logging', 'polls'],
  },
  creator: {
    label: 'Creator or streamer community',
    modules: ['moderation', 'automod', 'smartWelcome', 'reactionRoles', 'tickets', 'levelingPlus', 'polls', 'starboard', 'socialNotifications'],
  },
  general: {
    label: 'General community',
    modules: ['moderation', 'automod', 'smartWelcome', 'suggestions', 'levelingPlus', 'polls', 'reminders', 'logging'],
  },
  support: {
    label: 'Support server',
    modules: ['moderation', 'smartWelcome', 'tickets', 'suggestions', 'logging', 'reminders'],
  },
  private: {
    label: 'Private server',
    modules: ['moderation', 'automod', 'smartWelcome', 'tickets', 'logging'],
  },
  custom: {
    label: 'Custom configuration',
    modules: ['moderation', 'automod', 'smartWelcome', 'tickets', 'suggestions', 'levelingPlus', 'logging'],
  },
};

function getAuthorized(interaction) {
  const isOwner = interaction.guild.ownerId === interaction.user.id;
  const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);
  const isManager = interaction.member.permissions.has(PermissionFlagsBits.ManageGuild);
  return isOwner || isAdmin || isManager;
}

function buildSetupEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle(title)
    .setDescription(description)
    .setFooter({ text: 'Nexus Setup Wizard' });
}

function buildPresetButtons() {
  const rows = [];
  const presetEntries = Object.entries(PRESETS);
  for (let i = 0; i < presetEntries.length; i += 3) {
    const row = new ActionRowBuilder();
    for (const [key, preset] of presetEntries.slice(i, i + 3)) {
      row.addComponents(
        new ButtonBuilder()
          .setCustomId(`setup_preset_${key}`)
          .setLabel(preset.label)
          .setStyle(ButtonStyle.Primary)
      );
    }
    rows.push(row);
  }
  return rows;
}

function getSelectedModules(guildId) {
  const config = getGuildConfig(guildId);
  const onboarding = config.onboarding || {};
  if (Array.isArray(onboarding.moduleList) && onboarding.moduleList.length > 0) {
    return [...new Set(onboarding.moduleList)];
  }
  if (onboarding.preset && PRESETS[onboarding.preset]) {
    return [...PRESETS[onboarding.preset].modules];
  }
  return [...PRESETS.custom.modules];
}

function buildModuleButtons(guildId) {
  const config = getGuildConfig(guildId);
  const selectedSet = new Set(getSelectedModules(guildId));
  const pageSize = 8; // Four component rows plus one navigation row stays within Discord's 5-row limit.
  const pageCount = Math.max(1, Math.ceil(MODULES.length / pageSize));
  const page = Math.max(0, Math.min(pageCount - 1, Number(config.onboarding?.modulePage || 0)));
  const pageModules = MODULES.slice(page * pageSize, (page + 1) * pageSize);
  const rows = [];

  for (let i = 0; i < pageModules.length; i += 2) {
    const row = new ActionRowBuilder();
    for (const mod of pageModules.slice(i, i + 2)) {
      const isSelected = selectedSet.has(mod.key);
      row.addComponents(
        new ButtonBuilder()
          .setCustomId(`setup_toggle_${mod.key}`)
          .setLabel(`${isSelected ? '✓' : '○'} ${mod.label}`.slice(0, 80))
          .setStyle(isSelected ? ButtonStyle.Success : ButtonStyle.Secondary)
      );
    }
    rows.push(row);
  }

  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('setup_back').setLabel('Back').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('setup_modpage_prev').setLabel('Previous').setStyle(ButtonStyle.Secondary).setDisabled(page === 0),
    new ButtonBuilder().setCustomId('setup_modpage_next').setLabel('Next').setStyle(ButtonStyle.Secondary).setDisabled(page >= pageCount - 1),
    new ButtonBuilder().setCustomId('setup_apply').setLabel('Apply Setup').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('setup_cancel').setLabel('Cancel').setStyle(ButtonStyle.Danger),
  ));

  return rows;
}

function buildSetupWizard(guildId) {
  const config = getGuildConfig(guildId);
  const onboarding = config.onboarding || {};
  const step = Number(onboarding.step || 0);
  const selected = getSelectedModules(guildId);

  if (step === 1) {
    const embed = buildSetupEmbed(
      'Choose Your Modules',
      'Select the features you want enabled for this server. Toggle options on or off, then apply the configuration.'
    ).addFields(
      { name: 'Preset', value: `**${onboarding.preset || 'custom'}**`, inline: true },
      { name: 'Selected', value: `${selected.length} modules enabled`, inline: true },
      { name: 'Page', value: `${Math.min(Math.floor(Number(onboarding.modulePage || 0)), Math.ceil(MODULES.length / 8) - 1) + 1}/${Math.ceil(MODULES.length / 8)}`, inline: true },
      { name: 'Tip', value: 'Use Previous / Next to browse every module, then apply your choices.', inline: false }
    );

    return {
      embed,
      components: buildModuleButtons(guildId),
    };
  }

  const embed = buildSetupEmbed(
    'Nexus Setup Wizard',
    'Welcome to the Nexus onboarding flow. Choose a preset for your server, then customize the modules you want to turn on.'
  ).addFields(
    { name: 'Progress', value: 'Step 1/2 • Preset selection', inline: false },
    { name: 'Selected preset', value: `**${onboarding.preset || 'custom'}**`, inline: true },
    { name: 'Current modules', value: selected.length ? selected.join(', ') : 'None selected', inline: false }
  );

  const buttons = buildPresetButtons();
  buttons.push(
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('setup_cancel').setLabel('Cancel').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId('setup_next').setLabel('Next').setStyle(ButtonStyle.Primary),
    )
  );
  return { embed, components: buttons };
}

function applySetupSelection(guildId) {
  const config = getGuildConfig(guildId);
  const onboarding = config.onboarding || {};
  const selected = getSelectedModules(guildId);
  const moduleMap = {};
  for (const module of MODULES) {
    moduleMap[module.key] = selected.includes(module.key);
  }

  setGuildConfig(guildId, {
    modules: {
      ...config.modules,
      ...moduleMap,
    },
    onboarding: {
      ...onboarding,
      active: false,
      completed: true,
      step: 2,
    },
  });

  return getGuildConfig(guildId);
}

async function startSetup(interaction) {
  const config = getGuildConfig(interaction.guildId);
  updateSetupState(interaction.guildId, {
    active: true,
    step: 0,
    preset: 'custom',
    startedBy: interaction.user.id,
    completed: false,
    moduleList: config.modules ? Object.entries(config.modules).filter(([, enabled]) => enabled).map(([key]) => key) : [...PRESETS.custom.modules],
  });

  const wizard = buildSetupWizard(interaction.guildId);
  await interaction.reply({ embeds: [wizard.embed], components: wizard.components, flags: 64 });
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Run the Nexus onboarding wizard for this server.')
    .addSubcommand(sub => sub.setName('start').setDescription('Start the onboarding wizard'))
    .addSubcommand(sub => sub.setName('status').setDescription('Check the current setup status'))
    .addSubcommand(sub => sub.setName('reset').setDescription('Reset setup progress for this server')),

  async execute(interaction) {
    if (!interaction.inGuild()) {
      return interaction.reply({ content: 'This command can only be used in a server.', flags: 64 });
    }

    if (!getAuthorized(interaction)) {
      return interaction.reply({ content: 'Meow Ghop Ghop Ghop 🐱', flags: 64 });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'status') {
      const config = getGuildConfig(interaction.guildId);
      const status = config.onboarding?.active ? 'In progress' : 'Not started';
      const embed = buildSetupEmbed('Setup Status', `Current status: **${status}**\nPreset: **${config.onboarding?.preset || 'custom'}**\nStep: **${config.onboarding?.step || 0}**`);
      return interaction.reply({ embeds: [embed], flags: 64 });
    }

    if (sub === 'reset') {
      const confirm = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('setup_reset_confirm').setLabel('Reset Setup').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('setup_reset_cancel').setLabel('Keep Current Setup').setStyle(ButtonStyle.Secondary),
      );
      return interaction.reply({ content: 'This will not delete any existing server data, but it will clear Nexus setup progress. Continue?', components: [confirm], flags: 64 });
    }

    return startSetup(interaction);
  },

  getAuthorized,
  MODULES,
  PRESETS,
  buildSetupEmbed,
  buildSetupWizard,
  applySetupSelection,
};
