const native = require('../polls/native');
module.exports = { data: native.createCommand(), execute: native.execute };
