const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('node:fs');
const path = require('node:path');
const { getGuildConfig } = require('../utils/config');

const dataDir = path.join(__dirname, '..', '..', 'data');
const suggestionsPath = path.join(dataDir, 'suggestions.json');

function ensureSuggestions() {
  fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(suggestionsPath)) fs.writeFileSync(suggestionsPath, '{}', 'utf8');
}

function readSuggestions() {
  ensureSuggestions();
  try {
    return JSON.parse(fs.readFileSync(suggestionsPath, 'utf8'));
  } catch {
    return {};
  }
}

function writeSuggestions(data) {
  ensureSuggestions();
  fs.writeFileSync(suggestionsPath, JSON.stringify(data, null, 2), 'utf8');
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('suggest')
    .setDescription('Submit or review server suggestions.')
    .addSubcommand(sub => sub.setName('submit').setDescription('Submit a suggestion').addStringOption(opt => opt.setName('idea').setDescription('Your suggestion').setRequired(true)))
    .addSubcommand(sub => sub.setName('review').setDescription('Review a suggestion').addStringOption(opt => opt.setName('id').setDescription('Suggestion ID').setRequired(true)).addStringOption(opt => opt.setName('decision').setDescription('Decision').addChoices({ name: 'Approved', value: 'Approved' }, { name: 'Denied', value: 'Denied' }, { name: 'Implemented', value: 'Implemented' }).setRequired(true)).addStringOption(opt => opt.setName('reason').setDescription('Reason').setRequired(false))),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: 'Use this command inside a server.', flags: 64 });
    const config = getGuildConfig(interaction.guildId);
    const suggestionsChannelId = config.channels.suggestions;
    if (!suggestionsChannelId) return interaction.reply({ content: 'Set a suggestions channel first using `!config channel suggestions #channel`.', flags: 64 });

    const sub = interaction.options.getSubcommand();
    if (sub === 'submit') {
      const idea = interaction.options.getString('idea', true);
      const suggestions = readSuggestions();
      const guildSuggestions = suggestions[interaction.guildId] || [];
      const id = `SUG-${Date.now()}`;
      const record = { id, authorId: interaction.user.id, idea, status: 'Pending', votes: { up: 0, down: 0 }, voters: { up: [], down: [] }, createdAt: Date.now() };
      guildSuggestions.push(record);
      suggestions[interaction.guildId] = guildSuggestions;
      writeSuggestions(suggestions);

      const channel = interaction.guild.channels.cache.get(suggestionsChannelId) || await interaction.guild.channels.fetch(suggestionsChannelId).catch(() => null);
      if (!channel || !channel.isTextBased()) return interaction.reply({ content: 'The configured suggestions channel is unavailable.', flags: 64 });

      const upvote = new ButtonBuilder().setCustomId(`suggest_up_${id}`).setLabel('Upvote').setStyle(ButtonStyle.Success);
      const downvote = new ButtonBuilder().setCustomId(`suggest_down_${id}`).setLabel('Downvote').setStyle(ButtonStyle.Danger);
      const voters = new ButtonBuilder().setCustomId(`suggest_view_${id}`).setLabel('View Voters').setStyle(ButtonStyle.Secondary);
      const row = new ActionRowBuilder().addComponents(upvote, downvote, voters);
      const embed = new EmbedBuilder().setColor(0x10b981).setTitle(`Suggestion ${id}`).setDescription(idea).addFields(
        { name: 'Submitted By', value: `<@${interaction.user.id}>`, inline: true },
        { name: 'Status', value: 'Pending', inline: true },
        { name: 'Votes', value: `👍 ${record.votes.up} / 👎 ${record.votes.down}`, inline: true },
      );

      await channel.send({ embeds: [embed], components: [row] });
      return interaction.reply({ content: `Suggestion ${id} submitted.`, flags: 64 });
    }

    if (sub === 'review') {
      if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageMessages)) {
        return interaction.reply({ content: 'Meow Ghop Ghop Ghop 🐱', flags: 64 });
      }
      const decision = interaction.options.getString('decision', true);
      const reason = interaction.options.getString('reason') || 'No reason provided';
      const id = interaction.options.getString('id', true);
      const suggestions = readSuggestions();
      const guildSuggestions = suggestions[interaction.guildId] || [];
      const record = guildSuggestions.find(item => item.id === id);
      if (!record) return interaction.reply({ content: `Suggestion ${id} not found.`, flags: 64 });
      record.status = decision;
      record.reviewReason = reason;
      writeSuggestions(suggestions);
      return interaction.reply({ content: `Suggestion ${id} marked as **${decision}**.`, flags: 64 });
    }

    return interaction.reply({ content: 'Unknown subcommand.', flags: 64 });
  },
};
