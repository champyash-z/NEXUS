const { SlashCommandBuilder, MessageFlags } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder().setName('ping').setDescription('Check whether Nexus is online.'),
  async execute(interaction) {
    // Use the current discord.js v14 flags API instead of deprecated ephemeral.
    return interaction.reply({ content: 'Pong! :ping_pong: Ghop Ghop Ghop :cat:.', flags: MessageFlags.Ephemeral });
  }
};
