const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { clearWarnings } = require('../utils/warnings');

module.exports = {
  data: new SlashCommandBuilder().setName('clearwarnings').setDescription('Clear recorded warnings for a member.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('Member whose warnings to clear').setRequired(true)),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: 'Use this command inside a server.', flags: 64 });
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ModerateMembers)) return interaction.reply({ content: 'Meow Ghop Ghop Ghop 🐱', flags: 64 });
    const user = interaction.options.getUser('user', true);
    const count = clearWarnings(interaction.guildId, user.id);
    await interaction.reply({ content: `Cleared ${count} warning(s) for **${user.tag}**.`, flags: 64 });
  }
};
