const {
  SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder,
  PermissionFlagsBits, AttachmentBuilder, ChannelType, StringSelectMenuBuilder
} = require('discord.js');
const fs = require('node:fs');
const path = require('node:path');
const { getGuildConfig, setGuildConfig } = require('../utils/config');
const { getTicketRecord, addEvent, closeTicketAndTranscript, fetchAllMessages, makeTranscript, db } = require('../utils/tickets');

const STAFF_PERMS = [PermissionFlagsBits.ManageChannels, PermissionFlagsBits.Administrator];
function isStaff(interaction, ticket) {
  return Boolean(interaction.memberPermissions?.hasAny(...STAFF_PERMS) || (ticket.staff_role_id && interaction.member?.roles?.cache?.has(ticket.staff_role_id)));
}
function isAdmin(interaction) {
  return Boolean(interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild) || interaction.memberPermissions?.has(PermissionFlagsBits.Administrator));
}
function safeName(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').slice(0, 90) || 'ticket'; }

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket').setDescription('Configure and manage the Nexus ticket system.')
    .addSubcommand(s => s.setName('panel').setDescription('Post a customizable ticket panel in this channel')
      .addStringOption(o => o.setName('title').setDescription('Panel heading').setMaxLength(180))
      .addStringOption(o => o.setName('description').setDescription('Panel instructions').setMaxLength(3500))
      .addStringOption(o => o.setName('banner_url').setDescription('Optional direct HTTPS banner URL').setMaxLength(500)))
    .addSubcommand(s => s.setName('setup').setDescription('Configure the ticket category and staff role')
      .addChannelOption(o => o.setName('category').setDescription('Category where private ticket channels are created').addChannelTypes(ChannelType.GuildCategory).setRequired(true))
      .addRoleOption(o => o.setName('staff_role').setDescription('Role allowed to view and manage tickets').setRequired(true))
      .addChannelOption(o => o.setName('log_channel').setDescription('Optional ticket transcript/log channel').addChannelTypes(ChannelType.GuildText)))
    .addSubcommand(s => s.setName('help').setDescription('Show ticket system commands'))
    .addSubcommand(s => s.setName('claim').setDescription('Claim the current ticket'))
    .addSubcommand(s => s.setName('unclaim').setDescription('Release your claim on the current ticket'))
    .addSubcommand(s => s.setName('close').setDescription('Close and archive the current ticket').addStringOption(o => o.setName('reason').setDescription('Reason for closing').setMaxLength(200)))
    .addSubcommand(s => s.setName('info').setDescription('Show details for the current ticket'))
    .addSubcommand(s => s.setName('priority').setDescription('Set ticket priority').addStringOption(o => o.setName('level').setDescription('Priority').setRequired(true).addChoices({name:'Low',value:'Low'},{name:'Normal',value:'Normal'},{name:'High',value:'High'},{name:'Urgent',value:'Urgent'})))
    .addSubcommand(s => s.setName('rename').setDescription('Rename the current ticket').addStringOption(o => o.setName('name').setDescription('New channel name').setRequired(true).setMaxLength(90)))
    .addSubcommand(s => s.setName('add').setDescription('Add a member to this ticket').addUserOption(o => o.setName('user').setDescription('Member to add').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove a member from this ticket').addUserOption(o => o.setName('user').setDescription('Member to remove').setRequired(true)))
    .addSubcommand(s => s.setName('transcript').setDescription('Generate an HTML transcript without closing the ticket'))
    .addSubcommand(s => s.setName('notes').setDescription('Create a private staff notes thread'))
    .addSubcommand(s => s.setName('stats').setDescription('Show ticket and satisfaction statistics'))
    .addSubcommand(s => s.setName('transfer').setDescription('Transfer this ticket to another staff team')
      .addRoleOption(o => o.setName('staff_role').setDescription('New staff role for this ticket').setRequired(true)))
    .addSubcommand(s => s.setName('reopen').setDescription('Reopen a recently closed ticket channel'))
    .addSubcommand(s => s.setName('close_request').setDescription('Request that staff close your ticket'))
    .addSubcommand(s => s.setName('autoclose').setDescription('Configure automatic closure after ticket inactivity')
      .addIntegerOption(o => o.setName('hours').setDescription('Inactivity hours; use 0 to disable').setMinValue(0).setMaxValue(720).setRequired(true))),

  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: 'Use this command inside a server.', flags: 64 });
    const sub = interaction.options.getSubcommand();
    if (sub === 'help') {
      const embed = new EmbedBuilder().setColor(0x7c3aed).setTitle('🎫 Nexus Ticket Commands').setDescription([
        '`!ticket setup` — set ticket category, staff role and optional logs', '`!ticket panel` — post a customizable panel',
        '`!ticket claim` / `!ticket unclaim` — manage assignment', '`!ticket close reason:` — close and send the report',
        '`!ticket info` — inspect the current ticket', '`!ticket priority level:` — change priority',
        '`!ticket rename name:` — rename the channel', '`!ticket add user:` / `!ticket remove user:` — manage access',
        '`!ticket transcript` — export current history', '`!ticket notes` — create a private staff notes thread', '`!ticket stats` — ratings and ticket totals',
        '`!ticket transfer staff_role:` — transfer to another staff team', '`!ticket close_request` — ask staff to close your ticket', '`!ticket reopen` — reopen a closed ticket', '`!ticket autoclose hours:` — configure inactivity auto-close (0 disables)'
      ].join('\n')).setFooter({ text: 'Nexus Support • All ticket actions are permission-checked' });
      return interaction.reply({ embeds: [embed], flags: 64 });
    }
    if (sub === 'setup') {
      if (!isAdmin(interaction)) return interaction.reply({ content: 'You need Manage Server permission to configure tickets.', flags: 64 });
      const category = interaction.options.getChannel('category');
      const role = interaction.options.getRole('staff_role');
      const log = interaction.options.getChannel('log_channel');
      const cfg = getGuildConfig(interaction.guildId);
      setGuildConfig(interaction.guildId, { ...cfg, ticketStaffRoleId: role.id, channels: { ...cfg.channels, ticketCategory: category.id, ...(log ? { modlog: log.id } : {}) } });
      return interaction.reply({ content: `Ticket setup saved. Category: <#${category.id}> · Staff role: <@&${role.id}>${log ? ` · Logs: <#${log.id}>` : ''}`, flags: 64 });
    }
    if (sub === 'panel') {
      if (!isAdmin(interaction)) return interaction.reply({ content: 'You need Manage Server permission to publish a ticket panel.', flags: 64 });
      const title = interaction.options.getString('title') || 'NEXUS SUPPORT CENTER';
      const description = interaction.options.getString('description') || [
        'Welcome to **Nexus Support**. Choose the category that best matches your request.', '',
        '🛠️ **Support** · General help\n🐛 **Bug Report** · Report an issue\n💡 **Feature Request** · Suggest an improvement\n🤝 **Partnership** · Business inquiries\n💳 **Billing** · Payment or purchase questions\n🚩 **User Report** · Report a player or member\n📌 **Other** · Anything else', '',
        'Your ticket is private. Please provide accurate details and avoid opening duplicate tickets.'
      ].join('\n');
      const bannerUrl = interaction.options.getString('banner_url');
      if (bannerUrl && !/^https:\/\//i.test(bannerUrl)) return interaction.reply({ content: 'The banner URL must be a direct HTTPS URL.', flags: 64 });
      const embed = new EmbedBuilder().setColor(0x7c3aed).setAuthor({ name: `${interaction.guild.name} • Nexus Support`, iconURL: interaction.guild.iconURL({ size: 128 }) || undefined }).setTitle(`🎫 ${title}`).setDescription(description).addFields(
        { name: '🔒 Private tickets', value: 'Only you and authorized support staff can see your ticket.', inline: true },
        { name: '⚡ What happens next?', value: 'A support channel is created after you submit the ticket form.', inline: true }
      ).setFooter({ text: 'Nexus Support • Clear details help us respond faster' }).setTimestamp();
      if (bannerUrl) embed.setImage(bannerUrl);
      const row = new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('ticket_category_select').setPlaceholder('Choose a ticket category…').addOptions(
        { label: 'Support', value: 'Support', description: 'General questions and help', emoji: '🛠️' },
        { label: 'Bug Report', value: 'Bug Report', description: 'Report a bug or technical issue', emoji: '🐛' },
        { label: 'Feature Request', value: 'Feature Request', description: 'Suggest an improvement', emoji: '💡' },
        { label: 'Partnership', value: 'Partnership', description: 'Business and partnership inquiries', emoji: '🤝' },
        { label: 'Billing', value: 'Billing', description: 'Payments and purchases', emoji: '💳' },
        { label: 'User Report', value: 'User Report', description: 'Report a player or member', emoji: '🚩' },
        { label: 'Other', value: 'Other', description: 'Anything else', emoji: '📌' }
      ));
      await interaction.channel.send({ embeds: [embed], components: [row] });
      return interaction.reply({ content: 'Ticket panel posted.', flags: 64 });
    }
    if (sub === 'autoclose') {
      if (!isAdmin(interaction)) return interaction.reply({ content: 'You need Manage Server permission to configure auto-close.', flags: 64 });
      const hours = interaction.options.getInteger('hours');
      const cfg = getGuildConfig(interaction.guildId);
      setGuildConfig(interaction.guildId, { ...cfg, ticketAutoCloseHours: hours });
      return interaction.reply({ content: hours === 0 ? 'Automatic ticket closure is disabled.' : `Tickets will be auto-closed after ${hours} hours without activity. The bot will notify the ticket before closing.`, flags: 64 });
    }
    if (sub === 'stats') {
      if (!isAdmin(interaction)) return interaction.reply({ content: 'You need Manage Server permission to view server-wide ticket statistics.', flags: 64 });
      const totals = db.prepare('SELECT COUNT(*) total, SUM(CASE WHEN status IN (\'open\',\'claimed\') THEN 1 ELSE 0 END) open, SUM(CASE WHEN status=\'closed\' THEN 1 ELSE 0 END) closed FROM tickets WHERE guild_id=?').get(interaction.guildId);
      const ratings = db.prepare('SELECT COUNT(*) count, AVG(rating) average FROM ticket_ratings WHERE guild_id=?').get(interaction.guildId);
      const embed = new EmbedBuilder().setColor(0x7c3aed).setTitle('📊 Nexus Ticket Statistics').addFields(
        { name: 'All tickets', value: String(totals.total || 0), inline: true }, { name: 'Open', value: String(totals.open || 0), inline: true },
        { name: 'Closed', value: String(totals.closed || 0), inline: true }, { name: 'Ratings', value: String(ratings.count || 0), inline: true },
        { name: 'Average rating', value: ratings.average == null ? 'Not rated yet' : `${Number(ratings.average).toFixed(2)} / 5 ⭐`, inline: true }
      );
      return interaction.reply({ embeds: [embed], flags: 64 });
    }

    const ticket = getTicketRecord(interaction.guildId, interaction.channelId);
    if (sub === 'close_request') {
      if (!ticket) return interaction.reply({ content: 'Use this inside your open ticket.', flags: 64 });
      if (ticket.owner_id !== interaction.user.id && !isStaff(interaction, ticket)) return interaction.reply({ content: 'Only the ticket creator or support staff can request closure.', flags: 64 });
      db.prepare("UPDATE tickets SET close_requested_at=? WHERE channel_id=? AND status IN ('open','claimed')").run(Date.now(), interaction.channelId);
      addEvent(interaction.channelId, 'close_requested', interaction.user.id);
      const rolePing = ticket.staff_role_id ? `<@&${ticket.staff_role_id}> ` : '';
      await interaction.channel.send({ content: `${rolePing}🔒 <@${ticket.owner_id}> has requested that this ticket be closed. Staff can use \`!ticket close\` when ready.` });
      return interaction.reply({ content: 'Your close request has been sent to the support team.', flags: 64 });
    }
    if (sub === 'reopen') {
      if (!isAdmin(interaction)) return interaction.reply({ content: 'Only server administrators can reopen archived tickets.', flags: 64 });
      const closed = db.prepare("SELECT * FROM tickets WHERE guild_id=? AND channel_id=? AND status='closed'").get(interaction.guildId, interaction.channelId);
      if (!closed) return interaction.reply({ content: 'This channel is not a closed ticket.', flags: 64 });
      db.prepare("UPDATE tickets SET status='open',closed_at=NULL,closed_by=NULL,close_reason=NULL,last_activity_at=? WHERE channel_id=?").run(Date.now(), interaction.channelId);
      await interaction.channel.setName(interaction.channel.name.replace(/^closed-/, '').slice(0, 100)).catch(() => {});
      await interaction.channel.permissionOverwrites.edit(closed.owner_id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true }).catch(() => {});
      addEvent(interaction.channelId, 'reopened', interaction.user.id);
      await interaction.channel.send(`🔓 Ticket reopened by <@${interaction.user.id}>.`);
      return interaction.reply({ content: 'Ticket reopened.', flags: 64 });
    }
    if (!ticket) return interaction.reply({ content: 'This command must be used inside a registered ticket channel.', flags: 64 });
    const staff = isStaff(interaction, ticket);
    if (['claim','unclaim','close','priority','rename','add','remove','transcript','notes','transfer'].includes(sub) && !staff) return interaction.reply({ content: 'Only authorized support staff can use this action.', flags: 64 });

    if (sub === 'claim') {
      const result = db.prepare("UPDATE tickets SET claimed_by=?,claimed_at=?,status='claimed' WHERE channel_id=? AND status='open' AND claimed_by IS NULL").run(interaction.user.id, Date.now(), interaction.channelId);
      if (!result.changes) return interaction.reply({ content: 'This ticket is already claimed or is not open.', flags: 64 });
      addEvent(interaction.channelId, 'claimed', interaction.user.id);
      return interaction.reply({ content: `Ticket claimed by <@${interaction.user.id}>.` });
    }
    if (sub === 'unclaim') {
      const result = db.prepare("UPDATE tickets SET claimed_by=NULL,claimed_at=NULL,status='open' WHERE channel_id=? AND status='claimed' AND (claimed_by=? OR ?=1)").run(interaction.channelId, interaction.user.id, isAdmin(interaction) ? 1 : 0);
      if (!result.changes) return interaction.reply({ content: 'Only the assigned staff member or an administrator can unclaim this ticket.', flags: 64 });
      addEvent(interaction.channelId, 'unclaimed', interaction.user.id);
      return interaction.reply({ content: 'Ticket returned to the support queue.' });
    }
    if (sub === 'close') {
      await interaction.reply({ content: 'Closing ticket, saving transcript, and preparing the closure report…', flags: 64 });
      const result = await closeTicketAndTranscript(interaction.client, interaction.channel, interaction.user, interaction.options.getString('reason') || 'No reason provided');
      if (!result.ok) await interaction.followUp({ content: 'Ticket could not be closed; it may already be closing or closed.', flags: 64 }).catch(() => {});
      else if (!result.dmSent) await interaction.followUp({ content: 'Ticket archived, but the creator DM could not be delivered. The failure is logged.', flags: 64 }).catch(() => {});
      return;
    }
    if (sub === 'info') {
      const embed = new EmbedBuilder().setColor(0x7c3aed).setTitle(`🎫 Ticket ${ticket.ticket_id}`).addFields(
        { name: 'Creator', value: `<@${ticket.owner_id}>`, inline: true }, { name: 'Category', value: ticket.category || 'Support', inline: true },
        { name: 'Status', value: ticket.status, inline: true }, { name: 'Priority', value: ticket.priority || 'Normal', inline: true },
        { name: 'Claimed by', value: ticket.claimed_by ? `<@${ticket.claimed_by}>` : 'Not assigned', inline: true },
        { name: 'Opened', value: `<t:${Math.floor(ticket.created_at/1000)}:F>`, inline: true },
        { name: 'Subject', value: (ticket.subject || 'Not provided').slice(0, 1024) }, { name: 'Description', value: (ticket.description || 'Not provided').slice(0, 1024) }
      );
      return interaction.reply({ embeds: [embed], flags: 64 });
    }
    if (sub === 'transfer') {
      const role = interaction.options.getRole('staff_role');
      if (role.id === interaction.guild.roles.everyone.id) return interaction.reply({ content: 'You cannot transfer a ticket to @everyone.', flags: 64 });
      const oldRole = ticket.staff_role_id;
      if (oldRole) await interaction.channel.permissionOverwrites.delete(oldRole).catch(() => {});
      await interaction.channel.permissionOverwrites.edit(role.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true });
      db.prepare('UPDATE tickets SET staff_role_id=? WHERE channel_id=?').run(role.id, interaction.channelId);
      addEvent(interaction.channelId, 'transferred', interaction.user.id, { fromRoleId: oldRole, toRoleId: role.id });
      await interaction.channel.send(`🔁 Ticket transferred to <@&${role.id}> by <@${interaction.user.id}>.`);
      return interaction.reply({ content: `Ticket transferred to ${role}.`, flags: 64 });
    }
    if (sub === 'priority') {
      const level = interaction.options.getString('level');
      db.prepare('UPDATE tickets SET priority=? WHERE channel_id=?').run(level, interaction.channelId);
      addEvent(interaction.channelId, 'priority_changed', interaction.user.id, { priority: level });
      return interaction.reply({ content: `Ticket priority set to **${level}**.` });
    }
    if (sub === 'rename') {
      const name = safeName(interaction.options.getString('name'));
      await interaction.channel.setName(name);
      addEvent(interaction.channelId, 'renamed', interaction.user.id, { name });
      return interaction.reply({ content: `Ticket renamed to **${name}**.` });
    }
    if (sub === 'add' || sub === 'remove') {
      const user = interaction.options.getUser('user');
      const member = await interaction.guild.members.fetch(user.id).catch(() => null);
      if (!member) return interaction.reply({ content: 'That member is not in this server.', flags: 64 });
      if (sub === 'add') {
        await interaction.channel.permissionOverwrites.edit(user.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true });
      } else {
        if (user.id === ticket.owner_id) return interaction.reply({ content: 'You cannot remove the ticket creator.', flags: 64 });
        await interaction.channel.permissionOverwrites.delete(user.id).catch(() => {});
      }
      addEvent(interaction.channelId, sub === 'add' ? 'participant_added' : 'participant_removed', interaction.user.id, { userId: user.id });
      return interaction.reply({ content: sub === 'add' ? `Added <@${user.id}> to this ticket.` : `Removed <@${user.id}> from this ticket.` });
    }
    if (sub === 'transcript') {
      await interaction.deferReply({ flags: 64 });
      const messages = await fetchAllMessages(interaction.channel);
      const html = makeTranscript(interaction.channel, messages);
      const out = path.join(__dirname, '..', '..', 'data', 'transcripts', `ticket-${interaction.channelId}-manual.html`);
      fs.mkdirSync(path.dirname(out), { recursive: true }); fs.writeFileSync(out, html, 'utf8');
      return interaction.editReply({ content: `Transcript generated (${messages.length} recorded messages).`, files: [new AttachmentBuilder(out, { name: `nexus-ticket-${interaction.channelId}-transcript.html` })] });
    }
    if (sub === 'notes') {
      const thread = await interaction.channel.threads.create({ name: `staff-notes-${interaction.channelId.slice(-6)}`, autoArchiveDuration: 1440, type: ChannelType.PrivateThread, invitable: false, reason: 'Private staff notes for ticket' });
      await thread.members.add(interaction.user.id).catch(() => {});
      if (ticket.staff_role_id) {
        const role = interaction.guild.roles.cache.get(ticket.staff_role_id);
        if (role) for (const [, member] of role.members) await thread.members.add(member.id).catch(() => {});
      }
      addEvent(interaction.channelId, 'staff_notes_created', interaction.user.id, { threadId: thread.id });
      return interaction.reply({ content: `Private staff notes thread created: <#${thread.id}>. Only invited staff can access it.`, flags: 64 });
    }
    return interaction.reply({ content: 'Unknown ticket action. Use `!ticket help`.', flags: 64 });
  }
};
