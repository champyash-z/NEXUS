const { SlashCommandBuilder } = require('discord.js');
const { addReminder, listReminders, cancelReminder, parseDuration } = require('../utils/reminders');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('remind')
    .setDescription('Create or manage reminders.')
    .addSubcommand(sub => sub.setName('me').setDescription('Create a reminder').addStringOption(opt => opt.setName('duration').setDescription('30s, 10m, 2h, 1d').setRequired(true)).addStringOption(opt => opt.setName('message').setDescription('Reminder message').setRequired(true)))
    .addSubcommand(sub => sub.setName('list').setDescription('List your reminders'))
    .addSubcommand(sub => sub.setName('cancel').setDescription('Cancel a reminder').addStringOption(opt => opt.setName('id').setDescription('Reminder ID').setRequired(true))),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: 'Use this command inside a server.', flags: 64 });
    const sub = interaction.options.getSubcommand();

    if (sub === 'me') {
      const duration = interaction.options.getString('duration', true);
      const text = interaction.options.getString('message', true);
      const parsed = parseDuration(duration);
      if (!parsed) return interaction.reply({ content: 'Supported durations: 30s, 10m, 2h, 1d.', flags: 64 });
      const reminder = addReminder({ guildId: interaction.guildId, userId: interaction.user.id, message: text, duration });
      return interaction.reply({ content: `Reminder created with ID \`${reminder.id}\`. It will fire in ${duration}.`, flags: 64 });
    }

    if (sub === 'list') {
      const reminders = listReminders(interaction.guildId, interaction.user.id);
      if (!reminders.length) return interaction.reply({ content: 'You have no active reminders.', flags: 64 });
      const lines = reminders.map(r => `**${r.id}** — ${r.duration} — ${r.message}`).join('\n');
      return interaction.reply({ content: lines.slice(0, 1800), flags: 64 });
    }

    if (sub === 'cancel') {
      const id = interaction.options.getString('id', true);
      const removed = cancelReminder(id);
      return interaction.reply({ content: removed ? `Reminder ${id} cancelled.` : `Reminder ${id} was not found.`, flags: 64 });
    }

    return interaction.reply({ content: 'Unknown reminder subcommand.', flags: 64 });
  },
};
