const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder().setName('help').setDescription('Legacy command help (prefix commands use !, . or ?).'),
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('Nexus — Command Help')
      .setDescription('Use `!`, `.`, or `?` before a command. Example: `!ping`.')
      .addFields(
        { name: 'Utility', value: '`!ping` `!help` `!serverinfo` `!userinfo @user` `!rank` `!leaderboard`' },
        { name: 'Moderation', value: '`!purge` `!kick` `!ban` `!timeout` `!warn` `!warnings` `!clearwarnings` `!mute` `!unmute`' },
        { name: 'Community', value: '`!p Question | Option 1 | Option 2` `!ticket` `!suggest` `!remind`' }
      )
      .setFooter({ text: 'Nexus • Community bot' });
    await interaction.reply({ embeds: [embed], flags: 64 });
  }
};
