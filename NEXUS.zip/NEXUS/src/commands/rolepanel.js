const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, ActionRowBuilder } = require('discord.js');
const fs = require('node:fs');
const path = require('node:path');

const dataDir = path.join(__dirname, '..', '..', 'data');
const filePath = path.join(dataDir, 'rolepanels.json');

function ensureFile() {
  fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, '{}', 'utf8');
}

function readPanels() {
  ensureFile();
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return {};
  }
}

function writePanels(data) {
  ensureFile();
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rolepanel')
    .setDescription('Manage self-assignable role panels.')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub => sub.setName('add').setDescription('Add a role to the panel').addRoleOption(opt => opt.setName('role').setDescription('Role to add').setRequired(true)).addStringOption(opt => opt.setName('label').setDescription('Button or label').setRequired(true)).addStringOption(opt => opt.setName('description').setDescription('Optional role description').setRequired(false)))
    .addSubcommand(sub => sub.setName('remove').setDescription('Remove a role from the panel').addRoleOption(opt => opt.setName('role').setDescription('Role to remove').setRequired(true)))
    .addSubcommand(sub => sub.setName('send').setDescription('Send the role panel embed')),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: 'Use this command inside a server.', flags: 64 });
    const sub = interaction.options.getSubcommand();

    if (sub === 'add') {
      const role = interaction.options.getRole('role', true);
      const label = interaction.options.getString('label', true);
      const description = interaction.options.getString('description') || '';
      const panels = readPanels();
      panels[interaction.guildId] = panels[interaction.guildId] || [];
      const existing = panels[interaction.guildId].find(item => item.roleId === role.id);
      if (existing) {
        existing.label = label;
        existing.description = description;
      } else {
        panels[interaction.guildId].push({ roleId: role.id, label, description });
      }
      writePanels(panels);
      return interaction.reply({ content: `Role panel entry added for <@&${role.id}>.`, flags: 64 });
    }

    if (sub === 'remove') {
      const role = interaction.options.getRole('role', true);
      const panels = readPanels();
      const list = panels[interaction.guildId] || [];
      panels[interaction.guildId] = list.filter(item => item.roleId !== role.id);
      writePanels(panels);
      return interaction.reply({ content: `Removed <@&${role.id}> from the panel.`, flags: 64 });
    }

    if (sub === 'send') {
      const panels = readPanels();
      const entries = panels[interaction.guildId] || [];
      if (!entries.length) return interaction.reply({ content: 'Add at least one role to the panel first.', flags: 64 });
      const select = new StringSelectMenuBuilder()
        .setCustomId('selfrole_select')
        .setPlaceholder('Select a role to add or remove')
        .addOptions(entries.map(({ roleId, label, description }) => new StringSelectMenuOptionBuilder().setValue(roleId).setLabel(label || interaction.guild.roles.cache.get(roleId)?.name || 'Role').setDescription(description || 'Self-assignable role')));
      const embed = new EmbedBuilder().setTitle('Self-Assignable Roles').setDescription('Choose one or more roles from the menu below.').setColor(0x8b5cf6);
      await interaction.reply({ embeds: [embed], components: [new ActionRowBuilder().addComponents(select)] });
      return;
    }

    return interaction.reply({ content: 'Unknown subcommand.', flags: 64 });
  },
};
