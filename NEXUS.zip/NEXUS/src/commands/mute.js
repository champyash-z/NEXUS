const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Mute Nexus in this channel.'),

  async execute(interaction) {
    if (!interaction.inGuild()) {
      await interaction.reply({ content: 'Use this command inside a server.', flags: 64 });
      return;
    }

    const { client } = interaction;
    client.mutedChannels.add(interaction.channelId);
    await interaction.reply({ content: 'Okay now I will not say anything, sorry for disturbing you.', flags: 64 });
  }
};
