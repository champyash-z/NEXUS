const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Unmute Nexus in this channel.'),

  async execute(interaction) {
    if (!interaction.inGuild()) {
      await interaction.reply({ content: 'Use this command inside a server.', flags: 64 });
      return;
    }

    const { client } = interaction;
    client.mutedChannels.delete(interaction.channelId);
    await interaction.reply({ content: 'You cant keep me quiet for long! Yahoo, I am back! Admit it, you cant live without me, bro.', flags: 64 });
  }
};
