const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder().setName('serverinfo').setDescription('Show information about this server.'),
  async execute(interaction) {
    const guild = interaction.guild;
    if (!guild) return interaction.reply({ content: 'Use this command inside a server.', flags: 64 });
    const embed = new EmbedBuilder().setColor(0x5865F2).setTitle(guild.name)
      .setThumbnail(guild.iconURL({ size: 256 }))
      .addFields(
        { name: 'Members', value: `${guild.memberCount}`, inline: true },
        { name: 'Created', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true },
        { name: 'Owner', value: `<@${guild.ownerId}>`, inline: true }
      );
    await interaction.reply({ embeds: [embed], flags: 64 });
  }
};
