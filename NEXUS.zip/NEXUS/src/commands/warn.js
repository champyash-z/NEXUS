const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { addWarning } = require('../utils/warnings');

module.exports = {
  data: new SlashCommandBuilder().setName('warn').setDescription('Record a warning for a member.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('Member to warn').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for warning').setMaxLength(500).setRequired(true)),
  async execute(interaction) {
    if (!interaction.inGuild()) return interaction.reply({ content: 'Use this command inside a server.', flags: 64 });
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ModerateMembers)) return interaction.reply({ content: 'Meow Ghop Ghop Ghop 🐱', flags: 64 });
    const user = interaction.options.getUser('user', true);
    if (user.id === interaction.user.id) return interaction.reply({ content: 'You cannot warn yourself.', flags: 64 });
    const reason = interaction.options.getString('reason', true);
    const warnings = addWarning(interaction.guildId, user.id, {
      reason, moderatorId: interaction.user.id, createdAt: new Date().toISOString()
    });
    await interaction.reply({ content: `Warned **${user.tag}**. They now have **${warnings.length}** recorded warning(s). Reason: ${reason}`, flags: 64 });
  }
};
