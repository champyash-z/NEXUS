const { Chess } = require('chess.js');
const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const games = new Map(); // channelId -> live match
const invites = new Map(); // inviteId -> invitation
const saveFile = path.join(__dirname, '..', 'data', 'chess-saves.json');
const PIECES = { w: { k:'♔', q:'♕', r:'♖', b:'♗', n:'♘', p:'♙' }, b: { k:'♚', q:'♛', r:'♜', b:'♝', n:'♞', p:'♟︎' } };
function readSaves() { try { const v=JSON.parse(fs.readFileSync(saveFile,'utf8')); return v&&typeof v==='object'?v:{}; } catch { return {}; } }
function writeSaves(v) { fs.mkdirSync(path.dirname(saveFile),{recursive:true}); const tmp=saveFile+'.tmp'; fs.writeFileSync(tmp,JSON.stringify(v,null,2),'utf8'); fs.renameSync(tmp,saveFile); }
function hashPassword(password) {
  const salt=crypto.randomBytes(16).toString('hex');
  return `${salt}:${crypto.scryptSync(String(password),salt,32).toString('hex')}`;
}
function verifyPassword(password, stored) {
  if (!password || !stored) return false;
  try {
    const [salt,hex]=String(stored).split(':');
    if(!salt||!hex) return false;
    const a=crypto.scryptSync(String(password),salt,32), b=Buffer.from(hex,'hex');
    return a.length===b.length&&crypto.timingSafeEqual(a,b);
  } catch { return false; }
}
function boardText(chess) {
  return chess.board().map((row,r)=>`${8-r}  ${row.map((sq,c)=>sq?PIECES[sq.color][sq.type]:((r+c)%2===0?'·':'　')).join(' ')}`).join('\n')+'\n   a b c d e f g h';
}
function statusText(g) {
  if(g.isCheckmate()) return `Checkmate — ${g.turn()==='w'?'Black':'White'} wins.`;
  if(g.isStalemate()) return 'Draw — stalemate.';
  if(g.isThreefoldRepetition()) return 'Draw — threefold repetition.';
  if(g.isInsufficientMaterial()) return 'Draw — insufficient material.';
  if(g.isDraw()) return 'Draw.';
  return `${g.turn()==='w'?'White':'Black'} to move${g.isCheck()?' · CHECK':''}`;
}
function legalBySquare(g) {
  const out={}; for(const m of g.moves({verbose:true})) (out[m.from]??=[]).push(m);
  return out;
}
function components(channelId, session) {
  if (!session.blackId || session.game.isGameOver()) return [];
  const map=legalBySquare(session.game), squares=Object.keys(map);
  if (!squares.length) return [];
  const pieceRow=new ActionRowBuilder().addComponents(new StringSelectMenuBuilder()
    .setCustomId(`nch_piece:${channelId}`).setPlaceholder('1 · Select a piece to move')
    .addOptions(squares.slice(0,25).map(sq=>({label:`${sq.toUpperCase()} · ${session.game.get(sq).color==='w'?'White':'Black'} ${session.game.get(sq).type.toUpperCase()}`,value:sq}))));
  const rows=[pieceRow];
  const selected=session.selectedSquare;
  if(selected && map[selected]) {
    const opts=map[selected].slice(0,25).map(m=>({label:`${m.to.toUpperCase()}${m.promotion?` · promote to ${m.promotion.toUpperCase()}`:''}`,value:`${m.to}${m.promotion||''}`,description:m.san}));
    if(opts.length) rows.push(new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId(`nch_dest:${channelId}`).setPlaceholder('2 · Choose destination').addOptions(opts)));
  }
  return rows;
}
function embed(session, note='') {
  const g=session.game;
  return new EmbedBuilder().setColor(g.isGameOver()?0x64748b:0x5865f2).setTitle('♟️ NEXUS CHESS')
    .setDescription(`\`\`\`\n${boardText(g)}\n\`\`\`\n${note?`${note}\n\n`:''}**White:** <@${session.whiteId}>\n**Black:** ${session.blackId?`<@${session.blackId}>`:'Waiting for opponent'}\n**Turn:** ${statusText(g)}`)
    .addFields({name:'Touch controls',value:'Select a piece, then choose its destination from the menus below. Coordinate moves also work: `!chess e2e4`.'})
    .setFooter({text:'NEXUS • Chess'});
}
async function refresh(session, channel, note='') {
  const payload={embeds:[embed(session,note)],components:components(channel.id,session)};
  if(session.messageId) {
    const old=await channel.messages.fetch(session.messageId).catch(()=>null);
    if(old) return old.edit(payload);
  }
  const sent=await channel.send(payload); session.messageId=sent.id; return sent;
}
function restoreGame(saved) {
  const game=new Chess();
  for(const m of saved.moves||[]) game.move({from:m.from,to:m.to,promotion:m.promotion||undefined});
  return game;
}
async function handleCommand(message,args) {
  if(!message.guild) return message.reply('Chess commands must be used in a server.');
  const sub=String(args[0]||'help').toLowerCase(), channelId=message.channel.id;
  let s=games.get(channelId);
  if(sub==='help') return message.reply({embeds:[new EmbedBuilder().setColor(0x5865f2).setTitle('♟️ NEXUS CHESS • COMMAND GUIDE').setDescription('Play together with touchscreen menus or coordinate moves. All commands support `!`, `.` and `?`.').addFields(
    {name:'Start & join',value:'`!chess start [password]` — create a private match\n`!chess join [password]` — join as Black'},
    {name:'Touchscreen & moves',value:'Select a piece and destination on the chess panel, or use `!chess e2e4`, `!chess Nf3`, `!chess board`, `!chess moves`.'},
    {name:'Save & resume',value:'`!chess save <match name>` — save your current game\n`!chess load <match name> <password>` — resume a saved game\n`!chess saves` — list your saved games'},
    {name:'Invite & controls',value:'`!chess invite @player` — DM an invitation\n`!chess invite cancel` — cancel your pending invite\n`!chess resign` · `!chess stop`'})
    ]});
  if(sub==='start'||sub==='new') {
    if(s&&!s.game.isGameOver()) return message.reply('A chess match is already active in this channel. Use `!chess stop` first.');
    const password=args.slice(1).join(' ').trim();
    if(password.length>100) return message.reply('Password must be 100 characters or fewer.');
    s={game:new Chess(),whiteId:message.author.id,blackId:null,messageId:null,passwordHash:password?hashPassword(password):null,selectedSquare:null,createdAt:Date.now()};
    games.set(channelId,s);
    return refresh(s,message.channel,`Match created by ${message.author}. ${password?'🔒 Password protected.':'Open match.'} Share ${password?'the password privately and ':''}use \`!chess join${password?' [password]':''}\` to join.`);
  }
  if(sub==='join') {
    if(!s) return message.reply('There is no active match in this channel.');
    if(s.blackId) return message.reply('This match already has two players.');
    if(message.author.id===s.whiteId) return message.reply('You created this match and are already White.');
    const password=args.slice(1).join(' ').trim();
    if(s.passwordHash&&!verifyPassword(password,s.passwordHash)) return message.reply('Incorrect or missing match password.');
    s.blackId=message.author.id; await refresh(s,message.channel,`${message.author} joined as Black. White moves first.`); return;
  }
  if(sub==='save') {
    if(!s) return message.reply('There is no active match to save.');
    if(![s.whiteId,s.blackId].includes(message.author.id)) return message.reply('Only a player in this match can save it.');
    const name=args.slice(1).join(' ').trim();
    if(!name||name.length>40) return message.reply('Usage: `!chess save <match name>` (1–40 characters).');
    const all=readSaves(); const key=`${message.guild.id}:${message.author.id}:${name.toLowerCase()}`;
    all[key]={name,guildId:message.guild.id,ownerId:message.author.id,whiteId:s.whiteId,blackId:s.blackId,moves:s.game.history({verbose:true}).map(m=>({from:m.from,to:m.to,promotion:m.promotion||null})),passwordHash:s.passwordHash,savedAt:Date.now()};
    writeSaves(all); return message.reply(`💾 Saved **${name}**. Resume it with \`!chess load ${name} <password>\`.`);
  }
  if(sub==='saves') {
    const all=readSaves(), list=Object.values(all).filter(x=>x.guildId===message.guild.id&&x.ownerId===message.author.id);
    return message.reply(list.length?`**Your saved matches:**\n${list.map(x=>`• ${x.name} — saved ${new Date(x.savedAt).toLocaleString()}`).join('\n')}`:'You have no saved chess matches.');
  }
  if(sub==='load') {
    const all=readSaves(), rest=args.slice(1), password=rest.length>1?rest[rest.length-1]:'', name=rest.length>1?rest.slice(0,-1).join(' '):rest.join(' ');
    if(!name) return message.reply('Usage: `!chess load <match name> <password>` (use `-` if the match has no password).');
    const key=`${message.guild.id}:${message.author.id}:${name.toLowerCase()}`, saved=all[key];
    if(!saved) return message.reply('Saved match not found. Use `!chess saves` to list your matches.');
    if(saved.passwordHash&&!verifyPassword(password==='-'?'':password,saved.passwordHash)) return message.reply('Incorrect saved-match password.');
    if(s&&!s.game.isGameOver()) return message.reply('An active match already exists here. Stop it before loading another.');
    const game=restoreGame(saved);
    s={game,whiteId:saved.whiteId,blackId:saved.blackId,messageId:null,passwordHash:saved.passwordHash,selectedSquare:null,createdAt:Date.now()};
    games.set(channelId,s); return refresh(s,message.channel,`📂 Loaded saved match **${saved.name}**.`);
  }
  if(sub==='invite') {
    if(!s||message.author.id!==s.whiteId||s.blackId) return message.reply('Create a match first, then invite an opponent before anyone joins.');
    if(args[1]?.toLowerCase()==='cancel') {
      const pending=[...invites.entries()].find(([,v])=>v.channelId===channelId&&v.fromId===message.author.id);
      if(!pending) return message.reply('There is no pending invitation to cancel.');
      invites.delete(pending[0]); return message.reply('Chess invitation cancelled.');
    }
    const user=message.mentions.users.first();
    if(!user||user.bot||user.id===message.author.id) return message.reply('Usage: `!chess invite @player`.');
    const inviteId=crypto.randomBytes(8).toString('hex');
    const invite={id:inviteId,channelId,guildId:message.guild.id,fromId:message.author.id,toId:user.id,createdAt:Date.now()};
    invites.set(inviteId,invite);
    const dmEmbed=new EmbedBuilder().setColor(0x5865f2).setTitle('♟️ Chess invitation').setDescription(`${message.author.tag} invited you to play Nexus Chess in **${message.guild.name}**.\nJoin the server and accept to play as Black in <#${channelId}>.`);
    const dmRow=new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`nch_invite_join:${inviteId}`).setLabel('Join').setStyle(ButtonStyle.Success),new ButtonBuilder().setCustomId(`nch_invite_decline:${inviteId}`).setLabel('Decline').setStyle(ButtonStyle.Secondary));
    try { await user.send({embeds:[dmEmbed],components:[dmRow]}); }
    catch { invites.delete(inviteId); return message.reply('I could not DM that player. Ask them to enable server-member DMs and try again.'); }
    const cancelRow=new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`nch_invite_cancel:${inviteId}`).setLabel('Cancel invitation').setStyle(ButtonStyle.Danger));
    await message.channel.send({content:`${message.author}, invitation sent to ${user}.`,components:[cancelRow],allowedMentions:{users:[user.id]}});
    return;
  }
  if(!s) return message.reply('No active chess match here. Start one with `!chess start [password]`.');
  if(sub==='board'||sub==='status') return refresh(s,message.channel);
  if(sub==='moves') {
    if(![s.whiteId,s.blackId].includes(message.author.id)) return message.reply('Only match players can request legal moves.');
    const moves=s.game.moves({verbose:true}).map(m=>`${m.from}${m.to}${m.promotion||''} (${m.san})`);
    return message.reply(moves.length?`**Legal moves:** ${moves.join(', ')}`:'No legal moves.');
  }
  if(sub==='stop') {
    if(message.author.id!==s.whiteId&&!message.member.permissions.has('ManageGuild')) return message.reply('Only the match creator or a server manager can stop this match.');
    games.delete(channelId); return message.channel.send('Chess match stopped.');
  }
  if(sub==='resign') {
    if(![s.whiteId,s.blackId].includes(message.author.id)) return message.reply('Only a player in this match can resign.');
    games.delete(channelId); return message.channel.send(`🏳️ ${message.author} resigned. ${message.author.id===s.whiteId?'Black':'White'} wins!`);
  }
  if(s.game.isGameOver()) return message.reply('This match is over. Start another with `!chess start`.');
  if(!s.blackId) return message.reply('Waiting for an opponent to join.');
  const expected=s.game.turn()==='w'?s.whiteId:s.blackId;
  if(message.author.id!==expected) return message.reply(`It is ${s.game.turn()==='w'?'White':'Black'}'s turn.`);
  const raw=args.join(' ').trim(); if(!raw) return message.reply('Use the touchscreen menus or enter a move like `!chess e2e4`.');
  let move; try { const u=raw.match(/^([a-h][1-8])([a-h][1-8])([qrbn])?$/i); move=u?s.game.move({from:u[1].toLowerCase(),to:u[2].toLowerCase(),promotion:(u[3]||'q').toLowerCase()}):s.game.move(raw); } catch { move=null; }
  if(!move) return message.reply('Illegal move. Select a legal move from the touchscreen menus or use `!chess moves`.');
  s.selectedSquare=null; return refresh(s,message.channel,`${message.author} played **${move.san}**.`);
}
async function handleInteraction(interaction) {
  const id=interaction.customId||'';
  if(interaction.isModalSubmit?.() && id.startsWith('nch_invite_password:')) {
    const inviteId=id.split(':')[1], invite=invites.get(inviteId);
    if(!invite||interaction.user.id!==invite.toId) return interaction.reply({content:'This invitation has expired or was sent to another player.',ephemeral:true});
    const s=games.get(invite.channelId), password=interaction.fields.getTextInputValue('nch_password');
    if(!s||s.blackId||!s.passwordHash) { invites.delete(inviteId); return interaction.reply({content:'This match is no longer waiting for an opponent.',ephemeral:true}); }
    if(!verifyPassword(password,s.passwordHash)) return interaction.reply({content:'Incorrect password. You can try the invitation again.',ephemeral:true});
    const guild=interaction.client.guilds.cache.get(invite.guildId), channel=guild&&await guild.channels.fetch(invite.channelId).catch(()=>null);
    if(!channel) { invites.delete(inviteId); return interaction.reply({content:'The match channel is unavailable.',ephemeral:true}); }
    s.blackId=interaction.user.id; invites.delete(inviteId);
    await interaction.reply({content:'Password accepted. You joined the chess match as Black!',ephemeral:true});
    await refresh(s,channel,`${interaction.user} accepted the invitation and joined as Black.`);
    return true;
  }
  if(id.startsWith('nch_piece:')||id.startsWith('nch_dest:')) {
    const [kind,channelId]=id.split(':');
    const s=games.get(channelId);
    if(!s||interaction.channelId!==channelId) return interaction.reply({content:'This chess match is no longer active.',ephemeral:true});
    if(![s.whiteId,s.blackId].includes(interaction.user.id)) return interaction.reply({content:'Only the two players can move pieces.',ephemeral:true});
    if(!s.blackId||s.game.isGameOver()) return interaction.reply({content:'This match is not currently playable.',ephemeral:true});
    const expected=s.game.turn()==='w'?s.whiteId:s.blackId;
    if(interaction.user.id!==expected) return interaction.reply({content:`It is ${s.game.turn()==='w'?'White':'Black'}'s turn.`,ephemeral:true});
    if(kind==='nch_piece') {
      const square=interaction.values[0], piece=s.game.get(square);
      if(!piece||piece.color!==s.game.turn()) return interaction.reply({content:'Select one of your own pieces.',ephemeral:true});
      s.selectedSquare=square;
      return interaction.update({embeds:[embed(s,`Selected **${square.toUpperCase()}**. Now choose a destination.`)],components:components(channelId,s)});
    }
    const value=interaction.values[0], to=value.slice(0,2), promotion=value[2]||'q';
    let move; try { move=s.game.move({from:s.selectedSquare,to,promotion}); } catch { move=null; }
    if(!move) return interaction.reply({content:'That move is no longer legal. Select your piece again.',ephemeral:true});
    s.selectedSquare=null;
    return interaction.update({embeds:[embed(s,`${interaction.user} played **${move.san}**.`)],components:components(channelId,s)});
  }
  if(id.startsWith('nch_invite_')) {
    const [action,inviteId]=id.split(':'); const invite=invites.get(inviteId);
    if(!invite) return interaction.reply({content:'This invitation has expired or was cancelled.',ephemeral:true});
    if(action==='nch_invite_cancel') {
      if(interaction.user.id!==invite.fromId) return interaction.reply({content:'Only the inviter can cancel this invitation.',ephemeral:true});
      invites.delete(inviteId); return interaction.update({content:'Chess invitation cancelled.',components:[]});
    }
    if(interaction.user.id!==invite.toId) return interaction.reply({content:'This invitation was sent to another player.',ephemeral:true});
    if(action==='nch_invite_decline') { invites.delete(inviteId); return interaction.update({content:'You declined the chess invitation.',components:[]}); }
    if(action==='nch_invite_join') {
      const guild=interaction.client.guilds.cache.get(invite.guildId), channel=guild&&await guild.channels.fetch(invite.channelId).catch(()=>null), s=games.get(invite.channelId);
      if(!channel||!s||s.blackId||s.whiteId!==invite.fromId) { invites.delete(inviteId); return interaction.update({content:'This match is no longer waiting for an opponent.',components:[]}); }
      if(s.passwordHash) {
        const modal=new ModalBuilder().setCustomId(`nch_invite_password:${inviteId}`).setTitle('Enter chess password');
        const field=new TextInputBuilder().setCustomId('nch_password').setLabel('Match password').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100);
        modal.addComponents(new ActionRowBuilder().addComponents(field));
        return interaction.showModal(modal);
      }
      s.blackId=interaction.user.id; invites.delete(inviteId);
      await interaction.update({content:'You joined the chess match! Return to the server match channel to play.',components:[]});
      await refresh(s,channel,`${interaction.user} accepted the invitation and joined as Black.`);
      return;
    }
  }
  return false;
}
module.exports={handleCommand,handleInteraction};
