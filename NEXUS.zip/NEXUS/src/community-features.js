const fs = require('node:fs');
const path = require('node:path');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus, VoiceConnectionStatus, entersState, getVoiceConnection } = require('@discordjs/voice');
const DATA = path.join(__dirname, '..', 'data');
const FILE = path.join(DATA, 'community-features.json');
const SOUNDS = path.join(DATA, 'sounds');
const DEFAULT_WELCOME_SOUND = path.join(SOUNDS, 'welcome.mp3');
fs.mkdirSync(DATA,{recursive:true}); fs.mkdirSync(SOUNDS,{recursive:true});
function load(){try{return JSON.parse(fs.readFileSync(FILE,'utf8'))}catch{return {guilds:{},invites:{},giveaways:{},soundboards:{}}}}
let store=load(); function save(){fs.writeFileSync(FILE,JSON.stringify(store,null,2),'utf8')}
function gc(id){return store.guilds[id] ||= {counting:{channelId:null,count:0,lastUserId:null,best:0},guess:{},coinflips:0}}
function embed(title,description,color=0x7657e8){return new EmbedBuilder().setColor(color).setTitle(title).setDescription(description).setTimestamp().setFooter({text:'NEXUS • Community'});}
function admin(m){return m.member?.permissions?.has(PermissionFlagsBits.ManageGuild)||m.member?.permissions?.has(PermissionFlagsBits.Administrator)}
function safeName(s){return String(s||'').toLowerCase().replace(/[^a-z0-9_-]/g,'').slice(0,32)}

// Soundboard entries share the same per-guild playback queue as music.
const SUSPENSE_FILE = path.join(SOUNDS, 'suspens.mp3');
const KIRA_LAUGH_FILE = path.join(SOUNDS, 'kira-laugh.mp3');
async function enqueueSound(message, file, name) {
  const music = require('./music');
  return music.enqueueSound(message, file, name);
}
async function playSuspense(message) { return enqueueSound(message, SUSPENSE_FILE, 'sus'); }
async function playLaugh(message) { return enqueueSound(message, KIRA_LAUGH_FILE, 'laugh'); }
async function stopSuspense(message) {
  if (!message.guild) return false;
  const music = require('./music');
  return music.handleCommand(message, ['stop']);
}

const inviteCache=new Map();
async function cacheInvites(guild){try{const invites=await guild.invites.fetch(); inviteCache.set(guild.id,new Map(invites.map(i=>[i.code,i.uses||0])))}catch{inviteCache.set(guild.id,new Map())}}
async function onJoin(member){const g=member.guild;let used=null;try{const current=await g.invites.fetch();const old=inviteCache.get(g.id)||new Map();used=current.find(i=>(i.uses||0)>(old.get(i.code)||0))||null;inviteCache.set(g.id,new Map(current.map(i=>[i.code,i.uses||0])))}catch{}
 const rec=store.invites[member.guild.id] ||= {users:{},joins:{}};rec.joins[member.id]={inviterId:used?.inviter?.id||null,code:used?.code||null,at:Date.now(),left:false,bot:member.user.bot};if(used?.inviter){const u=rec.users[used.inviter.id] ||= {joins:0,left:0};u.joins++;}save();return rec.joins[member.id];}
async function onLeave(member){const rec=store.invites[member.guild.id];const j=rec?.joins?.[member.id];if(j&&!j.left){j.left=true;if(j.inviterId){const u=rec.users[j.inviterId] ||= {joins:0,left:0};u.left++;}save();}}
async function handleCommand(m,args){const name=(args.shift()||'').toLowerCase(), g=m.guild;if(!g)return m.reply({embeds:[embed('Server only','Use this feature inside a server.',0xe74c3c)]});
 if(name==='suspens'||name==='sus') return playSuspense(m);
 if(name==='laugh') return playLaugh(m);
 if(name==='counting'||name==='count'){const cfg=gc(g.id).counting,sub=(args.shift()||'status').toLowerCase();if(sub==='setup'){if(!admin(m))return m.reply({embeds:[embed('Permission required','Manage Server is required.',0xe74c3c)]});const ch=m.mentions.channels.first();if(!ch?.isTextBased())return m.reply({embeds:[embed('Usage','`!counting setup #channel`') ]});cfg.channelId=ch.id;cfg.count=0;cfg.lastUserId=null;save();return m.reply({embeds:[embed('Counting enabled',`Count channel: ${ch}\nStart by sending **1**. No skipping, and one person cannot count twice in a row.`)]})}if(sub==='reset'){if(!admin(m))return m.reply({embeds:[embed('Permission required','Manage Server is required.',0xe74c3c)]});cfg.count=0;cfg.lastUserId=null;save();return m.reply({embeds:[embed('Count reset','The next valid number is **1**.')]})}if(sub==='status'||sub==='stats')return m.reply({embeds:[embed('Counting stats',`Channel: ${cfg.channelId?`<#${cfg.channelId}>`:'Not configured'}\nCurrent count: **${cfg.count}**\nPersonal best: **${cfg.best}**\n\nSetup: \`!counting setup #channel\``)]});return m.reply({embeds:[embed('Counting help','`!counting setup #channel` — configure\n`!counting stats` — current count\n`!counting reset` — reset (staff only)')]})}
 if(name==='guess'||name==='guessnumber'){
   const cfg=gc(g.id).guess;
   const sub=(args[0]||'').toLowerCase();
   if(sub==='setup'){
     if(!admin(m)) return m.reply({embeds:[embed('Permission required','Manage Server is required to configure the guessing channel.',0xe74c3c)]});
     const ch=m.mentions.channels.first();
     if(!ch?.isTextBased()) return m.reply({embeds:[embed('Guessing channel setup','Use `!guess setup #channel` to choose where members can guess.')]});
     cfg.channelId=ch.id; cfg.number=null; cfg.active=false; cfg.wins=0; cfg.guesses=0; save();
     return m.reply({embeds:[embed('🎯 Guessing channel configured',`Members will guess by sending a number directly in ${ch}.\n\nNext: run \`!guess start\` once in this server. Nexus will then keep choosing a new number after each correct guess.`)]});
   }
   if(sub==='stop'){
     if(!admin(m)) return m.reply({embeds:[embed('Permission required','Manage Server is required.',0xe74c3c)]});
     cfg.active=false; cfg.number=null; save();
     return m.reply({embeds:[embed('Guessing paused','The number guessing game is paused. Staff can resume it with `!guess start`.')]});
   }
   if(sub==='start'){
     // Start/restart the game in the channel where the command was run, avoiding stale channel IDs.
     cfg.channelId=m.channel.id;
     cfg.number=1+Math.floor(Math.random()*100000); cfg.active=true; cfg.startedBy=m.author.id; cfg.wins=cfg.wins||0; cfg.guesses=cfg.guesses||0; save();
     return m.reply({embeds:[embed('🎯 Number Guessing is Live!',`Nexus has chosen a secret number from **1 to 100,000**.\n\nSend your guesses in this channel as normal messages—no command needed. I’ll automatically pick a new number after every correct guess.`,0x16a34a)]});
   }
   if(sub==='stats'){
     return m.reply({embeds:[embed('🎯 Guessing stats',`Channel: ${cfg.channelId?`<#${cfg.channelId}>`:'Not configured'}\nStatus: ${cfg.active?'Live':'Not started / paused'}\nCorrect guesses: **${cfg.wins||0}**\nTotal guesses: **${cfg.guesses||0}**`)]});
   }
   return m.reply({embeds:[embed('🎯 Guess the Number',`\`!guess setup #channel\` — choose a guessing channel (staff)\n\`!guess start\` — start/restart the game\n\`!guess stats\` — view stats\n\`!guess stop\` — pause (staff)\n\nOnce started, members just send numbers from **1–100,000** in the configured channel. Nexus automatically starts a fresh round after each correct guess.`)]});
 }
 if(name==='coinflip'||name==='flip'){const side=Math.random()<.5?'HEADS':'TAILS';const msg=await m.reply({embeds:[embed('🪙 Nexus Coin Toss','The coin is spinning…',0xf1c40f)]});const frames=['🪙  ◓','🪙  ◑','🪙  ◒','🪙  ◐'];for(const f of frames){await new Promise(r=>setTimeout(r,350));await msg.edit({embeds:[embed('🪙 Nexus Coin Toss',`${f}\nFlipping…`,0xf1c40f)]}).catch(()=>{})}return msg.edit({embeds:[embed(`🪙 ${side}`,`${m.author} flipped **${side.toLowerCase()}**!`,0x2ecc71)]})}
 if(name==='giveaway'||name==='gstart'){if(!admin(m))return m.reply({embeds:[embed('Permission required','Manage Server is required to start giveaways.',0xe74c3c)]});const duration=args[0], winners=Math.max(1,Math.min(20,Number(args[1])||1)), prize=args.slice(2).join(' ');const ms=parseDuration(duration);if(!ms||ms<10000||ms>30*86400000||!prize)return m.reply({embeds:[embed('Giveaway usage','`!giveaway <10m|2h|1d> <winners> <prize>`\nExample: `!giveaway 2h 2 Nitro`')]});const id=`${g.id}-${Date.now()}`;const ends=Date.now()+ms;const row=new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`nexus_giveaway_join:${id}`).setLabel('Enter giveaway').setEmoji('🎉').setStyle(ButtonStyle.Success));const e=embed('🎉 NEXUS GIVEAWAY',`**Prize:** ${prize}\n**Winners:** ${winners}\n**Ends:** <t:${Math.floor(ends/1000)}:R>\n\nClick **Enter giveaway** to join!`,0xe91e63);const sent=await m.channel.send({embeds:[e],components:[row]});store.giveaways[id]={guildId:g.id,channelId:m.channel.id,messageId:sent.id,hostId:m.author.id,prize,winners,ends,entries:[],ended:false};save();setTimeout(()=>endGiveaway(m.client,id).catch(()=>{}),ms);return m.reply({embeds:[embed('Giveaway created',`Your giveaway for **${prize}** is live in ${m.channel}.`)]})}
 if(name==='invites'||name==='invite'){const sub=(args[0]||'').toLowerCase();if(sub==='setup'){if(!admin(m))return m.reply({embeds:[embed('Permission required','Manage Server is required.',0xe74c3c)]});await cacheInvites(g);return m.reply({embeds:[embed('Invite tracking ready','Invite snapshots are enabled. Nexus needs the **Manage Server** permission to identify invite codes. Attribution may be unknown when several joins happen at once or vanity invites are used.')]})}const rec=store.invites[g.id]||{users:{},joins:{}};if(sub==='leaderboard'||sub==='lb'){const rows=Object.entries(rec.users).sort((a,b)=>(b[1].joins-b[1].left)-(a[1].joins-a[1].left)).slice(0,10);return m.reply({embeds:[embed('🏆 Invite leaderboard',rows.length?rows.map(([id,x],i)=>`**${i+1}.** <@${id}> — **${x.joins-x.left}** active · ${x.joins} joined · ${x.left} left`).join('\n'):'No tracked invites yet.')]})}const target=m.mentions.users.first()||m.author;const x=rec.users[target.id]||{joins:0,left:0};const join=Object.entries(rec.joins).find(([,j])=>j.inviterId===target.id);return m.reply({embeds:[embed('📨 Invite stats',`${target}\nTotal joins: **${x.joins}**\nLeft: **${x.left}**\nActive: **${x.joins-x.left}**\n\nUse \`!invites setup\` once as staff, then invite tracking runs automatically.`)]})}
 if (name === 'soundboard' || name === 'sound') {
   const sub = (args.shift() || 'list').toLowerCase();
   const board = store.soundboards[g.id] ||= {};
   if (sub === 'add') {
     if (!admin(m)) return m.reply({ embeds: [embed('Permission required', 'Manage Server is required.', 0xe74c3c)] });
     const attachment = m.attachments.first(); const key = safeName(args[0]);
     if (!key || !attachment || !/\.(mp3|ogg|wav|m4a|webm)$/i.test(attachment.name)) return m.reply({ embeds: [embed('Add a sound', 'Attach an MP3, OGG, WAV, M4A or WEBM file and use `!soundboard add <name>`.')] });
     if (attachment.size > 8 * 1024 * 1024) return m.reply({ embeds: [embed('File too large', 'Sound files must be 8 MB or smaller.', 0xe74c3c)] });
     const file = path.join(SOUNDS, `${g.id}-${key}${path.extname(attachment.name).toLowerCase()}`);
     const response = await fetch(attachment.url); if (!response.ok) throw Error('Could not download attachment');
     fs.writeFileSync(file, Buffer.from(await response.arrayBuffer())); board[key] = file; save();
     return m.reply({ embeds: [embed('Sound added', `Saved **${key}**. Play it with \`!soundboard play ${key}\`.`)] });
   }
   if (sub === 'play') {
     const key = safeName(args[0]); const file = board[key] || (key === 'welcome' && fs.existsSync(DEFAULT_WELCOME_SOUND) ? DEFAULT_WELCOME_SOUND : null);
     if (!file || !fs.existsSync(file)) return;
     return enqueueSound(m, file, key);
   }
   if (sub === 'remove') {
     if (!admin(m)) return m.reply({ embeds: [embed('Permission required', 'Manage Server is required.', 0xe74c3c)] });
     const key = safeName(args[0]); if (key === 'welcome' && !board[key] && fs.existsSync(DEFAULT_WELCOME_SOUND)) return m.reply({ embeds: [embed('Built-in sound', 'The built-in **welcome** sound cannot be removed. You can still add your own server sound with a different name.', 0xe74c3c)] }); if (!board[key]) return m.reply({ embeds: [embed('Sound not found', 'No matching sound exists.', 0xe74c3c)] });
     try { fs.unlinkSync(board[key]); } catch {} delete board[key]; save();
     return m.reply({ embeds: [embed('Sound removed', `Removed **${key}**.`)] });
   }
   const names = [...new Set([...Object.keys(board), ...(fs.existsSync(DEFAULT_WELCOME_SOUND) ? ['welcome'] : [])])];
   return m.reply({ embeds: [embed('Nexus Soundboard', `${names.length ? names.map(x => `\`${x}\``).join(', ') : 'No sounds saved yet.'}\n\nAttach audio with \`!soundboard add <name>\`. Play with \`!soundboard play <name>\`. Remove custom sounds with \`!soundboard remove <name>\`.\nBuilt-in sound: \`welcome\`.`)] });
 }
 return false;}
function handleGuessMessage(m){
 if(!m.guild||m.author.bot) return false;
 const cfg=gc(m.guild.id).guess;
 if(!cfg.active||!cfg.channelId||m.channel.id!==cfg.channelId) return false;
 const text=String(m.content||'').trim();
 if(!/^\\d{1,6}$/.test(text)) return false;
 const n=Number(text);
 if(!Number.isInteger(n)||n<1||n>100000) return false;
 if(!Number.isInteger(cfg.number)||cfg.number<1||cfg.number>100000) cfg.number=1+Math.floor(Math.random()*100000);
 cfg.guesses=(cfg.guesses||0)+1;
 if(n===cfg.number){
   const answer=cfg.number; cfg.wins=(cfg.wins||0)+1;
   cfg.number=1+Math.floor(Math.random()*100000); save();
   m.channel.send({embeds:[embed('🎉 Correct guess!',`${m.author} guessed **${answer}** and won this round!\n\nA new secret number has already been selected from **1 to 100,000**. Keep guessing—no command needed.`,0x22c55e)],allowedMentions:{users:[m.author.id]}}).catch(error=>console.error(`[guessing:send-win] ${error.message}`));
 } else {
   // Give a simple directional hint after every valid wrong guess.
   const hint = n < cfg.number ? '⬆️ Too low! Try a higher number.' : '⬇️ Too high! Try a lower number.';
   m.channel.send({ embeds: [embed('🎯 Keep guessing!', `${m.author}, ${hint}`, 0x5865f2)], allowedMentions: { users: [m.author.id] } }).catch(error => console.error(`[guessing:send-hint] ${error.message}`));
   save();
 }
 return true;
}
function parseDuration(s){const m=String(s||'').match(/^(\d+)(s|m|h|d)$/i);if(!m)return 0;return Number(m[1])*({s:1000,m:60000,h:3600000,d:86400000}[m[2].toLowerCase()])}
async function endGiveaway(client,id){const x=store.giveaways[id];if(!x||x.ended)return;const g=client.guilds.cache.get(x.guildId);const ch=g?.channels.cache.get(x.channelId);if(!ch)return;x.ended=true;const pool=[...new Set(x.entries)];const winners=[];while(pool.length&&winners.length<x.winners){winners.push(pool.splice(Math.floor(Math.random()*pool.length),1)[0])}save();const msg=await ch.messages.fetch(x.messageId).catch(()=>null);if(msg)await msg.edit({embeds:[embed('🎉 GIVEAWAY ENDED',`**Prize:** ${x.prize}\n**Winner${winners.length===1?'':'s'}:** ${winners.length?winners.map(id=>`<@${id}>`).join(', '):'No valid entries'}\n**Entries:** ${x.entries.length}`,0x808080)],components:[]}).catch(()=>{});await ch.send({embeds:[embed('Giveaway results',winners.length?`Congratulations ${winners.map(id=>`<@${id}>`).join(', ')}! You won **${x.prize}**.`:`The giveaway for **${x.prize}** ended with no entries.`)],allowedMentions:{users:winners}}).catch(()=>{})}
async function handleInteraction(i){if(!i.isButton()||!i.customId.startsWith('nexus_giveaway_join:'))return false;const id=i.customId.split(':')[1],x=store.giveaways[id];if(!x||x.ended)return i.reply({content:'This giveaway has ended.',ephemeral:true}),true;if(x.entries.includes(i.user.id))return i.reply({content:'You are already entered!',ephemeral:true}),true;x.entries.push(i.user.id);save();return i.reply({content:'🎉 You are entered in the giveaway!',ephemeral:true}),true}
function handleCountMessage(m){const cfg=gc(m.guild.id).counting;if(!cfg.channelId||m.channel.id!==cfg.channelId||m.author.bot||/^[!.?]/.test(m.content.trim()))return false;const n=Number(m.content.trim());if(!Number.isSafeInteger(n))return true;if(n===cfg.count+1&&m.author.id!==cfg.lastUserId){cfg.count=n;cfg.lastUserId=m.author.id;cfg.best=Math.max(cfg.best,n);save();m.react('✅').catch(()=>{});if(n%100===0)m.channel.send({embeds:[embed('🎯 Counting milestone',`The server reached **${n}**! Keep it going.`)]}).catch(()=>{});}else{m.delete().catch(()=>{});m.channel.send({embeds:[embed('❌ Count broken',`Expected **${cfg.count+1}** and a different member. The count has reset to **0**.`,0xe74c3c)]}).then(msg=>setTimeout(()=>msg.delete().catch(()=>{}),8000)).catch(()=>{});cfg.count=0;cfg.lastUserId=null;save();}return true}
module.exports={handleCommand,handleInteraction,onJoin,onLeave,cacheInvites,handleCountMessage,handleGuessMessage,stopSuspense};
