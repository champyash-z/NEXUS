require('dotenv').config();

const fs = require('node:fs');
const path = require('node:path');
const { Client, GatewayIntentBits, Events, Partials, EmbedBuilder, ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const { PREFIXES, runPrefixCommand } = require('./prefix-commands');
const { handleAutomatic: handleAiAutomatic, getConfig: getAiConfig, updateConfig: updateAiConfig, buildSetupComponents: buildAiSetupComponents, runConnectionTest: runAiConnectionTest, setupEmbed: buildAiSetupEmbed } = require('./ai/system');
const { getGuildConfig, updateSetupState, resetGuildSetup } = require('./utils/config');
const { PRESETS, MODULES, buildSetupEmbed, buildSetupWizard, applySetupSelection } = require('./commands/setup');
const { handleAutomod } = require('./utils/automod');
const { handleAuditLogEntry, handleMemberJoin, handleMessageRaid, restoreExpiredLockdowns } = require('./security/protection');
const { logModEvent } = require('./utils/modlog');
const { awardXp, getLevelConfig, getGuildLeaderBoard, readLevels, writeLevels } = require('./utils/leveling');
const { handleMemberJoin: handleOnboardingJoin, handleMemberLeave: handleOnboardingLeave, handleVerifyButton } = require('./utils/onboarding');
const { getDueReminders, markSent, resolveReminderUser } = require('./utils/reminders');
const { createTicketChannel, closeTicketAndTranscript, getTicketRecord, saveTicketRating, addEvent, recordTicketActivity, db } = require('./utils/tickets');
const { getSingleTriggerReply } = require('./utils/triggerReplies');
const { handleSafetyMessage, processExpiry: processAiModExpiry } = require('./utils/aiSafety');
const nativePolls = require('./polls/native');

const processedMessages = new Map();
const MAX_PROCESSED_MESSAGES = 5000;

function buildPrefixReplyEmbed(content) {
  const text = String(content || '').slice(0, 4000);
  const isWarning = /\bwarn(?:ing)?\b|⚠️/i.test(text);
  const isError = /\b(error|failed|cannot|can't|could not|permission required|not allowed)\b|❌/i.test(text);
  const isSuccess = /\b(success|configured|enabled|disabled|saved|completed|posted|sent|removed|cleared|kicked|banned|timed out|warned)\b|✅/i.test(text);
  const color = isWarning ? 0xfacc15 : isError ? 0xef4444 : isSuccess ? 0x22c55e : 0x7c3aed;
  const title = isWarning ? '⚠️ Nexus Notice' : isError ? 'Nexus • Action Required' : isSuccess ? 'Nexus • Success' : 'Nexus • Information';
  return new EmbedBuilder().setColor(color).setTitle(title).setDescription(text || 'No details provided.').setTimestamp(new Date()).setFooter({ text: 'NEXUS • Prefix commands' });
}

function stylePrefixReplies(message, commandName) {
  if (commandName === 'ai') return () => {};
  const originalReply = message.reply.bind(message);
  message.reply = (...args) => {
    let payload = args[0];
    if (typeof payload === 'string') {
      payload = { embeds: [buildPrefixReplyEmbed(payload)] };
    } else if (payload && typeof payload === 'object' && typeof payload.content === 'string' && !payload.embeds?.length && !payload.components?.length && !payload.files?.length && !payload.poll && !payload.stickers?.length) {
      const { content, ...options } = payload;
      payload = { ...options, embeds: [buildPrefixReplyEmbed(content)] };
    }
    return originalReply(payload, ...args.slice(1));
  };
  return () => { message.reply = originalReply; };
}

async function handleXpLevelUp(guild, member, xpResult, fallbackChannel = null) {
  if (!xpResult || xpResult.ignored || !xpResult.leveledUp || !member) return;
  const cfg = getLevelConfig(guild.id);
  const rawReward = cfg.rewards?.[String(xpResult.level)];
  const rewardIds = Array.isArray(rawReward) ? rawReward : rawReward ? [rawReward] : [];
  for (const roleId of rewardIds) {
    const role = guild.roles.cache.get(roleId) || await guild.roles.fetch(roleId).catch(() => null);
    if (role && member.manageable && guild.members.me?.permissions.has('ManageRoles') && role.position < guild.members.me.roles.highest.position) await member.roles.add(role, `Nexus level reward for level ${xpResult.level}`).catch(() => {});
  }
  const config = getGuildConfig(guild.id);
  const channelId = config.channels?.levelup;
  const targetChannel = (channelId ? guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId).catch(() => null) : null) || fallbackChannel;
  if (cfg.levelUpMessages && targetChannel?.isTextBased()) {
    const embed = new EmbedBuilder().setColor(0x8b5cf6).setTitle('✨ Level Up!').setDescription(`<@${member.id}> reached level **${xpResult.level}**! They now have **${xpResult.xp} XP**.`).setTimestamp(new Date());
    await targetChannel.send({ embeds: [embed], allowedMentions: { users: [member.id] } }).catch(() => {});
  }
}
const MESSAGE_DEDUPE_TTL_MS = 5 * 60 * 1000;
const voiceSessionStarts = new Map();
const firstPlaceSyncAt = new Map();
function markMessageProcessed(messageId) {
  const now = Date.now();
  for (const [id, at] of processedMessages) {
    if (now - at > MESSAGE_DEDUPE_TTL_MS) processedMessages.delete(id);
    else break;
  }
  if (processedMessages.has(messageId)) return false;
  processedMessages.set(messageId, now);
  while (processedMessages.size > MAX_PROCESSED_MESSAGES) processedMessages.delete(processedMessages.keys().next().value);
  return true;
}

const token = process.env.DISCORD_BOT_TOKEN || process.env.DISCORD_TOKEN;
if (!token || token === 'put_your_bot_token_here' || token === 'paste_your_bot_token_here' || token === 'YOUR_BOT_TOKEN_HERE') {
  console.error('Missing bot token. Please set DISCORD_BOT_TOKEN in your local .env file.');
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildVoiceStates,
  ],
  partials: [Partials.Channel, Partials.Message, Partials.Reaction, Partials.User],
});

client.prefixes = PREFIXES;
client.mutedChannels = new Set();
const nexusMusic = require('./music');
nexusMusic.initialize(client);


client.once(Events.ClientReady, readyClient => {
  console.log(`Nexus is online as ${readyClient.user.tag}`);
  console.log('Slash command execution is disabled.');
  console.log(`Prefix commands enabled: ${PREFIXES.join(' ')}`);
  for (const guild of readyClient.guilds.cache.values()) require('./community-features').cacheInvites(guild).catch(() => {});

  setInterval(async () => {
    await processAiModExpiry(readyClient).catch(error => console.error(`[ai-mod] Expiry sweep failed: ${error.message}`));
    await restoreExpiredLockdowns(readyClient).catch(error => console.error(`[security] Lockdown expiry sweep failed: ${error.message}`));
    // Discord-native inactivity automation; disabled unless configured with !ticket autoclose.
    try {
      const openTickets = db.prepare("SELECT * FROM tickets WHERE status IN ('open','claimed')").all();
      for (const ticket of openTickets) {
        const cfg = getGuildConfig(ticket.guild_id);
        const hours = Number(cfg.ticketAutoCloseHours || 0);
        if (!Number.isFinite(hours) || hours <= 0) continue;
        const guild = readyClient.guilds.cache.get(ticket.guild_id);
        if (!guild) continue;
        const channel = guild.channels.cache.get(ticket.channel_id) || await guild.channels.fetch(ticket.channel_id).catch(() => null);
        if (!channel?.isTextBased()) continue;
        const lastActivity = ticket.last_activity_at || ticket.created_at;
        const inactiveFor = Date.now() - lastActivity;
        if (inactiveFor < hours * 3600000) continue;
        if (!ticket.auto_close_warned_at) {
          db.prepare('UPDATE tickets SET auto_close_warned_at=? WHERE channel_id=? AND auto_close_warned_at IS NULL').run(Date.now(), ticket.channel_id);
          await channel.send(`⏳ This ticket has been inactive for ${hours} hours. It will be automatically closed in 24 hours unless someone replies.`).catch(() => {});
          continue;
        }
        if (Date.now() - ticket.auto_close_warned_at < 24 * 3600000) continue;
        await closeTicketAndTranscript(readyClient, channel, readyClient.user, `Automatically closed after ${hours} hours of inactivity`).catch(error => console.error('[Tickets] Auto-close failed:', error.message));
      }
    } catch (error) { console.error('[Tickets] Inactivity automation error:', error.message); }

    const reminders = getDueReminders();
    for (const reminder of reminders) {
      const user = await resolveReminderUser(client, reminder.userId);
      if (user) {
        await user.send(`⏰ Reminder: ${reminder.message}`).catch(() => {});
      }
      markSent(reminder.id);
    }
    // Voice XP and time are tracked in short intervals; only active, non-muted members count.
    const activeVoiceKeys = new Set();
    for (const guild of readyClient.guilds.cache.values()) {
      const cfg = getLevelConfig(guild.id);
      if (!cfg.enabled) continue;
      for (const channel of guild.channels.cache.values()) {
        if (!channel.isVoiceBased?.() || !channel.members) continue;
        const activeMembers = [...channel.members.values()].filter(member => !member.user.bot && !member.voice?.selfMute && !member.voice?.selfDeaf && !member.voice?.serverMute && !member.voice?.serverDeaf);
        if (activeMembers.length < Math.max(2, Number(cfg.voiceMinMembers) || 2)) continue;
        for (const member of activeMembers) {
          const key = `${guild.id}:${member.id}`; activeVoiceKeys.add(key);
          if (!voiceSessionStarts.has(key)) voiceSessionStarts.set(key, Date.now());
          const antiAfkHours = Math.max(0, Number(cfg.antiAfkHours) || 0);
          const noXp = antiAfkHours > 0 && Date.now() - voiceSessionStarts.get(key) >= antiAfkHours * 3600000;
          const result = awardXp(guild.id, member.id, null, Date.now(), { source: 'voice', voiceSeconds: 10, noXp, channelId: channel.id, roleIds: member.roles.cache.map(role => role.id) });
          await handleXpLevelUp(guild, member, result, null);
        }
      }
    }
    for (const key of voiceSessionStarts.keys()) if (!activeVoiceKeys.has(key)) voiceSessionStarts.delete(key);
    for (const guild of readyClient.guilds.cache.values()) {
      const cfg = getLevelConfig(guild.id); if (!cfg.enabled || !cfg.firstPlaceRoleId) continue;
      if (Date.now() - (firstPlaceSyncAt.get(guild.id) || 0) < 10 * 60 * 1000) continue;
      firstPlaceSyncAt.set(guild.id, Date.now());
      const role = guild.roles.cache.get(cfg.firstPlaceRoleId) || await guild.roles.fetch(cfg.firstPlaceRoleId).catch(() => null);
      if (!role || !guild.members.me?.permissions.has('ManageRoles') || role.position >= guild.members.me.roles.highest.position) continue;
      const top = getGuildLeaderBoard(guild.id, 1, 'xp')[0];
      const topMember = top ? await guild.members.fetch(top.userId).catch(() => null) : null;
      for (const holder of role.members.values()) if (!topMember || holder.id !== topMember.id) await holder.roles.remove(role, 'Nexus first-place role rotation').catch(() => {});
      if (topMember && !topMember.roles.cache.has(role.id)) await topMember.roles.add(role, 'Nexus first-place role rotation').catch(() => {});
    }
  }, 10000);
});

if (client.listenerCount(Events.MessageCreate) !== 0) {
  throw new Error('Unexpected messageCreate listener before central message router registration.');
}
client.on(Events.MessageCreate, async message => {
  if (!message.guild || message.author.bot || message.webhookId) return;
  if (!markMessageProcessed(message.id)) return;
  // Route active number guesses first so the counting mini-game cannot consume
  // numeric guesses when both games are configured in the same channel.
  try { if (require('./community-features').handleGuessMessage(message)) return; } catch (error) { console.error(`[guessing] ${error.stack || error.message}`); }
  // Counting is a channel-specific mini-game; handle it after the guessing game.
  try { if (require('./community-features').handleCountMessage(message)) return; } catch (error) { console.error(`[counting] ${error.stack || error.message}`); }
  // Any user or staff reply resets the inactivity timer for an active ticket.
  recordTicketActivity(message.channel.id, message.author.id);

  // AI Safety watches ordinary chat before any automation. Its own setup command is exempt.
  if (!/^[!.?]ai\s+(?:safety|mod)(?:\s|$)/i.test(message.content.trim())) {
    try { if (await handleSafetyMessage(message, client)) return; }
    catch (error) { console.error(`[ai-safety] ${error.message}`); }
  }

  try { if (await handleMessageRaid(message)) return; } catch (error) { console.error(`[security:anti-raid] ${error.message}`); }

  // Prefix commands always take priority over keyword automation.
  const prefix = PREFIXES.find(p => message.content.startsWith(p));
  if (prefix) {
    const body = message.content.slice(prefix.length).trim();
    if (!body) return;
    const parts = body.match(/"[^"]*"|'[^']*'|\S+/g) || [];
    const commandName = (parts.shift() || '').toLowerCase();
    const args = parts.map(part => part.replace(/^("|')|(?:"|')$/g, ''));
    const knownCommands = new Set(['weather','counting','count','guess','guessnumber','coinflip','flip','giveaway','gstart','invites','invite','soundboard','sound','suspens','sus','laugh','help', 'ping', 'p', 'config', 'serverinfo', 'userinfo', 'purge', 'kick', 'ban', 'timeout', 'warn', 'warnings', 'clearwarnings', 'mute', 'unmute', 'rank', 'leaderboard', 'levels', 'xp', 'ticket', 'suggest', 'remind', 'setup', 'rolepanel', 'security', 'welcome', 'ai', 'dm', 'msg', 'chess', 'music', 'play', 'search', 'pause', 'resume', 'skip', 'stop', 'join', 'leave', 'previous', 'nowplaying', 'np', 'seek', 'forward', 'rewind', 'volume', 'queue', 'q', 'shuffle', 'clear', 'remove', 'move', 'playnext', 'loop', 'autoplay', 'playrecent', 'selectrandom', 'filter', 'playlist']);
    if (knownCommands.has(commandName)) {
      const restoreReply = stylePrefixReplies(message, commandName);
      try { await runPrefixCommand(message, commandName, args); }
      catch (error) {
        console.error(`[command:${prefix}${commandName}] ${error.stack || error.message}`);
        await message.reply('Something went wrong while running that command. Check the bot terminal for details.').catch(() => {});
      } finally {
        restoreReply();
      }
    }
    return;
  }

  // Muted channels ignore ordinary chat but still allow prefix commands such as !unmute.
  if (client.mutedChannels.has(message.channel.id)) return;


  // Public server address shortcut; exact standalone 'ip' only. No user ping or reply reference.
  if (/^ip[.!?]*$/i.test(message.content.trim())) {
    const ipEmbed = new EmbedBuilder().setColor(0x16a34a).setTitle('🎮 Rooi SMP • Server IP')
      .setDescription('Join the server and start playing!')
      .addFields({ name: 'IP / Address', value: '`play.rooi.site`', inline: true }, { name: 'Port', value: '`19132`', inline: true })
      .addFields({ name: 'Website', value: '[rooismp.vercel.app](https://rooismp.vercel.app)', inline: false })
      .setFooter({ text: 'Rooi SMP • See you in-game!' });
    await message.channel.send({ embeds: [ipEmbed], allowedMentions: { parse: [] } });
    return;
  }

  // AI responds to bot mentions and short greetings/compliments in eligible channels.
  // When AI handled the message, stop here so legacy hard-coded trigger replies do not duplicate it.
  try {
    const aiHandled = await handleAiAutomatic(message);
    if (aiHandled) return;
  } catch (error) {
    console.error(`[ai:auto] ${error.message}`);
  }

  const allowed = await handleAutomod(message, client);
  if (allowed) return;

  const triggerReply = getSingleTriggerReply(message.content, message);
  if (triggerReply) {
    for (const reply of triggerReply.sequence || []) {
      try { await message.channel.send(reply); }
      catch (error) { console.error(`[trigger:${triggerReply.type}] Send failed for message ${message.id}: ${error.message}`); }
    }
    return;
  }

  const xpConfig = getLevelConfig(message.guild.id);
  const xpResult = awardXp(message.guild.id, message.author.id, null, Date.now(), { source: 'message', messageContent: message.content, channelId: message.channel.id, roleIds: message.member?.roles?.cache?.map(role => role.id) || [] });
  await handleXpLevelUp(message.guild, message.member, xpResult, message.channel);
});


client.on(Events.MessageReactionAdd, async (reaction, user) => {
  try {
    if (user.bot) return;
    if (reaction.partial) await reaction.fetch();
    const message = reaction.message.partial ? await reaction.message.fetch() : reaction.message;
    if (!message.guild || !message.author || message.author.bot) return;
    const cfg = getLevelConfig(message.guild.id);
    if (!cfg.enabled || !cfg.reactionXpEnabled) return;
    const reactor = await message.guild.members.fetch(user.id).catch(() => null);
    if (cfg.reactionAwardReactors && reactor) {
      const result = awardXp(message.guild.id, user.id, null, Date.now(), { source: 'reaction', countReaction: true, channelId: message.channel.id, roleIds: reactor.roles.cache.map(role => role.id) });
      await handleXpLevelUp(message.guild, reactor, result, message.channel);
    }
    if (cfg.reactionAwardAuthor && message.author.id !== user.id) {
      const author = await message.guild.members.fetch(message.author.id).catch(() => null);
      if (author) {
        const result = awardXp(message.guild.id, author.id, null, Date.now(), { source: 'reaction', countReaction: true, channelId: message.channel.id, roleIds: author.roles.cache.map(role => role.id) });
        await handleXpLevelUp(message.guild, author, result, message.channel);
      }
    }
  } catch (error) { console.error(`[leveling:reaction] ${error.message}`); }
});

client.on(Events.MessageUpdate, async (oldMessage, newMessage) => {
  if (!newMessage.guild || newMessage.author.bot) return;
  await logModEvent(client, newMessage.guild.id, {
    title: 'Message Edited',
    description: `A message in <#${newMessage.channel.id}> was edited by ${newMessage.author.tag}.`,
    color: 0xf59e0b,
    fields: [
      { name: 'Author', value: `${newMessage.author.tag} (${newMessage.author.id})`, inline: true },
      { name: 'Before', value: String(oldMessage.content || 'No content').slice(0, 500), inline: false },
      { name: 'After', value: String(newMessage.content || 'No content').slice(0, 500), inline: false },
    ],
  });
});

client.on(Events.MessageDelete, async message => {
  if (!message.guild || message.author?.bot) return;
  await logModEvent(client, message.guild.id, {
    title: 'Message Deleted',
    description: `A message was deleted in <#${message.channel.id}>.`,
    color: 0xef4444,
    fields: [
      { name: 'Author', value: `${message.author.tag} (${message.author.id})`, inline: true },
      { name: 'Channel', value: `<#${message.channel.id}>`, inline: true },
      { name: 'Content', value: String(message.content || 'No content').slice(0, 500), inline: false },
    ],
  });
});

client.on(Events.GuildMemberRemove, async member => {
  await require('./community-features').onLeave(member).catch(error => console.error(`[invites:leave] ${error.message}`));
  await handleOnboardingLeave(member).catch(error => console.error(`[onboarding:leave] ${error.message}`));
});

client.on(Events.GuildAuditLogEntryCreate, async (auditLogEntry, guild) => {
  try { await handleAuditLogEntry(auditLogEntry, guild); } catch (error) { console.error(`[security:audit] ${error.message}`); }
});

client.on(Events.GuildMemberAdd, async member => {
  await require('./community-features').onJoin(member).catch(error => console.error(`[invites:join] ${error.message}`));
  await handleMemberJoin(member).catch(error => console.error(`[security:raid] ${error.message}`));
  await handleOnboardingJoin(member).catch(error => console.error(`[onboarding:join] ${error.message}`));
});

client.on(Events.InteractionCreate, async interaction => {
  try { if (await require('./chess').handleInteraction(interaction)) return; } catch (error) { console.error(`[chess:interaction] ${error.stack || error.message}`); if (!interaction.replied && !interaction.deferred) await interaction.reply({ content: 'Chess interaction failed. Please try again.', ephemeral: true }).catch(() => {}); }
  try { if (await nexusMusic.handleInteraction(interaction)) return; } catch (error) { console.error(`[music:interaction] ${error.message}`); }
  try { if (await require('./community-features').handleInteraction(interaction)) return; } catch (error) { console.error(`[community:interaction] ${error.message}`); }
  try { if (await handleVerifyButton(interaction)) return; } catch (error) { console.error(`[onboarding:verify] ${error.message}`); }
  if (interaction.isChatInputCommand()) {
    await interaction.reply({ content: 'Slash commands are disabled. Use `!help`, `.help`, or `?help` instead.', flags: 64 }).catch(() => {});
    return;
  }

  const aiAuthorized = Boolean(interaction.guild && (
    interaction.guild.ownerId === interaction.user.id ||
    interaction.memberPermissions?.has('Administrator') ||
    interaction.memberPermissions?.has('ManageGuild')
  ));
  if (interaction.isButton() && interaction.customId.startsWith('nexus_ai_')) {
    if (!aiAuthorized) return interaction.reply({ content: 'Administrator or Manage Server permission is required.', flags: 64 });
    const cfg = getAiConfig(interaction.guildId);
    if (interaction.customId === 'nexus_ai_toggle') {
      const updated = updateAiConfig(interaction.guildId, { enabled: Number(cfg.enabled) ? 0 : 1 });
      return interaction.update({ embeds: [buildAiSetupEmbed(updated)], components: buildAiSetupComponents(updated) });
    }
    if (interaction.customId === 'nexus_ai_memory') {
      const updated = updateAiConfig(interaction.guildId, { memory_enabled: Number(cfg.memory_enabled) ? 0 : 1 });
      return interaction.update({ embeds: [buildAiSetupEmbed(updated)], components: buildAiSetupComponents(updated) });
    }
    if (interaction.customId === 'nexus_ai_instructions') {
      const modal = new ModalBuilder().setCustomId('nexus_ai_instructions_modal').setTitle('Nexus AI Instructions');
      const field = new TextInputBuilder().setCustomId('nexus_ai_instructions_text').setLabel('System instructions').setStyle(TextInputStyle.Paragraph).setMinLength(5).setMaxLength(4000).setRequired(true).setValue(String(cfg.system_prompt || '').slice(0, 4000));
      modal.addComponents(new ActionRowBuilder().addComponents(field));
      return interaction.showModal(modal);
    }
    if (interaction.customId === 'nexus_ai_test') {
      await interaction.deferReply({ flags: 64 });
      try {
        const answer = await runAiConnectionTest(interaction.guildId, interaction.channelId, interaction.user.id);
        return interaction.editReply(`✅ API connection successful: ${answer}`);
      } catch (error) { return interaction.editReply(`❌ API test failed: ${error.message}`); }
    }
  }
  if (interaction.isStringSelectMenu() && interaction.customId === 'nexus_ai_model') {
    if (!aiAuthorized) return interaction.reply({ content: 'Administrator or Manage Server permission is required.', flags: 64 });
    const model = interaction.values?.[0];
    if (!['gemini-3.5-flash-lite','gemini-3.8-flash','gemini-flash-latest'].includes(model)) return interaction.reply({ content: 'Unsupported Gemini model selection.', flags: 64 });
    const updated = updateAiConfig(interaction.guildId, { model, provider: 'gemini', base_url: 'https://generativelanguage.googleapis.com/v1beta' });
    return interaction.update({ embeds: [buildAiSetupEmbed(updated)], components: buildAiSetupComponents(updated) });
  }
  if (interaction.isModalSubmit() && interaction.customId === 'nexus_ai_instructions_modal') {
    if (!aiAuthorized) return interaction.reply({ content: 'Administrator or Manage Server permission is required.', flags: 64 });
    const instructions = interaction.fields.getTextInputValue('nexus_ai_instructions_text').trim();
    if (instructions.length < 5 || instructions.length > 4000) return interaction.reply({ content: 'Instructions must be 5–4000 characters.', flags: 64 });
    const updated = updateAiConfig(interaction.guildId, { system_prompt: instructions });
    return interaction.reply({ content: '✅ Nexus AI system instructions updated.', embeds: [buildAiSetupEmbed(updated)], components: buildAiSetupComponents(updated), flags: 64 });
  }

  if (interaction.isStringSelectMenu() && interaction.customId === 'ticket_category_select') {
    const category = interaction.values?.[0] || 'Support';
    const categoryId = category.replace(/[^a-z0-9]/gi, '').toLowerCase() || 'support';
    const modal = new ModalBuilder().setCustomId(`ticket_modal_${categoryId}`).setTitle(`${category} Ticket`.slice(0, 45));
    const subjectInput = new TextInputBuilder().setCustomId('ticket_subject').setLabel('Subject').setStyle(TextInputStyle.Short).setMaxLength(100).setRequired(true);
    const descriptionInput = new TextInputBuilder().setCustomId('ticket_description').setLabel('Describe your issue').setStyle(TextInputStyle.Paragraph).setMaxLength(3500).setRequired(true);
    modal.addComponents(new ActionRowBuilder().addComponents(subjectInput), new ActionRowBuilder().addComponents(descriptionInput));
    await interaction.showModal(modal);
    return;
  }

  if (interaction.isButton()) {
    const customId = interaction.customId;

    if (customId.startsWith('xp_reset_server_confirm:')) {
      const [, guildId, actorId] = customId.split(':');
      if (!interaction.guild || interaction.guild.id !== guildId || interaction.user.id !== actorId) return interaction.reply({ content: 'Only the administrator who requested this reset can confirm it.', flags: 64 });
      const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
      if (!member?.permissions.has('ManageGuild') && !member?.permissions.has('Administrator') && interaction.guild.ownerId !== interaction.user.id) return interaction.reply({ content: 'You no longer have permission to reset leveling data.', flags: 64 });
      const all = readLevels(); delete all[guildId]; writeLevels(all);
      await interaction.update({ content: 'All leveling XP and activity records for this server have been reset.', components: [] });
      return;
    }
    if (customId === 'xp_reset_server_cancel') { await interaction.update({ content: 'Server XP reset cancelled. No data was changed.', components: [] }); return; }

    if (customId.startsWith('setup_')) {
      if (customId === 'setup_cancel') {
        updateSetupState(interaction.guildId, { active: false, step: 0, completed: false, startedBy: null });
        await interaction.update({ content: 'Setup cancelled. You can run `!setup start` again any time.', embeds: [], components: [] });
        return;
      }

      if (customId === 'setup_quick_start') {
        const preset = PRESETS.custom;
        updateSetupState(interaction.guildId, { active: true, step: 1, preset: 'custom', moduleList: preset.modules, modulePage: 0, completed: false, startedBy: interaction.user.id });
        const wizard = buildSetupWizard(interaction.guildId);
        await interaction.update({ embeds: [wizard.embed], components: wizard.components });
        return;
      }

      if (customId.startsWith('setup_preset_')) {
        const presetKey = customId.replace('setup_preset_', '');
        const preset = PRESETS[presetKey];
        if (!preset) return interaction.reply({ content: 'That preset is not available.', flags: 64 });
        updateSetupState(interaction.guildId, { active: true, step: 1, preset: presetKey, moduleList: preset.modules, modulePage: 0, completed: false, startedBy: interaction.user.id });
        const wizard = buildSetupWizard(interaction.guildId);
        await interaction.update({ embeds: [wizard.embed], components: wizard.components });
        return;
      }

      if (customId === 'setup_modpage_prev' || customId === 'setup_modpage_next') {
        const member = interaction.guild ? await interaction.guild.members.fetch(interaction.user.id).catch(() => null) : null;
        if (!member || (!member.permissions.has('ManageGuild') && !member.permissions.has('Administrator') && interaction.guild.ownerId !== interaction.user.id)) {
          await interaction.reply({ content: 'Only server managers can change the setup wizard.', flags: 64 });
          return;
        }
        const config = getGuildConfig(interaction.guildId);
        const pageCount = Math.max(1, Math.ceil(MODULES.length / 8));
        const currentPage = Math.max(0, Math.min(pageCount - 1, Number(config.onboarding?.modulePage || 0)));
        const nextPage = customId === 'setup_modpage_next' ? Math.min(pageCount - 1, currentPage + 1) : Math.max(0, currentPage - 1);
        updateSetupState(interaction.guildId, { step: 1, modulePage: nextPage, active: true });
        const wizard = buildSetupWizard(interaction.guildId);
        await interaction.update({ embeds: [wizard.embed], components: wizard.components });
        return;
      }

      if (customId === 'setup_next') {
        const config = getGuildConfig(interaction.guildId);
        const currentStep = Number(config.onboarding?.step || 0);
        const nextStep = Math.min(currentStep + 1, 1);
        updateSetupState(interaction.guildId, { step: nextStep });
        const wizard = buildSetupWizard(interaction.guildId);
        await interaction.update({ embeds: [wizard.embed], components: wizard.components });
        return;
      }

      if (customId === 'setup_back') {
        const config = getGuildConfig(interaction.guildId);
        const currentStep = Number(config.onboarding?.step || 1);
        const prevStep = Math.max(currentStep - 1, 0);
        updateSetupState(interaction.guildId, { step: prevStep });
        const wizard = buildSetupWizard(interaction.guildId);
        await interaction.update({ embeds: [wizard.embed], components: wizard.components });
        return;
      }

      if (customId.startsWith('setup_toggle_')) {
        const moduleKey = customId.replace('setup_toggle_', '');
        const config = getGuildConfig(interaction.guildId);
        const selected = Array.isArray(config.onboarding?.moduleList) ? [...config.onboarding.moduleList] : [...PRESETS.custom.modules];
        const index = selected.indexOf(moduleKey);
        if (index >= 0) {
          selected.splice(index, 1);
        } else {
          selected.push(moduleKey);
        }
        updateSetupState(interaction.guildId, { step: 1, preset: config.onboarding?.preset || 'custom', moduleList: selected, active: true, completed: false });
        const wizard = buildSetupWizard(interaction.guildId);
        await interaction.update({ embeds: [wizard.embed], components: wizard.components });
        return;
      }

      if (customId === 'setup_apply') {
        applySetupSelection(interaction.guildId);
        await interaction.update({ content: 'Setup complete! Nexus has been configured for your server.', embeds: [], components: [] });
        return;
      }

      if (customId === 'setup_reset_confirm') {
        resetGuildSetup(interaction.guildId);
        await interaction.update({ content: 'Setup progress was reset. Existing server data was not deleted.', embeds: [], components: [] });
        return;
      }

      if (customId === 'setup_reset_cancel') {
        await interaction.update({ content: 'Setup reset cancelled. Current configuration remains in place.', embeds: [], components: [] });
        return;
      }
    }

    if (customId === 'ticket_open' || customId.startsWith('ticket_open_')) {
      const category = customId.startsWith('ticket_open_') ? customId.slice('ticket_open_'.length) : 'Support';
      const modal = new ModalBuilder().setCustomId(`ticket_modal_${category.replace(/[^a-z0-9]/gi, '').toLowerCase() || 'support'}`).setTitle(`${category} Ticket`.slice(0, 45));
      const subjectInput = new TextInputBuilder().setCustomId('ticket_subject').setLabel('Subject').setStyle(TextInputStyle.Short).setMaxLength(100).setRequired(true);
      const descriptionInput = new TextInputBuilder().setCustomId('ticket_description').setLabel('Describe your issue').setStyle(TextInputStyle.Paragraph).setMaxLength(3500).setRequired(true);
      modal.addComponents(new ActionRowBuilder().addComponents(subjectInput), new ActionRowBuilder().addComponents(descriptionInput));
      await interaction.showModal(modal);
      return;
    }

    if (customId.startsWith('ticket_rate_')) {
      const parts = customId.split('_');
      const ticketId = parts[2];
      const rating = Number(parts[3]);
      if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
        await interaction.reply({ content: 'This survey button is invalid.', flags: 64 }); return;
      }
      try {
        const result = saveTicketRating(ticketId, interaction.user.id, rating, interaction.guildId || null);
        if (!result.ok) {
          await interaction.reply({ content: result.reason === 'already-rated' ? 'Thanks! A rating has already been recorded for this ticket.' : 'This survey is not available for your account.', flags: 64 }); return;
        }
        await interaction.update({ content: `Thank you for rating your Nexus Support experience **${rating}/5**! Your feedback has been recorded.`, embeds: interaction.message.embeds, components: [] });
      } catch (error) {
        console.error('[Tickets] Rating save failed:', error);
        await interaction.reply({ content: 'Could not save your rating right now. Please contact staff.', flags: 64 }).catch(() => {});
      }
      return;
    }

    if (customId === 'ticket_claim') {
      const ticket = interaction.inGuild() ? getTicketRecord(interaction.guildId, interaction.channelId) : null;
      if (!ticket) { await interaction.reply({ content: 'This channel is not a registered ticket.', flags: 64 }); return; }
      const isStaff = interaction.memberPermissions?.has('ManageChannels') || interaction.memberPermissions?.has('Administrator') || (ticket.staff_role_id && interaction.member?.roles?.cache?.has(ticket.staff_role_id));
      if (!isStaff) { await interaction.reply({ content: 'Only support staff can claim tickets.', flags: 64 }); return; }
      const claimed = db.prepare("UPDATE tickets SET claimed_by=?,claimed_at=?,status='claimed' WHERE channel_id=? AND status='open' AND claimed_by IS NULL").run(interaction.user.id, Date.now(), interaction.channelId);
      if (!claimed.changes) { await interaction.reply({ content: 'This ticket is already claimed or closed.', flags: 64 }); return; }
      addEvent(interaction.channelId, 'claimed', interaction.user.id);
      await interaction.reply({ content: `Ticket claimed by <@${interaction.user.id}>.`, flags: 64 });
      return;
    }

    if (customId === 'ticket_close') {
      const ticket = interaction.inGuild() ? getTicketRecord(interaction.guildId, interaction.channelId) : null;
      if (!ticket) { await interaction.reply({ content: 'This channel is not a registered ticket.', flags: 64 }); return; }
      const isStaff = interaction.memberPermissions?.has('ManageChannels') || interaction.memberPermissions?.has('Administrator') || (ticket.staff_role_id && interaction.member?.roles?.cache?.has(ticket.staff_role_id));
      if (!isStaff) { await interaction.reply({ content: 'Only support staff can close tickets.', flags: 64 }); return; }
      await interaction.reply({ content: 'Closing ticket, saving the HTML transcript, and preparing the closure report...', flags: 64 });
      const result = await closeTicketAndTranscript(client, interaction.channel, interaction.user, 'Closed by staff');
      if (!result.ok) await interaction.followUp({ content: result.reason === 'already-closing-or-closed' ? 'This ticket is already being closed.' : 'Could not close this ticket.', flags: 64 }).catch(() => {});
      else if (!result.dmSent) await interaction.followUp({ content: 'Ticket closed and archived, but the creator DM could not be delivered. The failure was logged for staff.', flags: 64 }).catch(() => {});
      return;
    }

    if (customId.startsWith('suggest_up_')) {
      const id = customId.replace('suggest_up_', '');
      const fs = require('node:fs');
      const path = require('node:path');
      const filePath = path.join(__dirname, '..', 'data', 'suggestions.json');
      const data = JSON.parse(fs.readFileSync(filePath, 'utf8') || '{}');
      const guild = data[interaction.guildId] || [];
      const item = guild.find(entry => entry.id === id);
      if (item) {
        if (!item.voters.up.includes(interaction.user.id)) {
          item.voters.up.push(interaction.user.id);
          item.votes.up += 1;
        }
      }
      fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
      await interaction.reply({ content: 'Your upvote was recorded.', flags: 64 });
      return;
    }

    if (customId.startsWith('suggest_down_')) {
      const id = customId.replace('suggest_down_', '');
      const fs = require('node:fs');
      const path = require('node:path');
      const filePath = path.join(__dirname, '..', 'data', 'suggestions.json');
      const data = JSON.parse(fs.readFileSync(filePath, 'utf8') || '{}');
      const guild = data[interaction.guildId] || [];
      const item = guild.find(entry => entry.id === id);
      if (item) {
        if (!item.voters.down.includes(interaction.user.id)) {
          item.voters.down.push(interaction.user.id);
          item.votes.down += 1;
        }
      }
      fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
      await interaction.reply({ content: 'Your downvote was recorded.', flags: 64 });
      return;
    }

    if (customId.startsWith('suggest_view_')) {
      const id = customId.replace('suggest_view_', '');
      const fs = require('node:fs');
      const path = require('node:path');
      const filePath = path.join(__dirname, '..', 'data', 'suggestions.json');
      const data = JSON.parse(fs.readFileSync(filePath, 'utf8') || '{}');
      const item = (data[interaction.guildId] || []).find(entry => entry.id === id);
      if (!item) return interaction.reply({ content: 'Suggestion not found.', flags: 64 });
      await interaction.reply({ content: `**Voters for ${id}**\nUpvoters: ${item.voters.up.length || 0}\nDownvoters: ${item.voters.down.length || 0}`, flags: 64 });
      return;
    }


  }

  if (interaction.isStringSelectMenu() && interaction.customId === 'selfrole_select') {
    const selected = interaction.values;
    for (const roleId of selected) {
      const role = interaction.guild.roles.cache.get(roleId);
      if (!role) continue;
      const member = interaction.member;
      if (member.roles.cache.has(roleId)) {
        await member.roles.remove(roleId).catch(() => {});
      } else {
        await member.roles.add(roleId).catch(() => {});
      }
    }
    await interaction.reply({ content: 'Your roles were updated.', flags: 64 });
    return;
  }

  if (interaction.isModalSubmit() && interaction.customId === 'native_poll_builder') {
    if (!interaction.inGuild()) return interaction.reply({ content: 'Polls can only be created in a server.', flags: 64 });
    try {
      const question = interaction.fields.getTextInputValue('question').trim();
      const answers = interaction.fields.getTextInputValue('answers').split('\n').map(x => x.trim()).filter(Boolean);
      const hours = Number(interaction.fields.getTextInputValue('hours').trim());
      const multipleRaw = interaction.fields.getTextInputValue('multiple').trim().toLowerCase();
      if (!['yes', 'no'].includes(multipleRaw)) throw new Error('Multiple answers must be `yes` or `no`.');
      const payload = nativePolls.buildOptions(question, answers, hours, multipleRaw === 'yes');
      await interaction.channel.send(payload);
      return interaction.reply({ content: `Poll published. Voting closes in ${hours} hour${hours === 1 ? '' : 's'}.`, flags: 64 });
    } catch (error) { return interaction.reply({ content: error.message, flags: 64 }); }
  }

  if (interaction.isModalSubmit() && (interaction.customId === 'ticket_modal' || interaction.customId.startsWith('ticket_modal_'))) {
    const subject = interaction.fields.getTextInputValue('ticket_subject');
    const description = interaction.fields.getTextInputValue('ticket_description');
    const categoryKey = interaction.customId === 'ticket_modal' ? 'support' : interaction.customId.slice('ticket_modal_'.length);
    const categories = { support:'Support', bugreport:'Bug Report', featurerequest:'Feature Request', partnership:'Partnership', billing:'Billing', userreport:'User Report', other:'Other' };
    const category = categories[categoryKey] || 'Support';
    const guild = interaction.guild;
    const config = getGuildConfig(guild.id);
    try {
      const channel = await createTicketChannel({ guild, ownerId: interaction.user.id, subject, description, staffRoleId: config.ticketStaffRoleId, category });
      await interaction.reply({ content: `Your **${category}** ticket has been created: <#${channel.id}>`, flags: 64 });
    } catch (error) {
      await interaction.reply({ content: error.message || 'Could not create your ticket. Please contact staff.', flags: 64 });
    }
    return;
  }
});


client.login(token).catch(error => {
  if (error.message.includes('disallowed intents')) {
    console.error('\n[LOGIN ERROR] Disallowed Intents: You must enable "Message Content Intent" in the Discord Developer Portal:');
    console.error('1. Go to https://discord.com/developers/applications');
    console.error('2. Select your application -> Click "Bot" in the left menu');
    console.error('3. Scroll to "Privileged Gateway Intents"');
    console.error('4. Toggle ON "Message Content Intent"');
    console.error('5. Click "Save Changes" and restart Nexus.\n');
  } else {
    console.error('Could not log in. Check DISCORD_BOT_TOKEN in your local .env file.', error.message);
  }
  process.exit(1);
});
