// Nexus intentionally uses prefix commands (!, . and ?), not slash commands.
// This no-op keeps `npm run deploy` safe and avoids requiring CLIENT_ID or a token.
console.log('Nexus uses prefix commands (!, . and ?). No slash commands need deploying.');
console.log('Start the bot with: npm start');
